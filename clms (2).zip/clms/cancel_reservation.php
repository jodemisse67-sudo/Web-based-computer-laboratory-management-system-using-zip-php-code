<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $reservation_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    
    // Check if reservation belongs to user (or admin)
    if ($_SESSION['role'] != 'admin') {
        $check_sql = "SELECT * FROM reservations WHERE reservation_id = ? AND user_id = ?";
        $check_stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($check_stmt, "ii", $reservation_id, $user_id);
        mysqli_stmt_execute($check_stmt);
        $result = mysqli_stmt_get_result($check_stmt);
        
        if (mysqli_num_rows($result) == 0) {
            $_SESSION['error'] = "Unauthorized to cancel this reservation";
            header("Location: dashboard.php");
            exit();
        }
    }
    
    // Update reservation status to cancelled
    $sql = "UPDATE reservations SET status = 'cancelled' WHERE reservation_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $reservation_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Reservation cancelled successfully";
    } else {
        $_SESSION['error'] = "Error cancelling reservation";
    }
    
    header("Location: dashboard.php");
    exit();
} else {
    header("Location: dashboard.php");
    exit();
}
?>