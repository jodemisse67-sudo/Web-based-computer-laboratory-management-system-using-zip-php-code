<?php
require_once 'config/config.php';
require_once 'includes/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo IMAGE_URL; ?>logo-icon.png">
    
    <!-- Schema.org markup for Google -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "EducationalOrganization",
      "name": "Wachemo University Durame Campus",
      "image": "<?php echo IMAGE_URL; ?>campus-building.jpg",
      "description": "Computer Laboratory Management System for efficient resource management",
      "url": "<?php echo BASE_URL; ?>"
    }
    </script>
    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Lightbox CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
    
    <style>
        /* Hero section with background image */
        .hero-section {
            position: relative;
            min-height: 80vh;
            display: flex;
            align-items: center;
            background: linear-gradient(rgba(44, 62, 80, 0.9), rgba(44, 62, 80, 0.8)), 
                        url('<?php echo clms/images; ?>hero-bg.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: white;
            padding: 4rem 0;
        }
        
        .hero-content {
            position: relative;
            z-index: 2;
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
        }
        
        .university-badge {
            margin-bottom: 2rem;
        }
        
        .university-badge img {
            width: 120px;
            height: auto;
            filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3));
        }
        
        .hero-title {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        
        .hero-subtitle {
            font-size: 1.5rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        
        .hero-description {
            font-size: 1.2rem;
            margin-bottom: 3rem;
            line-height: 1.6;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        /* Stats section */
        .stats-section {
            padding: 4rem 0;
            background: white;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
        }
        
        .stat-card {
            text-align: center;
            padding: 2rem;
            border-radius: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-10px);
        }
        
        .stat-number {
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        /* Features section */
        .features-section {
            padding: 4rem 0;
            background: #f8f9fa;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }
        
        .feature-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        
        .feature-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, #3498db 0%, #2c3e50 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
        }
        
        /* Gallery section */
        .gallery-section {
            padding: 4rem 0;
        }
        
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .gallery-item {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .gallery-item img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .gallery-item:hover img {
            transform: scale(1.1);
        }
        
        .gallery-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0,0,0,0.8));
            color: white;
            padding: 1.5rem;
            transform: translateY(100%);
            transition: transform 0.3s ease;
        }
        
        .gallery-item:hover .gallery-caption {
            transform: translateY(0);
        }
        
        /* CTA section */
        .cta-section {
            padding: 4rem 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
        }
        
        .cta-title {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .cta-description {
            font-size: 1.2rem;
            margin-bottom: 2rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            opacity: 0.9;
        }
        
        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.2rem;
            }
            
            .hero-buttons, .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .gallery-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .hero-title {
                font-size: 2rem;
            }
        }
        
        /* Your original styles with corrections */
        .university-badge {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .university-badge img {
            width: 100px;
            height: auto;
            filter: drop-shadow(0 2px 10px rgba(0,0,0,0.3));
        }
        
        .hero {
            color: white;
            padding: 5rem 0;
            position: relative;
        }
        
        .hero .container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            align-items: center;
        }
        
        .hero-content {
            z-index: 2;
            position: relative;
        }
        
        .hero-image {
            position: relative;
            overflow: hidden;
            border-radius: 15px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.5);
        }
        
        .hero-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.5s ease;
        }
        
        .hero-image:hover img {
            transform: scale(1.05);
        }
        
        .image-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            text-align: center;
        }
        
        .feature-image {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 1rem;
            border: 3px solid var(--primary-color);
        }
        
        .gallery {
            padding: 4rem 0;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        @media (max-width: 768px) {
            .hero .container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .hero-image {
                order: -1;
            }
            
            .university-badge img {
                width: 80px;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <div class="university-badge">
                    <img src="<?php echo IMAGE_URL; ?>university-badge.png" 
                         alt="Wachemo University Badge"
                         width="120"
                         height="120">
                </div>
                
                <h1 class="hero-title">Computer Laboratory Management System</h1>
                <p class="hero-subtitle">Wachemo University Durame Campus</p>
                <p class="hero-description">
                    Streamline laboratory resources, equipment reservations, and academic sessions 
                    management for enhanced educational experience.
                </p>
                
                <div class="hero-buttons">
                    <?php if (isLoggedIn()): ?>
                        <a href="<?php echo USER_ROLE; ?>_dashboard.php" class="btn btn-primary btn-large">
                            <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                        </a>
                        <a href="view_equipment.php" class="btn btn-secondary btn-large">
                            <i class="fas fa-desktop"></i> Browse Equipment
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary btn-large">
                            <i class="fas fa-sign-in-alt"></i> Login to System
                        </a>
                        <a href="signup.php" class="btn btn-secondary btn-large">
                            <i class="fas fa-user-plus"></i> Create Account
                        </a>
                    <?php endif; ?>
                    <a href="#features" class="btn btn-outline btn-large" style="background: rgba(255,255,255,0.1); border-color: white; color: white;">
                        <i class="fas fa-info-circle"></i> Learn More
                    </a>
                </div>
            </div>
            
            <div class="hero-image">
                <img src="<?php echo IMAGE_URL; ?>computer-lab.jpg" 
                     alt="Modern Computer Laboratory at Wachemo University" 
                     class="img-fluid"
                     width="600"
                     height="400">
                <div class="image-caption">
                    <small>Modern Computer Laboratory - Building A</small>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Stats Section -->
    <?php
    // Get stats for display
    $conn = getConnection();
    
    // Get equipment count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM equipment WHERE status = 'available'");
    $stmt->execute();
    $equipmentResult = $stmt->fetch();
    $equipmentCount = $equipmentResult['count'];
    
    // Get labs count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM labs WHERE status = 'active'");
    $stmt->execute();
    $labsResult = $stmt->fetch();
    $labsCount = $labsResult['count'];
    
    // Get users count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE status = 'active'");
    $stmt->execute();
    $usersResult = $stmt->fetch();
    $usersCount = $usersResult['count'];
    
    // Get reservations count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM equipment_reservations WHERE status = 'approved' AND reservation_date >= CURDATE()");
    $stmt->execute();
    $reservationsResult = $stmt->fetch();
    $reservationsCount = $reservationsResult['count'];
    ?>
    
    <section class="stats-section">
        <div class="container">
            <h2 class="section-title text-center">System at a Glance</h2>
            <p class="section-subtitle text-center">Real-time statistics of our laboratory management system</p>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $usersCount; ?></div>
                    <div class="stat-label">Registered Users</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-number"><?php echo $labsCount; ?></div>
                    <div class="stat-label">Active Laboratories</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-number"><?php echo $equipmentCount; ?></div>
                    <div class="stat-label">Available Equipment</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-number"><?php echo $reservationsCount; ?></div>
                    <div class="stat-label">Active Reservations</div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Features Section -->
    <section id="features" class="features-section">
        <div class="container">
            <h2 class="section-title text-center">System Features</h2>
            <p class="section-subtitle text-center">Comprehensive tools for managing computer laboratory resources</p>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <img src="<?php echo IMAGE_URL; ?>equipment-1.jpg" 
                             alt="Equipment Management" 
                             class="feature-image"
                             width="80"
                             height="80">
                    </div>
                    <h3>Equipment Management</h3>
                    <p>Track and manage all laboratory equipment with real-time status updates.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <img src="<?php echo IMAGE_URL; ?>lab-1.jpg" 
                             alt="Lab Reservations" 
                             class="feature-image"
                             width="80"
                             height="80">
                    </div>
                    <h3>Lab Reservations</h3>
                    <p>Easy booking system for laboratory sessions and equipment reservations.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Attendance Tracking</h3>
                    <p>Automated attendance system with detailed reports and analytics.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-tools"></i>
                    </div>
                    <h3>Maintenance Management</h3>
                    <p>Schedule and track equipment maintenance, repairs, and service requests efficiently.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3>Analytics & Reports</h3>
                    <p>Generate comprehensive reports on equipment usage, attendance, and resource utilization.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h3>Notification System</h3>
                    <p>Stay updated with real-time notifications for reservations, maintenance schedules, and important announcements.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Image Gallery -->
    <section class="gallery-section">
        <div class="container">
            <h2 class="section-title text-center">Our Laboratories</h2>
            <p class="section-subtitle text-center">State-of-the-art facilities for quality education</p>
            
            <div class="gallery-grid">
                <a href="<?php echo IMAGE_URL; ?>lab-1.jpg" 
                   data-lightbox="gallery" 
                   data-title="Computer Laboratory 1 - Main laboratory with 30 workstations" 
                   class="gallery-item">
                    <img src="<?php echo IMAGE_URL; ?>lab-1.jpg" 
                         alt="Computer Laboratory 1"
                         loading="lazy"
                         width="400"
                         height="250">
                    <div class="gallery-caption">
                        <h4>Computer Laboratory 1</h4>
                        <p>Main laboratory with 30 workstations</p>
                    </div>
                </a>
                
                <a href="<?php echo IMAGE_URL; ?>lab-2.jpg" 
                   data-lightbox="gallery" 
                   data-title="Network Laboratory - Cisco networking equipment" 
                   class="gallery-item">
                    <img src="<?php echo IMAGE_URL; ?>lab-2.jpg" 
                         alt="Network Laboratory"
                         loading="lazy"
                         width="400"
                         height="250">
                    <div class="gallery-caption">
                        <h4>Network Laboratory</h4>
                        <p>Cisco networking equipment</p>
                    </div>
                </a>
                
                <a href="<?php echo IMAGE_URL; ?>equipment-1.jpg" 
                   data-lightbox="gallery" 
                   data-title="Modern Computer Equipment - Latest computer hardware" 
                   class="gallery-item">
                    <img src="<?php echo IMAGE_URL; ?>equipment-1.jpg" 
                         alt="Modern Computer Equipment"
                         loading="lazy"
                         width="400"
                         height="250">
                    <div class="gallery-caption">
                        <h4>Modern Equipment</h4>
                        <p>Latest computer hardware</p>
                    </div>
                </a>
                
                <a href="<?php echo IMAGE_URL; ?>campus-building.jpg" 
                   data-lightbox="gallery" 
                   data-title="Wachemo University Campus - Durame Campus Building" 
                   class="gallery-item">
                    <img src="<?php echo IMAGE_URL; ?>campus-building.jpg" 
                         alt="Wachemo University Campus"
                         loading="lazy"
                         width="400"
                         height="250">
                    <div class="gallery-caption">
                        <h4>University Campus</h4>
                        <p>Durame Campus Building</p>
                    </div>
                </a>
            </div>
        </div>
    </section>
    
    <!-- Call to Action -->
    <section class="cta-section">
        <div class="container">
            <h2 class="cta-title">Ready to Get Started?</h2>
            <p class="cta-description">
                Join our system to efficiently manage laboratory resources and enhance your learning experience. 
                Whether you're a student, faculty member, or administrator, we have the tools you need.
            </p>
            
            <div class="cta-buttons">
                <?php if (!isLoggedIn()): ?>
                    <a href="signup.php" class="btn btn-primary btn-large">
                        <i class="fas fa-user-plus"></i> Create Free Account
                    </a>
                <?php endif; ?>
                <a href="about.php" class="btn btn-outline btn-large" style="background: rgba(255,255,255,0.1); border-color: white; color: white;">
                    <i class="fas fa-question-circle"></i> Learn More About Us
                </a>
                <a href="#contact" class="btn btn-outline btn-large" style="background: rgba(255,255,255,0.1); border-color: white; color: white;">
                    <i class="fas fa-envelope"></i> Contact Us
                </a>
            </div>
        </div>
    </section>
    
    <?php include 'footer.php'; ?>
    
    <!-- Lightbox JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
    
    <!-- Lazy Loading Images -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Lazy load images
            const lazyImages = document.querySelectorAll('img[loading="lazy"]');
            
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            // Add loaded class for transition effect
                            img.classList.add('loaded');
                            // Ensure the image is loaded
                            if (img.dataset.src) {
                                img.src = img.dataset.src;
                            }
                            imageObserver.unobserve(img);
                        }
                    });
                });
                
                lazyImages.forEach(img => {
                    // Store original src in data-src
                    if (!img.dataset.src) {
                        img.dataset.src = img.src;
                    }
                    // Start with a placeholder or low-quality image
                    img.classList.add('lazy-loading');
                    imageObserver.observe(img);
                });
            } else {
                // Fallback for older browsers
                lazyImages.forEach(img => {
                    img.classList.add('loaded');
                });
            }
            
            // Mobile menu toggle (if exists)
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            const navMenu = document.getElementById('navMenu');
            
            if (mobileMenuToggle && navMenu) {
                mobileMenuToggle.addEventListener('click', function() {
                    navMenu.classList.toggle('show');
                });
                
                // Close menu when clicking outside
                document.addEventListener('click', function(event) {
                    if (!mobileMenuToggle.contains(event.target) && !navMenu.contains(event.target)) {
                        navMenu.classList.remove('show');
                    }
                });
            }
            
            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    const href = this.getAttribute('href');
                    if (href === '#') return;
                    
                    if (href.startsWith('#') && document.querySelector(href)) {
                        e.preventDefault();
                        const target = document.querySelector(href);
                        window.scrollTo({
                            top: target.offsetTop - 80,
                            behavior: 'smooth'
                        });
                        
                        // Close mobile menu if open
                        if (navMenu && navMenu.classList.contains('show')) {
                            navMenu.classList.remove('show');
                        }
                    }
                });
            });
            
            // Initialize Lightbox
            if (typeof lightbox !== 'undefined') {
                lightbox.option({
                    'resizeDuration': 200,
                    'wrapAround': true,
                    'albumLabel': 'Image %1 of %2',
                    'fadeDuration': 300,
                    'imageFadeDuration': 300
                });
            }
            
            // Add CSS for lazy loading
            const style = document.createElement('style');
            style.textContent = `
                .lazy-loading {
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }
                .lazy-loading.loaded {
                    opacity: 1;
                }
            `;
            document.head.appendChild(style);
        });
    </script>
</body>
</html>