<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

// Require authentication
requireAuth();

$conn = 'getConnection'();

// Get date filter
$date_filter = $_GET['date'] ?? date('Y-m-d');
$lab_filter = $_GET['lab'] ?? '';

// Get lab sessions
$sql = "SELECT ls.*, c.course_name, c.course_code, l.lab_name, l.location, 
               CONCAT(u.first_name, ' ', u.last_name) as instructor_name 
        FROM lab_sessions ls 
        JOIN courses c ON ls.course_id = c.course_id 
        JOIN labs l ON ls.lab_id = l.lab_id 
        JOIN users u ON ls.instructor_id = u.user_id 
        WHERE 1=1";

$params = [];

if ($date_filter) {
    $sql .= " AND ls.session_date = ?";
    $params[] = $date_filter;
}

if ($lab_filter) {
    $sql .= " AND ls.lab_id = ?";
    $params[] = $lab_filter;
}

$sql .= " ORDER BY ls.start_time";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$sessions = $stmt->fetchAll();

// Get labs for filter
$labs = $conn->query("SELECT * FROM labs WHERE status = 'active' ORDER BY lab_name")->fetchAll();

// Get previous and next dates
$prev_date = date('Y-m-d', strtotime($date_filter . ' -1 day'));
$next_date = date('Y-m-d', strtotime($date_filter . ' +1 day'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Schedules - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="dashboard-content">
            <div class="dashboard-header">
                <h1><i class="fas fa-calendar-alt"></i> Lab Schedules</h1>
                <?php if (isAdmin() || isFaculty()): ?>
                <a href="schedules_lab_session.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Schedule Session
                </a>
                <?php endif; ?>
            </div>
            
            <!-- Date Navigation -->
            <div class="date-navigation">
                <div class="date-nav">
                    <a href="view_lab_schedules.php?date=<?php echo $prev_date; ?><?php echo $lab_filter ? '&lab=' . $lab_filter : ''; ?>" 
                       class="btn btn-outline">
                        <i class="fas fa-chevron-left"></i> Previous Day
                    </a>
                    
                    <div class="current-date">
                        <h2><?php echo date('l, F j, Y', strtotime($date_filter)); ?></h2>
                        <form method="GET" action="" style="display: inline;">
                            <input type="date" name="date" value="<?php echo $date_filter; ?>" 
                                   onchange="this.form.submit()" class="date-picker">
                            <?php if ($lab_filter): ?>
                            <input type="hidden" name="lab" value="<?php echo $lab_filter; ?>">
                            <?php endif; ?>
                        </form>
                    </div>
                    
                    <a href="view_lab_schedules.php?date=<?php echo $next_date; ?><?php echo $lab_filter ? '&lab=' . $lab_filter : ''; ?>" 
                       class="btn btn-outline">
                        Next Day <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
                
                <div class="today-btn">
                    <a href="view_lab_schedules.php" class="btn btn-primary">
                        <i class="fas fa-calendar-day"></i> Today
                    </a>
                </div>
            </div>
            
            <!-- Filters -->
            <div class="dashboard-card">
                <div class="card-body">
                    <form method="GET" action="" class="filter-form">
                        <input type="hidden" name="date" value="<?php echo $date_filter; ?>">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="lab">Filter by Laboratory</label>
                                <select id="lab" name="lab" class="form-control" onchange="this.form.submit()">
                                    <option value="">All Laboratories</option>
                                    <?php foreach ($labs as $lab): ?>
                                    <option value="<?php echo $lab['lab_id']; ?>" 
                                            <?php echo $lab_filter == $lab['lab_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($lab['lab_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <a href="view_lab_schedules.php?date=<?php echo $date_filter; ?>" class="btn btn-outline">
                                    <i class="fas fa-times"></i> Clear Filter
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Schedule Timeline -->
            <div class="schedule-timeline">
                <div class="timeline-header">
                    <h3>Daily Schedule</h3>
                    <div class="timeline-legend">
                        <div class="legend-item">
                            <span class="legend-color lecture"></span> Lecture
                        </div>
                        <div class="legend-item">
                            <span class="legend-color practical"></span> Practical
                        </div>
                        <div class="legend-item">
                            <span class="legend-color workshop"></span> Workshop
                        </div>
                        <div class="legend-item">
                            <span class="legend-color exam"></span> Exam
                        </div>
                    </div>
                </div>
                
                <div class="timeline">
                    <?php
                    // Define time slots (8 AM to 6 PM)
                    $start_hour = 8;
                    $end_hour = 18;
                    
                    for ($hour = $start_hour; $hour <= $end_hour; $hour++):
                        $time_slot = sprintf('%02d:00', $hour);
                        $next_slot = sprintf('%02d:00', $hour + 1);
                        
                        // Find sessions in this time slot
                        $slot_sessions = array_filter($sessions, function($session) use ($time_slot, $next_slot) {
                            $start = strtotime($session['start_time']);
                            $end = strtotime($session['end_time']);
                            $slot_start = strtotime($time_slot);
                            $slot_end = strtotime($next_slot);
                            
                            return ($start < $slot_end && $end > $slot_start);
                        });
                    ?>
                    <div class="time-slot">
                        <div class="slot-time"><?php echo date('g:i A', strtotime($time_slot)); ?></div>
                        <div class="slot-sessions">
                            <?php if (empty($slot_sessions)): ?>
                                <div class="empty-slot">No sessions</div>
                            <?php else: ?>
                                <?php foreach ($slot_sessions as $session): ?>
                                <div class="session-block session-<?php echo $session['session_type']; ?>">
                                    <div class="session-header">
                                        <strong><?php echo htmlspecialchars($session['course_code']); ?></strong>
                                        <span class="session-time">
                                            <?php echo formatTime($session['start_time']); ?> - <?php echo formatTime($session['end_time']); ?>
                                        </span>
                                    </div>
                                    <div class="session-details">
                                        <div class="session-title"><?php echo htmlspecialchars($session['course_name']); ?></div>
                                        <div class="session-info">
                                            <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($session['instructor_name']); ?></span>
                                            <span><i class="fas fa-building"></i> <?php echo htmlspecialchars($session['lab_name']); ?></span>
                                            <span><i class="fas fa-users"></i> <?php echo $session['max_students']; ?> students</span>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
            
            <!-- Upcoming Sessions -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h3>Upcoming Sessions (Next 7 Days)</h3>
                </div>
                <div class="card-body">
                    <?php
                    $upcoming_sql = "SELECT ls.*, c.course_name, c.course_code, l.lab_name, l.location 
                                    FROM lab_sessions ls 
                                    JOIN courses c ON ls.course_id = c.course_id 
                                    JOIN labs l ON ls.lab_id = l.lab_id 
                                    WHERE ls.session_date >= CURDATE() 
                                    AND ls.session_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) 
                                    ORDER BY ls.session_date, ls.start_time 
                                    LIMIT 10";
                    $upcoming = $conn->query($upcoming_sql)->fetchAll();
                    ?>
                    
                    <?php if (empty($upcoming)): ?>
                        <div class="empty-state">
                            <i class="fas fa-calendar-times"></i>
                            <p>No upcoming sessions in the next 7 days</p>
                        </div>
                    <?php else: ?>
                        <div class="upcoming-sessions">
                            <?php foreach ($upcoming as $session): ?>
                            <div class="upcoming-session">
                                <div class="session-date">
                                    <div class="session-day"><?php echo date('d', strtotime($session['session_date'])); ?></div>
                                    <div class="session-month"><?php echo date('M', strtotime($session['session_date'])); ?></div>
                                    <div class="session-weekday"><?php echo date('D', strtotime($session['session_date'])); ?></div>
                                </div>
                                <div class="session-details">
                                    <div class="session-title">
                                        <strong><?php echo htmlspecialchars($session['course_name']); ?></strong>
                                        <span class="badge badge-<?php echo 'getSessionTypeClass'($session['session_type']); ?>">
                                            <?php echo ucfirst($session['session_type']); ?>
                                        </span>
                                    </div>
                                    <div class="session-info">
                                        <span><i class="fas fa-building"></i> <?php echo htmlspecialchars($session['lab_name']); ?></span>
                                        <span><i class="fas fa-clock"></i> <?php echo formatTime($session['start_time']); ?> - <?php echo formatTime($session['end_time']); ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <style>
        .date-navigation {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .date-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .current-date {
            text-align: center;
        }
        
        .current-date h2 {
            margin-bottom: 0.5rem;
        }
        
        .date-picker {
            padding: 0.5rem;
            border: 2px solid var(--border-color);
            border-radius: 4px;
            font-size: 1rem;
        }
        
        .today-btn {
            text-align: center;
        }
        
        .schedule-timeline {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .timeline-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .timeline-legend {
            display: flex;
            gap: 1rem;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.875rem;
        }
        
        .legend-color {
            width: 15px;
            height: 15px;
            border-radius: 3px;
        }
        
        .legend-color.lecture { background-color: #3498db; }
        .legend-color.practical { background-color: #2ecc71; }
        .legend-color.workshop { background-color: #f39c12; }
        .legend-color.exam { background-color: #e74c3c; }
        
        .timeline {
            border-left: 2px solid var(--border-color);
            margin-left: 100px;
        }
        
        .time-slot {
            display: flex;
            margin-bottom: 1rem;
            position: relative;
        }
        
        .time-slot:before {
            content: '';
            position: absolute;
            left: -6px;
            top: 0;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: var(--primary-color);
        }
        
        .slot-time {
            width: 100px;
            margin-left: -100px;
            padding-right: 1rem;
            text-align: right;
            font-weight: 500;
            color: var(--secondary-color);
        }
        
        .slot-sessions {
            flex: 1;
            padding-left: 1rem;
        }
        
        .empty-slot {
            padding: 1rem;
            background: var(--light-gray);
            border-radius: 4px;
            color: var(--gray-color);
            text-align: center;
        }
        
        .session-block {
            background: white;
            border-radius: 4px;
            box-shadow: var(--shadow);
            margin-bottom: 0.5rem;
            border-left: 4px solid;
            overflow: hidden;
        }
        
        .session-lecture { border-left-color: #3498db; }
        .session-practical { border-left-color: #2ecc71; }
        .session-workshop { border-left-color: #f39c12; }
        .session-exam { border-left-color: #e74c3c; }
        
        .session-header {
            background: var(--light-gray);
            padding: 0.75rem 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .session-time {
            font-size: 0.875rem;
            color: var(--gray-color);
        }
        
        .session-details {
            padding: 1rem;
        }
        
        .session-title {
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .session-info {
            display: flex;
            gap: 1rem;
            font-size: 0.875rem;
            color: var(--gray-color);
        }
        
        .session-info span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .upcoming-sessions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .upcoming-session {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            background: var(--light-gray);
            border-radius: var(--border-radius);
            border-left: 4px solid var(--primary-color);
        }
        
        .session-date {
            text-align: center;
            min-width: 80px;
        }
        
        .session-day {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .session-month {
            font-size: 0.875rem;
            color: var(--gray-color);
            text-transform: uppercase;
        }
        
        .session-weekday {
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--secondary-color);
        }
        
        @media (max-width: 768px) {
            .date-nav {
                flex-direction: column;
                gap: 1rem;
            }
            
            .timeline {
                margin-left: 0;
                border-left: none;
                border-top: 2px solid var(--border-color);
                padding-top: 1rem;
            }
            
            .time-slot {
                flex-direction: column;
            }
            
            .time-slot:before {
                left: 50%;
                top: -6px;
                transform: translateX(-50%);
            }
            
            .slot-time {
                width: auto;
                margin-left: 0;
                text-align: center;
                margin-bottom: 0.5rem;
            }
            
            .slot-sessions {
                padding-left: 0;
            }
            
            .timeline-legend {
                flex-wrap: wrap;
                justify-content: center;
            }
        }
    </style>
    
    <script>
        function getSessionTypeClass(type) {
            const classes = {
                'lecture': 'primary',
                'practical': 'success',
                'workshop': 'warning',
                'exam': 'danger'
            };
            return classes[type] || 'secondary';
        }
    </script>
</body>
</html>