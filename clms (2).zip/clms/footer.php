<?php require_once 'config/config.php'; ?>
    </main>
    
    <footer id="contact">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><i class="fas fa-university"></i> Wachemo University</h3>
                    <p>Durame Campus</p>
                    <p>Computer Laboratory Management System</p>
                    <p>Version: <?php echo 'VERSION'; ?></p>
                </div>
                
                <div class="footer-section">
                    <h3><i class="fas fa-link"></i> Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="about.php"><i class="fas fa-info-circle"></i> About</a></li>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="<?php echo 'USER_ROLE'; ?>_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                            <li><a href="view_notification.php"><i class="fas fa-bell"></i> Notifications</a></li>
                        <?php else: ?>
                            <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                            <li><a href="signup.php"><i class="fas fa-user-plus"></i> Sign Up</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3><i class="fas fa-address-book"></i> Contact Us</h3>
                    <p><i class="fas fa-envelope"></i> <?php echo 'SITE_EMAIL'; ?></p>
                    <p><i class="fas fa-phone"></i> +251 123 456 789</p>
                    <p><i class="fas fa-map-marker-alt"></i> Durame, Kembata Tembaro Zone, Ethiopia</p>
                </div>
                
                <div class="footer-section">
                    <h3><i class="fas fa-clock"></i> Working Hours</h3>
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 1:00 PM</p>
                    <p>Sunday: Closed</p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Wachemo University Durame Campus. All rights reserved.</p>
                <p>Developed by Computer Science Department</p>
            </div>
        </div>
    </footer>
    
    <script src="js/script.js"></script>
    <script>
        // Initialize dropdown menus
        document.addEventListener('DOMContentLoaded', function() {
            const userDropdown = document.getElementById('userDropdown');
            const dropdownMenu = document.getElementById('dropdownMenu');
            
            if (userDropdown && dropdownMenu) {
                userDropdown.addEventListener('click', function(e) {
                    e.stopPropagation();
                    dropdownMenu.classList.toggle('show');
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function() {
                    dropdownMenu.classList.remove('show');
                });
            }
            
            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    const href = this.getAttribute('href');
                    if (href === '#') return;
                    
                    const target = document.querySelector(href);
                    if (target) {
                        e.preventDefault();
                        window.scrollTo({
                            top: target.offsetTop - 80,
                            behavior: 'smooth'
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>