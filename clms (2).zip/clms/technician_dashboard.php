<?php
session_start();
require_once 'config.php';

// Check if lab manager/technician
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'lab_manager') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get technician stats
$stats = [];

// Pending reservations
$sql = "SELECT COUNT(*) as total FROM reservations WHERE status = 'pending'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$stats['pending_reservations'] = mysqli_fetch_assoc($result)['total'];

// Equipment needing maintenance
$sql = "SELECT COUNT(*) as total FROM equipment WHERE status = 'maintenance'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$stats['maintenance'] = mysqli_fetch_assoc($result)['total'];

// Active labs
$sql = "SELECT COUNT(*) as total FROM labs WHERE status = 'active'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$stats['active_labs'] = mysqli_fetch_assoc($result)['total'];

// Pending requests
$sql = "SELECT COUNT(*) as total FROM resource_requests WHERE status = 'pending'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$stats['pending_requests'] = mysqli_fetch_assoc($result)['total'];

// Get pending reservations
$pending_sql = "SELECT r.*, u.full_name, l.lab_name 
                FROM reservations r 
                JOIN users u ON r.user_id = u.user_id 
                JOIN labs l ON r.lab_id = l.lab_id 
                WHERE r.status = 'pending' 
                ORDER BY r.reservation_date ASC, r.start_time ASC 
                LIMIT 5";
$pending_result = mysqli_query($conn, $pending_sql);

// Get equipment needing attention
$equipment_sql = "SELECT e.*, l.lab_name 
                  FROM equipment e 
                  LEFT JOIN labs l ON e.lab_id = l.lab_id 
                  WHERE e.status IN ('maintenance', 'repaired') 
                  ORDER BY e.status, e.last_maintenance DESC 
                  LIMIT 5";
$equipment_result = mysqli_query($conn, $equipment_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Dashboard - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Technician Dashboard</h2>
            <div>
                <a href="manage_reservation.php" class="btn btn-primary">
                    <i class="fas fa-tasks"></i> Manage Reservations
                </a>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-warning text-dark">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Pending</h5>
                                <h2><?php echo $stats['pending_reservations']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-clock fa-3x"></i>
                            </div>
                        </div>
                        <p class="mb-0">Reservations to Approve</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Maintenance</h5>
                                <h2><?php echo $stats['maintenance']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-tools fa-3x"></i>
                            </div>
                        </div>
                        <p class="mb-0">Equipment Needs Attention</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Active Labs</h5>
                                <h2><?php echo $stats['active_labs']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-laptop-house fa-3x"></i>
                            </div>
                        </div>
                        <p class="mb-0">Labs Available</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Requests</h5>
                                <h2><?php echo $stats['pending_requests']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-inbox fa-3x"></i>
                            </div>
                        </div>
                        <p class="mb-0">Pending Resource Requests</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="row">
            <!-- Left Column -->
            <div class="col-md-6">
                <!-- Pending Reservations -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Pending Reservations</h5>
                        <a href="manage_reservation.php" class="btn btn-sm btn-primary">Manage All</a>
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($pending_result) > 0): ?>
                        <div class="list-group">
                            <?php while ($res = mysqli_fetch_assoc($pending_result)): ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($res['lab_name']); ?></h6>
                                    <small><?php echo date('M d', strtotime($res['reservation_date'])); ?></small>
                                </div>
                                <p class="mb-1">
                                    <i class="fas fa-user"></i> 
                                    <?php echo htmlspecialchars($res['full_name']); ?>
                                </p>
                                <p class="mb-1">
                                    <i class="fas fa-clock"></i> 
                                    <?php echo date('g:i A', strtotime($res['start_time'])); ?> - 
                                    <?php echo date('g:i A', strtotime($res['end_time'])); ?>
                                </p>
                                <div class="mt-2">
                                    <a href="manage_reservation.php?approve=<?php echo $res['reservation_id']; ?>" 
                                       class="btn btn-sm btn-success">Approve</a>
                                    <a href="manage_reservation.php?reject=<?php echo $res['reservation_id']; ?>" 
                                       class="btn btn-sm btn-danger">Reject</a>
                                    <a href="view_reservation.php?id=<?php echo $res['reservation_id']; ?>" 
                                       class="btn btn-sm btn-info">View</a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-success">
                            <p class="mb-0">No pending reservations. All caught up!</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-2">
                            <div class="col-md-6">
                                <a href="manage_equipment.php" class="btn btn-outline-primary w-100 mb-2">
                                    <i class="fas fa-desktop"></i> Manage Equipment
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="post_notification.php" class="btn btn-outline-success w-100 mb-2">
                                    <i class="fas fa-bell"></i> Post Notice
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="request_resources.php" class="btn btn-outline-warning w-100 mb-2">
                                    <i class="fas fa-tools"></i> Resource Requests
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="generate_reports.php" class="btn btn-outline-info w-100 mb-2">
                                    <i class="fas fa-chart-bar"></i> Generate Reports
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Column -->
            <div class="col-md-6">
                <!-- Equipment Status -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Equipment Status</h5>
                        <a href="manage_equipment.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($equipment_result) > 0): ?>
                        <div class="list-group">
                            <?php while ($equip = mysqli_fetch_assoc($equipment_result)): ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($equip['equipment_name']); ?></h6>
                                    <span class="badge bg-<?php 
                                        switch($equip['status']) {
                                            case 'maintenance': echo 'danger'; break;
                                            case 'repaired': echo 'success'; break;
                                            default: echo 'secondary';
                                        }
                                    ?>">
                                        <?php echo ucfirst($equip['status']); ?>
                                    </span>
                                </div>
                                <p class="mb-1">
                                    <i class="fas fa-home"></i> 
                                    <?php echo htmlspecialchars($equip['lab_name']); ?>
                                </p>
                                <?php if($equip['maintenance_notes']): ?>
                                <p class="mb-1 small"><?php echo htmlspecialchars(substr($equip['maintenance_notes'], 0, 100)); ?>...</p>
                                <?php endif; ?>
                                <div class="mt-2">
                                    <a href="manage_equipment.php" 
                                       class="btn btn-sm btn-outline-primary">Update Status</a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-success">
                            <p class="mb-0">All equipment is working properly!</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Today's Reservations -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Today's Reservations</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $today_sql = "SELECT l.lab_name, 
                                     COUNT(r.reservation_id) as reservation_count
                                     FROM labs l 
                                     LEFT JOIN reservations r ON l.lab_id = r.lab_id 
                                     AND r.reservation_date = CURDATE() 
                                     AND r.status = 'approved' 
                                     WHERE l.status = 'active' 
                                     GROUP BY l.lab_id 
                                     ORDER BY reservation_count DESC";
                        $today_result = mysqli_query($conn, $today_sql);
                        ?>
                        
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Lab</th>
                                        <th>Today's Bookings</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($today = mysqli_fetch_assoc($today_result)): 
                                        $percent = ($today['reservation_count'] / 10) * 100; // Assuming max 10 slots per day
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($today['lab_name']); ?></td>
                                        <td><?php echo $today['reservation_count']; ?></td>
                                        <td>
                                            <?php if($percent > 80): ?>
                                                <span class="badge bg-danger">Busy</span>
                                            <?php elseif($percent > 50): ?>
                                                <span class="badge bg-warning">Moderate</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Available</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- System Health -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>System Health</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <?php
                                    $total_equipment = mysqli_query($conn, "SELECT COUNT(*) as total FROM equipment");
                                    $total_equipment_count = mysqli_fetch_assoc($total_equipment)['total'];
                                    $working_equipment = mysqli_query($conn, "SELECT COUNT(*) as total FROM equipment WHERE status = 'working'");
                                    $working_equipment_count = mysqli_fetch_assoc($working_equipment)['total'];
                                    $equipment_health = $total_equipment_count > 0 ? ($working_equipment_count / $total_equipment_count) * 100 : 100;
                                    ?>
                                    <h3><?php echo round($equipment_health); ?>%</h3>
                                    <small>Equipment Health</small>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <?php
                                    $total_labs = mysqli_query($conn, "SELECT COUNT(*) as total FROM labs");
                                    $total_labs_count = mysqli_fetch_assoc($total_labs)['total'];
                                    $active_labs = mysqli_query($conn, "SELECT COUNT(*) as total FROM labs WHERE status = 'active'");
                                    $active_labs_count = mysqli_fetch_assoc($active_labs)['total'];
                                    $lab_health = $total_labs_count > 0 ? ($active_labs_count / $total_labs_count) * 100 : 100;
                                    ?>
                                    <h3><?php echo round($lab_health); ?>%</h3>
                                    <small>Lab Availability</small>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <?php
                                    $pending_tasks = $stats['pending_reservations'] + $stats['pending_requests'];
                                    ?>
                                    <h3><?php echo $pending_tasks; ?></h3>
                                    <small>Pending Tasks</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>