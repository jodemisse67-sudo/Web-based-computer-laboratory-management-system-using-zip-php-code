<?php
session_start();
require_once 'config.php';

// Check if admin or lab manager
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'lab_manager')) {
    header("Location: login.php");
    exit();
}

$message = "";

// Add new equipment
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_equipment'])) {
    $equipment_name = $_POST['equipment_name'];
    $lab_id = $_POST['lab_id'];
    $serial_number = $_POST['serial_number'];
    $purchase_date = $_POST['purchase_date'];
    $warranty_expiry = $_POST['warranty_expiry'];
    $status = $_POST['status'];
    $notes = $_POST['notes'];
    
    $sql = "INSERT INTO equipment (equipment_name, lab_id, serial_number, 
            purchase_date, warranty_expiry, status, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sisssss", $equipment_name, $lab_id, $serial_number, 
                          $purchase_date, $warranty_expiry, $status, $notes);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = "<div class='alert alert-success'>Equipment added successfully</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error adding equipment</div>";
    }
}

// Update equipment status
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $equipment_id = $_POST['equipment_id'];
    $status = $_POST['status'];
    $maintenance_notes = $_POST['maintenance_notes'];
    
    $sql = "UPDATE equipment SET status = ?, maintenance_notes = ?, 
            last_maintenance = NOW() WHERE equipment_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssi", $status, $maintenance_notes, $equipment_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = "<div class='alert alert-success'>Equipment status updated</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error updating status</div>";
    }
}

// Get all equipment with lab info
$sql = "SELECT e.*, l.lab_name 
        FROM equipment e 
        LEFT JOIN labs l ON e.lab_id = l.lab_id 
        ORDER BY e.status, e.equipment_name";
$result = mysqli_query($conn, $sql);

// Get labs for dropdown
$labs_sql = "SELECT * FROM labs WHERE status = 'active' ORDER BY lab_name";
$labs_result = mysqli_query($conn, $labs_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Equipment - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2>Equipment Management</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <!-- Add Equipment Form -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Add New Equipment</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Equipment Name</label>
                                <input type="text" class="form-control" name="equipment_name" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Lab</label>
                                <select class="form-select" name="lab_id" required>
                                    <option value="">Select Lab</option>
                                    <?php while ($lab = mysqli_fetch_assoc($labs_result)): ?>
                                    <option value="<?php echo $lab['lab_id']; ?>">
                                        <?php echo htmlspecialchars($lab['lab_name']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Serial Number</label>
                                <input type="text" class="form-control" name="serial_number">
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Purchase Date</label>
                                    <input type="date" class="form-control" name="purchase_date">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Warranty Expiry</label>
                                    <input type="date" class="form-control" name="warranty_expiry">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status" required>
                                    <option value="working">Working</option>
                                    <option value="maintenance">Under Maintenance</option>
                                    <option value="repaired">Repaired</option>
                                    <option value="disposed">Disposed</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea class="form-control" name="notes" rows="3"></textarea>
                            </div>
                            <button type="submit" name="add_equipment" class="btn btn-primary">Add Equipment</button>
                        </form>
                    </div>
                </div>
                
                <!-- Equipment Summary -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Equipment Summary</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $summary_sql = "SELECT status, COUNT(*) as count FROM equipment GROUP BY status";
                        $summary_result = mysqli_query($conn, $summary_sql);
                        ?>
                        <ul class="list-group">
                            <?php while ($summary = mysqli_fetch_assoc($summary_result)): 
                                $badge_class = [
                                    'working' => 'success',
                                    'maintenance' => 'warning',
                                    'repaired' => 'info',
                                    'disposed' => 'danger'
                                ];
                            ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo ucfirst($summary['status']); ?>
                                <span class="badge bg-<?php echo $badge_class[$summary['status']]; ?> rounded-pill">
                                    <?php echo $summary['count']; ?>
                                </span>
                            </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Equipment List -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Equipment List</h5>
                        <div>
                            <select class="form-select form-select-sm" id="filterStatus" onchange="filterEquipment()">
                                <option value="all">All Status</option>
                                <option value="working">Working</option>
                                <option value="maintenance">Maintenance</option>
                                <option value="repaired">Repaired</option>
                                <option value="disposed">Disposed</option>
                            </select>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="equipmentTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Equipment</th>
                                        <th>Lab</th>
                                        <th>Serial No.</th>
                                        <th>Status</th>
                                        <th>Warranty</th>
                                        <th>Last Maintenance</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($equipment = mysqli_fetch_assoc($result)): 
                                        $warranty_class = '';
                                        if ($equipment['warranty_expiry']) {
                                            $expiry = strtotime($equipment['warranty_expiry']);
                                            $today = strtotime(date('Y-m-d'));
                                            $diff = ($expiry - $today) / (60 * 60 * 24);
                                            
                                            if ($diff < 0) {
                                                $warranty_class = 'text-danger';
                                            } elseif ($diff < 30) {
                                                $warranty_class = 'text-warning';
                                            }
                                        }
                                    ?>
                                    <tr data-status="<?php echo $equipment['status']; ?>">
                                        <td><?php echo $equipment['equipment_id']; ?></td>
                                        <td><?php echo htmlspecialchars($equipment['equipment_name']); ?></td>
                                        <td><?php echo htmlspecialchars($equipment['lab_name']); ?></td>
                                        <td><?php echo htmlspecialchars($equipment['serial_number']); ?></td>
                                        <td>
                                            <?php 
                                            $status_badge = [
                                                'working' => 'success',
                                                'maintenance' => 'warning',
                                                'repaired' => 'info',
                                                'disposed' => 'danger'
                                            ];
                                            ?>
                                            <span class="badge bg-<?php echo $status_badge[$equipment['status']]; ?>">
                                                <?php echo ucfirst($equipment['status']); ?>
                                            </span>
                                        </td>
                                        <td class="<?php echo $warranty_class; ?>">
                                            <?php echo $equipment['warranty_expiry'] ? date('Y-m-d', strtotime($equipment['warranty_expiry'])) : 'N/A'; ?>
                                        </td>
                                        <td>
                                            <?php echo $equipment['last_maintenance'] ? date('Y-m-d', strtotime($equipment['last_maintenance'])) : 'Never'; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" 
                                                    data-bs-target="#updateModal<?php echo $equipment['equipment_id']; ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <a href="equipment_history.php?id=<?php echo $equipment['equipment_id']; ?>" 
                                               class="btn btn-sm btn-info">
                                               <i class="fas fa-history"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    
                                    <!-- Update Modal -->
                                    <div class="modal fade" id="updateModal<?php echo $equipment['equipment_id']; ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form method="POST" action="">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Update Equipment Status</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="equipment_id" value="<?php echo $equipment['equipment_id']; ?>">
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Current Status</label>
                                                            <select class="form-select" name="status" required>
                                                                <option value="working" <?php echo $equipment['status'] == 'working' ? 'selected' : ''; ?>>Working</option>
                                                                <option value="maintenance" <?php echo $equipment['status'] == 'maintenance' ? 'selected' : ''; ?>>Under Maintenance</option>
                                                                <option value="repaired" <?php echo $equipment['status'] == 'repaired' ? 'selected' : ''; ?>>Repaired</option>
                                                                <option value="disposed" <?php echo $equipment['status'] == 'disposed' ? 'selected' : ''; ?>>Disposed</option>
                                                            </select>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Maintenance Notes</label>
                                                            <textarea class="form-control" name="maintenance_notes" rows="3"><?php echo htmlspecialchars($equipment['maintenance_notes']); ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" name="update_status" class="btn btn-primary">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function filterEquipment() {
        var status = document.getElementById('filterStatus').value;
        var rows = document.querySelectorAll('#equipmentTable tbody tr');
        
        rows.forEach(function(row) {
            if (status == 'all' || row.getAttribute('data-status') == status) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>