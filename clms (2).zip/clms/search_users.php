<?php
session_start();
require_once 'config.php';

// Check if admin or lab manager
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'lab_manager')) {
    header("Location: login.php");
    exit();
}

$search_results = [];
$search_query = "";

// Handle search
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
    $search_query = mysqli_real_escape_string($conn, $_GET['search']);
    
    $sql = "SELECT * FROM users 
            WHERE username LIKE ? 
            OR full_name LIKE ? 
            OR email LIKE ? 
            OR department LIKE ? 
            OR phone LIKE ?
            ORDER BY full_name";
    
    $search_param = "%{$search_query}%";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssss", $search_param, $search_param, $search_param, $search_param, $search_param);
    mysqli_stmt_execute($stmt);
    $search_results = mysqli_stmt_get_result($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Users - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>Search Users</h2>
        
        <!-- Search Form -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-10">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" 
                                   placeholder="Search by name, username, email, department, or phone..." 
                                   value="<?php echo htmlspecialchars($search_query); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i> Search
                            </button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <a href="search_users.php" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Search Results -->
        <?php if(isset($_GET['search'])): ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h5>Search Results</h5>
                <span class="badge bg-primary">
                    <?php echo mysqli_num_rows($search_results); ?> users found
                </span>
            </div>
            <div class="card-body">
                <?php if(mysqli_num_rows($search_results) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Phone</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($user = mysqli_fetch_assoc($search_results)): ?>
                            <tr>
                                <td><?php echo $user['user_id']; ?></td>
                                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <?php 
                                    $role_badge = [
                                        'admin' => 'danger',
                                        'faculty' => 'success',
                                        'lab_manager' => 'warning',
                                        'student' => 'primary'
                                    ];
                                    ?>
                                    <span class="badge bg-<?php echo $role_badge[$user['role']]; ?>">
                                        <?php echo ucfirst($user['role']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($user['department']); ?></td>
                                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                <td>
                                    <a href="view_user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="btn btn-sm btn-info">
                                       <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit_user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="btn btn-sm btn-warning">
                                       <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-warning">
                    No users found matching "<?php echo htmlspecialchars($search_query); ?>"
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Advanced Search Options -->
        <div class="card mt-4">
            <div class="card-header">
                <h5>Advanced Search Options</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" name="role">
                            <option value="">All Roles</option>
                            <option value="admin">Administrator</option>
                            <option value="faculty">Faculty</option>
                            <option value="lab_manager">Lab Manager</option>
                            <option value="student">Student</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Department</label>
                        <input type="text" class="form-control" name="department" placeholder="Department">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Date Joined From</label>
                        <input type="date" class="form-control" name="date_from">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Date Joined To</label>
                        <input type="date" class="form-control" name="date_to">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Filter Users
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>