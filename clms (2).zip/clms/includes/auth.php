<?php
require_once __DIR__ . '/../config/config.php';

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if user has specific role
function hasRole($role) {
    if (!isLoggedIn()) return false;
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

// Check if user has any of the specified roles
function hasAnyRole($roles) {
    if (!isLoggedIn()) return false;
    return isset($_SESSION['role']) && in_array($_SESSION['role'], $roles);
}

// Require authentication
function requireAuth() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header('Location: ' . 'BASE_URL' . 'login.php');
        exit();
    }
}

// Require specific role
function requireRole($role) {
    requireAuth();
    if (!hasRole($role)) {
        $_SESSION['error'] = 'You do not have permission to access this page.';
        header('Location: ' . 'BASE_URL' . 'index.php');
        exit();
    }
}

// Require any of the specified roles
function requireAnyRole($roles) {
    requireAuth();
    if (!hasAnyRole($roles)) {
        $_SESSION['error'] = 'You do not have permission to access this page.';
        header('Location: ' . 'BASE_URL' . 'index.php');
        exit();
    }
}

// Login user
function loginUser($user) {
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['first_name'] = $user['first_name'];
    $_SESSION['last_name'] = $user['last_name'];
    $_SESSION['logged_in'] = true;
    
    // Update last login
    $conn = 'getConnection'();
    $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
    $stmt->execute([$user['user_id']]);
}

// Logout user
function logoutUser() {
    session_destroy();
    header('Location: ' . 'BASE_URL' . 'login.php');
    exit();
}

// Authenticate user
function authenticateUser($username, $password) {
    $conn = 'getConnection'();
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] !== 'active') {
            return ['success' => false, 'message' => 'Your account is ' . $user['status']];
        }
        return ['success' => true, 'user' => $user];
    }
    
    return ['success' => false, 'message' => 'Invalid username or password'];
}

// Register new user
function registerUser($data) {
    $conn = 'getConnection'();
    
    // Check if username or email exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$data['username'], $data['email']]);
    
    if ($stmt->rowCount() > 0) {
        return ['success' => false, 'message' => 'Username or email already exists'];
    }
    
    // Hash password
    $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Insert user
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, first_name, last_name, phone, department, student_id, role) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    try {
        $stmt->execute([
            $data['username'],
            $data['email'],
            $hashed_password,
            $data['first_name'],
            $data['last_name'],
            $data['phone'] ?? null,
            $data['department'] ?? null,
            $data['student_id'] ?? null,
            $data['role'] ?? 'student'
        ]);
        
        $userId = $conn->lastInsertId();
        return ['success' => true, 'user_id' => $userId];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()];
    }
}

// Get current user
function getCurrentUser() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    return 'getUserById'($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin() {
    return hasRole('admin');
}

// Check if user is student
function isStudent() {
    return hasRole('student');
}

// Check if user is faculty
function isFaculty() {
    return hasRole('faculty') || hasRole('instructor');
}

// Check if user is technician
function isTechnician() {
    return hasRole('technician');
}
?>