<?php
require_once __DIR__ . '/../config/config.php';

// Get user by ID
function getUserById($userId) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

// Get user by username
function getUserByUsername($username) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    return $stmt->fetch();
}

// Get all users
function getAllUsers($limit = 100, $offset = 0) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get users by role
function getUsersByRole($role, $limit = 100) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT * FROM users WHERE role = ? ORDER BY created_at DESC LIMIT ?");
    $stmt->bindValue(1, $role, PDO::PARAM_STR);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Update user
function updateUser($userId, $data) {
    $conn = 'getConnection'();
    
    $updates = [];
    $params = [];
    
    $allowedFields = ['first_name', 'last_name', 'email', 'phone', 'department', 'student_id', 'faculty_id', 'profile_pic'];
    
    foreach ($data as $key => $value) {
        if (in_array($key, $allowedFields) && !empty($value)) {
            $updates[] = "$key = ?";
            $params[] = $value;
        }
    }
    
    if (empty($updates)) {
        return false;
    }
    
    $params[] = $userId;
    $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE user_id = ?";
    
    $stmt = $conn->prepare($sql);
    return $stmt->execute($params);
}

// Change user password
function changePassword($userId, $currentPassword, $newPassword) {
    $user = getUserById($userId);
    
    if (!$user || !password_verify($currentPassword, $user['password'])) {
        return false;
    }

    $conn = 'getConnection'();
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
    return $stmt->execute([$hashedPassword, $userId]);
}

// Get equipment by ID
function getEquipmentById($equipmentId) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT e.*, c.category_name, l.lab_name, l.location 
                           FROM equipment e 
                           LEFT JOIN equipment_categories c ON e.category_id = c.category_id 
                           LEFT JOIN labs l ON e.lab_id = l.lab_id 
                           WHERE e.equipment_id = ?");
    $stmt->execute([$equipmentId]);
    return $stmt->fetch();
}

// Get all equipment
function getAllEquipment($limit = 100) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT e.*, c.category_name, l.lab_name 
                           FROM equipment e 
                           LEFT JOIN equipment_categories c ON e.category_id = c.category_id 
                           LEFT JOIN labs l ON e.lab_id = l.lab_id 
                           ORDER BY e.created_at DESC LIMIT ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get available equipment
function getAvailableEquipment() {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT e.*, c.category_name, l.lab_name 
                           FROM equipment e 
                           LEFT JOIN equipment_categories c ON e.category_id = c.category_id 
                           LEFT JOIN labs l ON e.lab_id = l.lab_id 
                           WHERE e.status = 'available' 
                           ORDER BY e.equipment_name");
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get labs
function getAllLabs() {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT * FROM labs WHERE status = 'active' ORDER BY lab_name");
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get lab by ID
function getLabById($labId) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT * FROM labs WHERE lab_id = ?");
    $stmt->execute([$labId]);
    return $stmt->fetch();
}

// Create equipment reservation
function createEquipmentReservation($userId, $equipmentId, $date, $startTime, $endTime, $purpose) {
    $conn = 'getConnection'();
    
    // Check if equipment is available
    $stmt = $conn->prepare("SELECT status FROM equipment WHERE equipment_id = ?");
    $stmt->execute([$equipmentId]);
    $equipment = $stmt->fetch();
    
    if (!$equipment || $equipment['status'] !== 'available') {
        return ['success' => false, 'message' => 'Equipment is not available for reservation'];
    }
    
    // Check for conflicting reservations
    $stmt = $conn->prepare("SELECT * FROM equipment_reservations 
                           WHERE equipment_id = ? AND reservation_date = ? 
                           AND ((start_time <= ? AND end_time >= ?) OR 
                                (start_time <= ? AND end_time >= ?)) 
                           AND status IN ('pending', 'approved')");
    $stmt->execute([$equipmentId, $date, $startTime, $startTime, $endTime, $endTime]);
    
    if ($stmt->rowCount() > 0) {
        return ['success' => false, 'message' => 'Time slot is already reserved'];
    }
    
    // Create reservation
    $stmt = $conn->prepare("INSERT INTO equipment_reservations 
                           (user_id, equipment_id, reservation_date, start_time, end_time, purpose) 
                           VALUES (?, ?, ?, ?, ?, ?)");
    
    try {
        $stmt->execute([$userId, $equipmentId, $date, $startTime, $endTime, $purpose]);
        $reservationId = $conn->lastInsertId();
        
        return ['success' => true, 'reservation_id' => $reservationId];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Failed to create reservation: ' . $e->getMessage()];
    }
}

// Get user reservations
function getUserReservations($userId, $limit = 50) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT r.*, e.equipment_name, e.equipment_code, 
                           CONCAT(u.first_name, ' ', u.last_name) as user_name 
                           FROM equipment_reservations r 
                           JOIN equipment e ON r.equipment_id = e.equipment_id 
                           JOIN users u ON r.user_id = u.user_id 
                           WHERE r.user_id = ? 
                           ORDER BY r.reservation_date DESC, r.start_time DESC 
                           LIMIT ?");
    $stmt->bindValue(1, $userId, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get pending reservations
function getPendingReservations() {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("SELECT r.*, e.equipment_name, e.equipment_code, 
                           CONCAT(u.first_name, ' ', u.last_name) as user_name, 
                           u.email as user_email 
                           FROM equipment_reservations r 
                           JOIN equipment e ON r.equipment_id = e.equipment_id 
                           JOIN users u ON r.user_id = u.user_id 
                           WHERE r.status = 'pending' 
                           ORDER BY r.reservation_date, r.start_time");
    $stmt->execute();
    return $stmt->fetchAll();
}

// Update reservation status
function updateReservationStatus($reservationId, $status, $approvedBy = null) {
    $conn = 'getConnection'();
    
    if ($status === 'approved') {
        $stmt = $conn->prepare("UPDATE equipment_reservations 
                               SET status = ?, approved_by = ?, approval_date = NOW() 
                               WHERE reservation_id = ?");
        return $stmt->execute([$status, $approvedBy, $reservationId]);
    } else {
        $stmt = $conn->prepare("UPDATE equipment_reservations 
                               SET status = ? 
                               WHERE reservation_id = ?");
        return $stmt->execute([$status, $reservationId]);
    }
}

// Get dashboard statistics
function getDashboardStats($userId = null, $role = null) {
    $conn = 'getConnection'();
    $stats = [];
    
    if ($role === 'admin') {
        // Admin stats
        $queries = [
            'total_users' => "SELECT COUNT(*) as count FROM users",
            'active_users' => "SELECT COUNT(*) as count FROM users WHERE status = 'active'",
            'total_labs' => "SELECT COUNT(*) as count FROM labs WHERE status = 'active'",
            'total_equipment' => "SELECT COUNT(*) as count FROM equipment",
            'available_equipment' => "SELECT COUNT(*) as count FROM equipment WHERE status = 'available'",
            'pending_reservations' => "SELECT COUNT(*) as count FROM equipment_reservations WHERE status = 'pending'",
            'pending_requests' => "SELECT COUNT(*) as count FROM resource_requests WHERE status = 'pending'",
            'today_sessions' => "SELECT COUNT(*) as count FROM lab_sessions WHERE session_date = CURDATE()"
        ];
        
        foreach ($queries as $key => $query) {
            $stmt = $conn->query($query);
            $result = $stmt->fetch();
            $stats[$key] = $result['count'];
        }
    } elseif ($userId) {
        // User stats
        $queries = [
            'total_reservations' => "SELECT COUNT(*) as count FROM equipment_reservations WHERE user_id = ? AND status = 'approved'",
            'pending_reservations' => "SELECT COUNT(*) as count FROM equipment_reservations WHERE user_id = ? AND status = 'pending'",
            'active_reservations' => "SELECT COUNT(*) as count FROM equipment_reservations WHERE user_id = ? AND status IN ('pending', 'approved')",
            'completed_reservations' => "SELECT COUNT(*) as count FROM equipment_reservations WHERE user_id = ? AND status = 'completed'"
        ];
        
        foreach ($queries as $key => $query) {
            $stmt = $conn->prepare($query);
            $stmt->execute([$userId]);
            $result = $stmt->fetch();
            $stats[$key] = $result['count'];
        }
    }
    
    return $stats;
}

// Upload file
function uploadFile($file, $type = 'profile') {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error'];
    }
    
    // Check file size
    if ($file['size'] > 'MAX_FILE_SIZE') {
        return ['success' => false, 'message' => 'File is too large'];
    }
    
    // Check file extension
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ('!in_array($ext, ALLOWED_EXTENSIONS)') {
        return ['success' => false, 'message' => 'File type not allowed'];
    }
    
    // Generate unique filename
    $filename = uniqid() . '_' . time() . '.' . $ext;
    
    // Determine upload directory
    $uploadDir = $type === 'profile' ? 'PROFILE_PICS_DIR' : 'REPORTS_DIR';
    
    // Create directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Move uploaded file
    $destination = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'filename' => $filename, 'path' => $destination];
    }
    
    return ['success' => false, 'message' => 'Failed to save file'];
}

// Send notification
function sendNotification($senderId, $recipientId, $title, $message, $type = 'info', $relatedId = null, $relatedType = null) {
    $conn = 'getConnection'();
    
    $stmt = $conn->prepare("INSERT INTO notifications 
                           (sender_id, recipient_id, title, message, type, related_id, related_type) 
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    try {
        $stmt->execute([$senderId, $recipientId, $title, $message, $type, $relatedId, $relatedType]);
        return true;
    } catch (PDOException $e) {
        error_log("Failed to send notification: " . $e->getMessage());
        return false;
    }
}

// Get user notifications
function getUserNotifications($userId, $limit = 20) {
    $conn = 'getConnection'();
    
    $stmt = $conn->prepare("SELECT n.*, CONCAT(u.first_name, ' ', u.last_name) as sender_name 
                           FROM notifications n 
                           LEFT JOIN users u ON n.sender_id = u.user_id 
                           WHERE n.recipient_id = ? OR n.recipient_role = 'all' 
                           ORDER BY n.created_at DESC 
                           LIMIT ?");
    $stmt->bindValue(1, $userId, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll();
}

// Mark notification as read
function markNotificationAsRead($notificationId) {
    $conn = 'getConnection'();
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE notification_id = ?");
    return $stmt->execute([$notificationId]);
}

// Search users
function searchUsers($searchTerm, $role = null) {
    $conn = 'getConnection'();
    
    $sql = "SELECT * FROM users WHERE 
            (username LIKE ? OR email LIKE ? OR first_name LIKE ? OR last_name LIKE ?)";
    
    $params = ["%$searchTerm%", "%$searchTerm%", "%$searchTerm%", "%$searchTerm%"];
    
    if ($role) {
        $sql .= " AND role = ?";
        $params[] = $role;
    }
    
    $sql .= " ORDER BY first_name, last_name LIMIT 50";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchAll();
}

// Generate report
function generateReport($type, $startDate = null, $endDate = null) {
    $conn = 'getConnection'();
    $report = [];
    
    switch ($type) {
        case 'reservations':
            $sql = "SELECT r.*, e.equipment_name, e.equipment_code, 
                   CONCAT(u.first_name, ' ', u.last_name) as user_name 
                   FROM equipment_reservations r 
                   JOIN equipment e ON r.equipment_id = e.equipment_id 
                   JOIN users u ON r.user_id = u.user_id 
                   WHERE 1=1";
            
            $params = [];
            
            if ($startDate) {
                $sql .= " AND r.reservation_date >= ?";
                $params[] = $startDate;
            }
            
            if ($endDate) {
                $sql .= " AND r.reservation_date <= ?";
                $params[] = $endDate;
            }
            
            $sql .= " ORDER BY r.reservation_date DESC";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            $report = $stmt->fetchAll();
            break;
            
        case 'users':
            $sql = "SELECT user_id, username, email, first_name, last_name, role, status, 
                   DATE(created_at) as join_date 
                   FROM users 
                   ORDER BY created_at DESC";
            
            $stmt = $conn->query($sql);
            $report = $stmt->fetchAll();
            break;
            
        case 'equipment':
            $sql = "SELECT e.*, c.category_name, l.lab_name, 
                   (SELECT COUNT(*) FROM equipment_reservations WHERE equipment_id = e.equipment_id) as total_reservations 
                   FROM equipment e 
                   LEFT JOIN equipment_categories c ON e.category_id = c.category_id 
                   LEFT JOIN labs l ON e.lab_id = l.lab_id 
                   ORDER BY e.equipment_name";
            
            $stmt = $conn->query($sql);
            $report = $stmt->fetchAll();
            break;
    }
    
    return $report;
}

// Sanitize input
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

// Redirect with message
function redirect($url, $type = null, $message = null) {
    if ($type && $message) {
        $_SESSION[$type] = $message;
    }
    header("Location: " . 'BASE_URL' . $url);
    exit();
}

// Get flash message
function getFlash($type) {
    if (isset($_SESSION[$type])) {
        $message = $_SESSION[$type];
        unset($_SESSION[$type]);
        return $message;
    }
    return null;
}

// Format date
function formatDate($date, $format = 'Y-m-d') {
    if (!$date) return '';
    $datetime = new DateTime($date);
    return $datetime->format($format);
}

// Format time
function formatTime($time, $format = 'H:i') {
    if (!$time) return '';
    $datetime = DateTime::createFromFormat('H:i:s', $time);
    return $datetime ? $datetime->format($format) : $time;
}

// Validate date
function isValidDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}
?>