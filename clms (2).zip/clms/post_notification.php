<?php
session_start();
require_once 'config.php';

// Check if admin or lab manager
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'lab_manager')) {
    header("Location: login.php");
    exit();
}

$message = "";

// Post notification
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_notification'])) {
    $title = $_POST['title'];
    $message_text = $_POST['message'];
    $priority = $_POST['priority'];
    $target_user = $_POST['target_user'];
    $expiry_date = $_POST['expiry_date'];
    
    // If specific user selected
    if ($target_user == 'specific') {
        $target_user = $_POST['specific_user'];
    }
    
    $sql = "INSERT INTO notifications (title, message, priority, target_user, expiry_date, created_by) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssi", $title, $message_text, $priority, 
                          $target_user, $expiry_date, $_SESSION['user_id']);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = "<div class='alert alert-success'>Notification posted successfully</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error posting notification</div>";
    }
}

// Get users for dropdown
$users_sql = "SELECT user_id, username, full_name FROM users ORDER BY full_name";
$users_result = mysqli_query($conn, $users_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Notification - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>Post Notification</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5>Create New Notification</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Title</label>
                                <input type="text" class="form-control" name="title" required maxlength="200">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Message</label>
                                <textarea class="form-control" id="message" name="message" rows="6" required></textarea>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Priority</label>
                                    <select class="form-select" name="priority" required>
                                        <option value="low">Low</option>
                                        <option value="medium">Medium</option>
                                        <option value="high">High</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Expiry Date</label>
                                    <input type="date" class="form-control" name="expiry_date" 
                                           value="<?php echo date('Y-m-d', strtotime('+7 days')); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Target Audience</label>
                                <div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="target_user" 
                                               id="all" value="all" checked onchange="toggleUserSelect()">
                                        <label class="form-check-label" for="all">All Users</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="target_user" 
                                               id="students" value="students" onchange="toggleUserSelect()">
                                        <label class="form-check-label" for="students">Students Only</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="target_user" 
                                               id="faculty" value="faculty" onchange="toggleUserSelect()">
                                        <label class="form-check-label" for="faculty">Faculty Only</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="target_user" 
                                               id="specific" value="specific" onchange="toggleUserSelect()">
                                        <label class="form-check-label" for="specific">Specific User</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3" id="userSelect" style="display: none;">
                                <label class="form-label">Select User</label>
                                <select class="form-select" name="specific_user">
                                    <option value="">Select User</option>
                                    <?php while ($user = mysqli_fetch_assoc($users_result)): ?>
                                    <option value="<?php echo $user['user_id']; ?>">
                                        <?php echo htmlspecialchars($user['full_name'] . ' (' . $user['username'] . ')'); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <button type="submit" name="post_notification" class="btn btn-primary">
                                <i class="fas fa-bell"></i> Post Notification
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Recent Notifications</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $recent_sql = "SELECT n.*, u.username as created_by_name 
                                      FROM notifications n 
                                      LEFT JOIN users u ON n.created_by = u.user_id 
                                      ORDER BY n.created_at DESC LIMIT 5";
                        $recent_result = mysqli_query($conn, $recent_sql);
                        ?>
                        
                        <div class="list-group">
                            <?php while ($notif = mysqli_fetch_assoc($recent_result)): ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($notif['title']); ?></h6>
                                    <small>
                                        <?php echo $notif['priority'] == 'high' ? 
                                            '<span class="badge bg-danger">High</span>' : ''; ?>
                                    </small>
                                </div>
                                <p class="mb-1 small"><?php echo htmlspecialchars(substr($notif['message'], 0, 80)); ?>...</p>
                                <small class="text-muted">
                                    To: <?php echo $notif['target_user']; ?> | 
                                    By: <?php echo $notif['created_by_name']; ?> |
                                    <?php echo date('M d', strtotime($notif['created_at'])); ?>
                                </small>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        
                        <div class="mt-3">
                            <a href="view_notifications.php" class="btn btn-outline-primary btn-sm">View All</a>
                        </div>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Guidelines</h5>
                    </div>
                    <div class="card-body">
                        <ul class="small">
                            <li>Use High priority only for urgent matters</li>
                            <li>Keep titles clear and concise</li>
                            <li>Include all necessary details in message</li>
                            <li>Set appropriate expiry dates</li>
                            <li>Choose correct target audience</li>
                            <li>Review before posting</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    CKEDITOR.replace('message', {
        toolbar: [
            ['Bold', 'Italic', 'Underline', 'Strike', 'NumberedList', 'BulletedList', 'Link']
        ],
        height: 200
    });
    
    function toggleUserSelect() {
        var specificRadio = document.getElementById('specific');
        var userSelect = document.getElementById('userSelect');
        
        if (specificRadio.checked) {
            userSelect.style.display = 'block';
        } else {
            userSelect.style.display = 'none';
        }
    }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>