<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$notification_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Get notification details
$sql = "SELECT n.*, u.username as created_by_name 
        FROM notifications n 
        LEFT JOIN users u ON n.created_by = u.user_id 
        WHERE n.notification_id = ? 
        AND (n.target_user = 'all' 
            OR n.target_user = ? 
            OR n.target_user = (SELECT role FROM users WHERE user_id = ?))";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "iii", $notification_id, $user_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    header("Location: notifications.php");
    exit();
}

$notification = mysqli_fetch_assoc($result);

// Mark as read
$read_sql = "INSERT INTO notification_reads (notification_id, user_id) 
             VALUES (?, ?) 
             ON DUPLICATE KEY UPDATE read_at = NOW()";
$read_stmt = mysqli_prepare($conn, $read_sql);
mysqli_stmt_bind_param($read_stmt, "ii", $notification_id, $user_id);
mysqli_stmt_execute($read_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Details - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="notifications.php">Notifications</a></li>
                <li class="breadcrumb-item active">Notification Details</li>
            </ol>
        </nav>
        
        <!-- Notification Card -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <?php if($notification['priority'] == 'high'): ?>
                    <span class="badge bg-danger me-2">High Priority</span>
                    <?php elseif($notification['priority'] == 'medium'): ?>
                    <span class="badge bg-warning me-2">Medium Priority</span>
                    <?php else: ?>
                    <span class="badge bg-info me-2">Low Priority</span>
                    <?php endif; ?>
                    
                    <?php 
                    $target_text = '';
                    switch($notification['target_user']) {
                        case 'all': $target_text = 'All Users'; break;
                        case 'students': $target_text = 'Students Only'; break;
                        case 'faculty': $target_text = 'Faculty Only'; break;
                        case 'lab_manager': $target_text = 'Lab Managers Only'; break;
                        default: $target_text = 'Specific User';
                    }
                    ?>
                    <span class="badge bg-secondary"><?php echo $target_text; ?></span>
                </div>
                
                <div class="text-muted">
                    <small>
                        <?php 
                        $created_time = strtotime($notification['created_at']);
                        $now = time();
                        $diff = $now - $created_time;
                        
                        if ($diff < 60) {
                            echo 'Just now';
                        } elseif ($diff < 3600) {
                            echo floor($diff / 60) . ' minutes ago';
                        } elseif ($diff < 86400) {
                            echo floor($diff / 3600) . ' hours ago';
                        } else {
                            echo date('M d, Y h:i A', $created_time);
                        }
                        ?>
                    </small>
                </div>
            </div>
            
            <div class="card-body">
                <h3 class="card-title mb-4"><?php echo htmlspecialchars($notification['title']); ?></h3>
                
                <div class="notification-meta mb-4">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-1">
                                <i class="fas fa-user me-2"></i>
                                <strong>Posted by:</strong> <?php echo htmlspecialchars($notification['created_by_name']); ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <?php if($notification['expiry_date']): ?>
                            <p class="mb-1">
                                <i class="fas fa-calendar-times me-2"></i>
                                <strong>Expires:</strong> 
                                <?php echo date('M d, Y', strtotime($notification['expiry_date'])); ?>
                                <?php 
                                $expiry = strtotime($notification['expiry_date']);
                                $today = strtotime(date('Y-m-d'));
                                if ($expiry < $today) {
                                    echo '<span class="badge bg-danger ms-2">Expired</span>';
                                }
                                ?>
                            </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <hr>
                
                <div class="notification-content">
                    <?php echo nl2br(htmlspecialchars($notification['message'])); ?>
                </div>
                
                <?php if($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'lab_manager'): ?>
                <hr>
                <div class="notification-stats mt-4">
                    <h5>Notification Statistics</h5>
                    <?php
                    // Get read count
                    $read_count_sql = "SELECT COUNT(*) as count FROM notification_reads 
                                       WHERE notification_id = ?";
                    $read_count_stmt = mysqli_prepare($conn, $read_count_sql);
                    mysqli_stmt_bind_param($read_count_stmt, "i", $notification_id);
                    mysqli_stmt_execute($read_count_stmt);
                    $read_count_result = mysqli_stmt_get_result($read_count_stmt);
                    $read_count = mysqli_fetch_assoc($read_count_result)['count'];
                    
                    // Get total users
                    $total_users_sql = "SELECT COUNT(*) as count FROM users";
                    $total_users_stmt = mysqli_prepare($conn, $total_users_sql);
                    mysqli_stmt_execute($total_users_stmt);
                    $total_users_result = mysqli_stmt_get_result($total_users_stmt);
                    $total_users = mysqli_fetch_assoc($total_users_result)['count'];
                    ?>
                    <div class="progress mb-2" style="height: 20px;">
                        <?php $read_percent = ($read_count / $total_users) * 100; ?>
                        <div class="progress-bar bg-success" style="width: <?php echo $read_percent; ?>%">
                            <?php echo round($read_percent); ?>%
                        </div>
                    </div>
                    <p class="text-muted">
                        Read by <?php echo $read_count; ?> of <?php echo $total_users; ?> users
                    </p>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="card-footer">
                <a href="notifications.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Notifications
                </a>
                
                <?php if($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'lab_manager'): ?>
                <a href="edit_notification.php?id=<?php echo $notification_id; ?>" 
                   class="btn btn-warning">
                   <i class="fas fa-edit"></i> Edit
                </a>
                <a href="delete_notification.php?id=<?php echo $notification_id; ?>" 
                   class="btn btn-danger"
                   onclick="return confirm('Delete this notification?')">
                   <i class="fas fa-trash"></i> Delete
                </a>
                <?php endif; ?>
                
                <button class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print"></i> Print
                </button>
            </div>
        </div>
        
        <!-- Related Notifications -->
        <div class="card mt-4">
            <div class="card-header">
                <h5>Recent Notifications</h5>
            </div>
            <div class="card-body">
                <?php
                $recent_sql = "SELECT n.*, 
                              (SELECT COUNT(*) FROM notification_reads nr 
                               WHERE nr.notification_id = n.notification_id 
                               AND nr.user_id = ?) as is_read
                              FROM notifications n 
                              WHERE (n.target_user = 'all' 
                                  OR n.target_user = ? 
                                  OR n.target_user = (SELECT role FROM users WHERE user_id = ?))
                              AND n.notification_id != ?
                              ORDER BY n.created_at DESC 
                              LIMIT 5";
                $recent_stmt = mysqli_prepare($conn, $recent_sql);
                mysqli_stmt_bind_param($recent_stmt, "iiii", $user_id, $user_id, $user_id, $notification_id);
                mysqli_stmt_execute($recent_stmt);
                $recent_result = mysqli_stmt_get_result($recent_stmt);
                ?>
                
                <div class="list-group">
                    <?php while($recent = mysqli_fetch_assoc($recent_result)): ?>
                    <a href="view_notification.php?id=<?php echo $recent['notification_id']; ?>" 
                       class="list-group-item list-group-item-action <?php echo $recent['is_read'] ? '' : 'list-group-item-primary'; ?>">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1"><?php echo htmlspecialchars($recent['title']); ?></h6>
                            <small>
                                <?php 
                                $time = strtotime($recent['created_at']);
                                $now = time();
                                $diff = $now - $time;
                                
                                if ($diff < 86400) {
                                    echo date('h:i A', $time);
                                } else {
                                    echo date('M d', $time);
                                }
                                ?>
                            </small>
                        </div>
                        <p class="mb-1 small text-muted">
                            <?php echo htmlspecialchars(substr($recent['message'], 0, 100)); ?>...
                        </p>
                        <small>
                            <?php if($recent['priority'] == 'high'): ?>
                            <span class="badge bg-danger">Important</span>
                            <?php endif; ?>
                            <?php if(!$recent['is_read']): ?>
                            <span class="badge bg-primary">New</span>
                            <?php endif; ?>
                        </small>
                    </a>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>