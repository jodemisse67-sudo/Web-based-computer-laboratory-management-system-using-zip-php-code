<?php
// Check if setup is already completed
if (file_exists(__DIR__ . '/setup_complete.flag')) {
    header('Location: index.php');
    exit();
}

$error = '';
$success = '';
$step = 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['step1'])) {
        // Step 1: Database connection test
        $host = $_POST['db_host'] ?? 'localhost';
        $user = $_POST['db_user'] ?? 'root';
        $pass = $_POST['db_pass'] ?? '';
        $name = $_POST['db_name'] ?? 'clms';
        
        try {
            $dsn = "mysql:host=$host;charset=utf8mb4";
            $pdo = new PDO($dsn, $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Try to create database
            $pdo->exec("CREATE DATABASE IF NOT EXISTS $name CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE $name");
            
            // Update config file
            $configContent = file_get_contents(__DIR__ . '/config/database.php');
            $configContent = preg_replace("/define\('DB_HOST', '.*?'\)/", "define('DB_HOST', '$host')", $configContent);
            $configContent = preg_replace("/define\('DB_USER', '.*?'\)/", "define('DB_USER', '$user')", $configContent);
            $configContent = preg_replace("/define\('DB_PASS', '.*?'\)/", "define('DB_PASS', '$pass')", $configContent);
            $configContent = preg_replace("/define\('DB_NAME', '.*?'\)/", "define('DB_NAME', '$name')", $configContent);
            
            file_put_contents(__DIR__ . '/config/database.php', $configContent);
            
            $_SESSION['db_config'] = compact('host', 'user', 'pass', 'name');
            $step = 2;
        } catch (PDOException $e) {
            $error = 'Database connection failed: ' . $e->getMessage();
        }
    } elseif (isset($_POST['step2'])) {
        // Step 2: Create tables
        require_once __DIR__ . '/config/database.php';
        
        try {
            $conn = 'getConnection'();
            
            // Run the database schema
            $sql = file_get_contents(__DIR__ . '/database/schema.sql');
            $conn->exec($sql);
            
            // Create admin user
            $password = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, first_name, last_name, role) 
                                   VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute(['admin', 'admin@wcu.edu.et', $password, 'System', 'Administrator', 'admin']);
            
            // Create setup complete flag
            file_put_contents(__DIR__ . '/setup_complete.flag', date('Y-m-d H:i:s'));
            
            $success = 'Setup completed successfully!';
            $step = 3;
        } catch (PDOException $e) {
            $error = 'Failed to setup database: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="setup-page">
    <div class="setup-container">
        <div class="setup-header">
            <h1><i class="fas fa-cogs"></i> System Setup</h1>
            <p>Wachemo University Computer Lab Management System</p>
            
            <div class="setup-steps">
                <div class="step <?php echo $step >= 1 ? 'active' : ''; ?>">
                    <div class="step-number">1</div>
                    <div class="step-label">Database</div>
                </div>
                <div class="step <?php echo $step >= 2 ? 'active' : ''; ?>">
                    <div class="step-number">2</div>
                    <div class="step-label">Tables</div>
                </div>
                <div class="step <?php echo $step >= 3 ? 'active' : ''; ?>">
                    <div class="step-number">3</div>
                    <div class="step-label">Complete</div>
                </div>
            </div>
        </div>
        
        <div class="setup-content">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
                <form method="POST" action="">
                    <h2>Database Configuration</h2>
                    <p>Please enter your database connection details:</p>
                    
                    <div class="form-group">
                        <label for="db_host">Database Host</label>
                        <input type="text" id="db_host" name="db_host" value="localhost" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_user">Database Username</label>
                        <input type="text" id="db_user" name="db_user" value="root" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_pass">Database Password</label>
                        <input type="password" id="db_pass" name="db_pass">
                    </div>
                    
                    <div class="form-group">
                        <label for="db_name">Database Name</label>
                        <input type="text" id="db_name" name="db_name" value="clms" required>
                    </div>
                    
                    <button type="submit" name="step1" class="btn btn-primary">
                        <i class="fas fa-arrow-right"></i> Continue
                    </button>
                </form>
                
            <?php elseif ($step == 2): ?>
                <form method="POST" action="">
                    <h2>Create Database Tables</h2>
                    <p>Click the button below to create the necessary database tables:</p>
                    
                    <div class="setup-info">
                        <h3><i class="fas fa-database"></i> Database Information</h3>
                        <table class="setup-table">
                            <tr>
                                <th>Host:</th>
                                <td><?php echo htmlspecialchars($_SESSION['db_config']['host']); ?></td>
                            </tr>
                            <tr>
                                <th>Database:</th>
                                <td><?php echo htmlspecialchars($_SESSION['db_config']['name']); ?></td>
                            </tr>
                            <tr>
                                <th>Username:</th>
                                <td><?php echo htmlspecialchars($_SESSION['db_config']['user']); ?></td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="setup-warning">
                        <h4><i class="fas fa-exclamation-triangle"></i> Important</h4>
                        <p>This will create all necessary tables and add a default admin user (admin/admin123).</p>
                    </div>
                    
                    <button type="submit" name="step2" class="btn btn-primary">
                        <i class="fas fa-database"></i> Create Tables
                    </button>
                </form>
                
            <?php elseif ($step == 3): ?>
                <div class="setup-complete">
                    <h2><i class="fas fa-check-circle text-success"></i> Setup Complete!</h2>
                    
                    <div class="success-message">
                        <p>The system has been successfully configured.</p>
                        
                        <div class="credentials">
                            <h3>Default Admin Credentials:</h3>
                            <table class="credentials-table">
                                <tr>
                                    <th>Username:</th>
                                    <td>admin</td>
                                </tr>
                                <tr>
                                    <th>Password:</th>
                                    <td>admin123</td>
                                </tr>
                                <tr>
                                    <th>Email:</th>
                                    <td>admin@wcu.edu.et</td>
                                </tr>
                            </table>
                            
                            <div class="warning">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>Important:</strong> Change the default password after first login!
                            </div>
                        </div>
                        
                        <div class="next-steps">
                            <h3>Next Steps:</h3>
                            <ol>
                                <li>Login with the admin credentials</li>
                                <li>Change the default admin password</li>
                                <li>Add departments and laboratories</li>
                                <li>Add equipment and courses</li>
                                <li>Create user accounts</li>
                            </ol>
                        </div>
                        
                        <div class="setup-actions">
                            <a href="login.php" class="btn btn-primary btn-large">
                                <i class="fas fa-sign-in-alt"></i> Go to Login
                            </a>
                            <a href="index.php" class="btn btn-outline btn-large">
                                <i class="fas fa-home"></i> Go to Homepage
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="setup-footer">
            <p>Wachemo University Durame Campus &copy; <?php echo date('Y'); ?></p>
        </div>
    </div>
    
    <style>
        .setup-page {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        
        .setup-container {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            max-width: 800px;
            width: 100%;
            overflow: hidden;
        }
        
        .setup-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        
        .setup-header h1 {
            color: white;
            margin-bottom: 0.5rem;
        }
        
        .setup-steps {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 2rem;
        }
        
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
        }
        
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .step.active .step-number {
            background: white;
            color: var(--primary-color);
        }
        
        .step-label {
            font-size: 0.875rem;
            opacity: 0.8;
        }
        
        .setup-content {
            padding: 3rem;
        }
        
        .setup-info {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
        }
        
        .setup-table {
            width: 100%;
        }
        
        .setup-table th {
            text-align: left;
            padding: 8px;
            width: 120px;
        }
        
        .setup-table td {
            padding: 8px;
        }
        
        .setup-warning {
            background: rgba(243, 156, 18, 0.1);
            border: 1px solid var(--warning-color);
            border-radius: var(--border-radius);
            padding: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .setup-complete {
            text-align: center;
        }
        
        .credentials {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin: 2rem 0;
        }
        
        .credentials-table {
            width: 100%;
            max-width: 400px;
            margin: 1rem auto;
        }
        
        .warning {
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid var(--danger-color);
            border-radius: var(--border-radius);
            padding: 1rem;
            margin-top: 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .next-steps {
            text-align: left;
            max-width: 500px;
            margin: 2rem auto;
        }
        
        .next-steps ol {
            padding-left: 1.5rem;
        }
        
        .setup-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }
        
        .setup-footer {
            padding: 1rem;
            text-align: center;
            border-top: 1px solid var(--border-color);
            color: var(--gray-color);
        }
        
        @media (max-width: 768px) {
            .setup-content {
                padding: 2rem 1rem;
            }
            
            .setup-steps {
                gap: 1rem;
            }
            
            .setup-actions {
                flex-direction: column;
            }
        }
    </style>
</body>
</html>