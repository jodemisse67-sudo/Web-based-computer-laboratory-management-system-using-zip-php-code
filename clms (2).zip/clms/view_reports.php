<?php
session_start();
require_once 'config.php';

// Check if admin or lab manager
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'lab_manager')) {
    header("Location: login.php");
    exit();
}

// Get saved reports
$reports_sql = "SELECT * FROM saved_reports 
                WHERE created_by = ? OR is_public = 1 
                ORDER BY created_at DESC";
$reports_stmt = mysqli_prepare($conn, $reports_sql);
mysqli_stmt_bind_param($reports_stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($reports_stmt);
$reports_result = mysqli_stmt_get_result($reports_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reports - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Saved Reports</h2>
            <div>
                <a href="generate_reports.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Generate New Report
                </a>
            </div>
        </div>
        
        <!-- Reports Grid -->
        <div class="row">
            <?php while($report = mysqli_fetch_assoc($reports_result)): 
                $report_data = json_decode($report['report_data'], true);
            ?>
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><?php echo htmlspecialchars($report['report_name']); ?></h5>
                        <div>
                            <?php if($report['is_public']): ?>
                                <span class="badge bg-success">Public</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Private</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <strong>Type:</strong> <?php echo ucfirst(str_replace('_', ' ', $report['report_type'])); ?><br>
                            <strong>Period:</strong> <?php echo date('M d, Y', strtotime($report['start_date'])); ?> 
                            to <?php echo date('M d, Y', strtotime($report['end_date'])); ?><br>
                            <strong>Generated:</strong> <?php echo date('M d, Y h:i A', strtotime($report['created_at'])); ?>
                        </p>
                        
                        <?php if($report['report_type'] == 'lab_utilization' && !empty($report_data)): ?>
                        <div class="mb-3">
                            <canvas id="chart_<?php echo $report['report_id']; ?>" height="150"></canvas>
                        </div>
                        <?php endif; ?>
                        
                        <div class="mt-3">
                            <a href="download_report.php?id=<?php echo $report['report_id']; ?>" 
                               class="btn btn-sm btn-outline-primary">
                               <i class="fas fa-download"></i> Download
                            </a>
                            <a href="view_report_details.php?id=<?php echo $report['report_id']; ?>" 
                               class="btn btn-sm btn-outline-info">
                               <i class="fas fa-eye"></i> View Details
                            </a>
                            <?php if($report['created_by'] == $_SESSION['user_id']): ?>
                            <a href="delete_report.php?id=<?php echo $report['report_id']; ?>" 
                               class="btn btn-sm btn-outline-danger"
                               onclick="return confirm('Delete this report?')">
                               <i class="fas fa-trash"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php if($report['report_type'] == 'lab_utilization' && !empty($report_data)): ?>
            <script>
            // Generate chart for lab utilization report
            var ctx_<?php echo $report['report_id']; ?> = document.getElementById('chart_<?php echo $report['report_id']; ?>').getContext('2d');
            var labels = <?php echo json_encode(array_column($report_data, 'lab_name')); ?>;
            var data = <?php echo json_encode(array_column($report_data, 'total_reservations')); ?>;
            
            new Chart(ctx_<?php echo $report['report_id']; ?>, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Reservations',
                        data: data,
                        backgroundColor: 'rgba(54, 162, 235, 0.5)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    }
                }
            });
            </script>
            <?php endif; ?>
            
            <?php endwhile; ?>
        </div>
        
        <?php if(mysqli_num_rows($reports_result) == 0): ?>
        <div class="alert alert-info">
            <h5>No saved reports found</h5>
            <p>Generate your first report to get started.</p>
            <a href="generate_reports.php" class="btn btn-primary">Generate Report</a>
        </div>
        <?php endif; ?>
        
        <!-- Report Categories -->
        <div class="row mt-5">
            <div class="col-12">
                <h4>Report Categories</h4>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-chart-bar fa-3x text-primary mb-3"></i>
                        <h5>Usage Reports</h5>
                        <p class="text-muted">Lab utilization and reservation patterns</p>
                        <a href="generate_reports.php?type=lab_utilization" class="btn btn-sm btn-outline-primary">View</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-users fa-3x text-success mb-3"></i>
                        <h5>User Reports</h5>
                        <p class="text-muted">User activity and engagement</p>
                        <a href="generate_reports.php?type=user_activity" class="btn btn-sm btn-outline-success">View</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-desktop fa-3x text-warning mb-3"></i>
                        <h5>Equipment Reports</h5>
                        <p class="text-muted">Equipment status and maintenance</p>
                        <a href="generate_reports.php?type=equipment_status" class="btn btn-sm btn-outline-warning">View</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-calendar-alt fa-3x text-info mb-3"></i>
                        <h5>Booking Reports</h5>
                        <p class="text-muted">Reservation summaries and trends</p>
                        <a href="generate_reports.php?type=reservation_summary" class="btn btn-sm btn-outline-info">View</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>