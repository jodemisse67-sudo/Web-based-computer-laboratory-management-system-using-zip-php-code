<?php
session_start();
require_once 'config.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$message = "";
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

// Approve reservation
if (isset($_GET['approve'])) {
    $reservation_id = $_GET['approve'];
    
    // Check for conflicts before approving
    $check_sql = "SELECT r.*, l.lab_name FROM reservations r 
                  JOIN labs l ON r.lab_id = l.lab_id 
                  WHERE r.reservation_id = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "i", $reservation_id);
    mysqli_stmt_execute($check_stmt);
    $reservation = mysqli_fetch_assoc(mysqli_stmt_get_result($check_stmt));
    
    $conflict_sql = "SELECT * FROM reservations 
                     WHERE lab_id = ? 
                     AND reservation_date = ? 
                     AND status = 'approved'
                     AND ((start_time < ? AND end_time > ?) 
                         OR (start_time >= ? AND start_time < ?))";
    $conflict_stmt = mysqli_prepare($conn, $conflict_sql);
    mysqli_stmt_bind_param($conflict_stmt, "isssss", 
        $reservation['lab_id'],
        $reservation['reservation_date'],
        $reservation['end_time'],
        $reservation['start_time'],
        $reservation['start_time'],
        $reservation['end_time']
    );
    mysqli_stmt_execute($conflict_stmt);
    $conflict_result = mysqli_stmt_get_result($conflict_stmt);
    
    if (mysqli_num_rows($conflict_result) > 0) {
        $message = "<div class='alert alert-danger'>Time conflict with existing reservation</div>";
    } else {
        $approve_sql = "UPDATE reservations SET status = 'approved' WHERE reservation_id = ?";
        $approve_stmt = mysqli_prepare($conn, $approve_sql);
        mysqli_stmt_bind_param($approve_stmt, "i", $reservation_id);
        
        if (mysqli_stmt_execute($approve_stmt)) {
            $message = "<div class='alert alert-success'>Reservation approved</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error approving reservation</div>";
        }
    }
}

// Reject reservation
if (isset($_GET['reject'])) {
    $reservation_id = $_GET['reject'];
    $reject_sql = "UPDATE reservations SET status = 'rejected' WHERE reservation_id = ?";
    $reject_stmt = mysqli_prepare($conn, $reject_sql);
    mysqli_stmt_bind_param($reject_stmt, "i", $reservation_id);
    
    if (mysqli_stmt_execute($reject_stmt)) {
        $message = "<div class='alert alert-success'>Reservation rejected</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error rejecting reservation</div>";
    }
}

// Build query based on filter
$sql = "SELECT r.*, u.username, u.email, l.lab_name 
        FROM reservations r 
        JOIN users u ON r.user_id = u.user_id 
        JOIN labs l ON r.lab_id = l.lab_id ";
        
if ($status_filter != 'all') {
    $sql .= "WHERE r.status = ? ";
    $sql .= "ORDER BY r.reservation_date DESC, r.start_time DESC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $status_filter);
} else {
    $sql .= "ORDER BY r.reservation_date DESC, r.start_time DESC";
    $stmt = mysqli_prepare($conn, $sql);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reservations - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>Manage Reservations</h2>
        
        <?php echo $message; ?>
        
        <!-- Filter -->
        <div class="mb-3">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                </div>
            </form>
        </div>
        
        <!-- Reservations Table -->
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Lab</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Purpose</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $row['reservation_id']; ?></td>
                                <td><?php echo htmlspecialchars($row['username']); ?><br>
                                    <small><?php echo htmlspecialchars($row['email']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($row['lab_name']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($row['reservation_date'])); ?></td>
                                <td><?php echo date('g:i A', strtotime($row['start_time'])); ?> - 
                                    <?php echo date('g:i A', strtotime($row['end_time'])); ?></td>
                                <td><?php echo htmlspecialchars(substr($row['purpose'], 0, 50)); ?></td>
                                <td>
                                    <?php 
                                    $status_class = [
                                        'pending' => 'warning',
                                        'approved' => 'success',
                                        'cancelled' => 'secondary',
                                        'rejected' => 'danger'
                                    ];
                                    ?>
                                    <span class="badge bg-<?php echo $status_class[$row['status']]; ?>">
                                        <?php echo ucfirst($row['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($row['status'] == 'pending'): ?>
                                    <a href="?approve=<?php echo $row['reservation_id']; ?>" 
                                       class="btn btn-sm btn-success" title="Approve">
                                       <i class="fas fa-check"></i>
                                    </a>
                                    <a href="?reject=<?php echo $row['reservation_id']; ?>" 
                                       class="btn btn-sm btn-danger" title="Reject">
                                       <i class="fas fa-times"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <a href="view_reservation.php?id=<?php echo $row['reservation_id']; ?>" 
                                       class="btn btn-sm btn-info" title="View Details">
                                       <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>