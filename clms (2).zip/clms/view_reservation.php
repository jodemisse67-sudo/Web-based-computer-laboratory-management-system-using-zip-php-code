<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$reservation_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Get reservation details
$sql = "SELECT r.*, l.lab_name, l.capacity, u.full_name, u.email, u.phone, 
               l.equipment as lab_equipment
        FROM reservations r
        JOIN labs l ON r.lab_id = l.lab_id
        JOIN users u ON r.user_id = u.user_id
        WHERE r.reservation_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $reservation_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    header("Location: dashboard.php");
    exit();
}

$reservation = mysqli_fetch_assoc($result);

// Check if user has permission to view
if ($_SESSION['role'] != 'admin' && $reservation['user_id'] != $user_id) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reservation - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="my_reservations.php">My Reservations</a></li>
                <li class="breadcrumb-item active">Reservation Details</li>
            </ol>
        </nav>
        
        <h2>Reservation Details</h2>
        
        <div class="row">
            <!-- Reservation Info -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Reservation Information</h5>
                        <span class="badge bg-<?php 
                            switch($reservation['status']) {
                                case 'approved': echo 'success'; break;
                                case 'pending': echo 'warning'; break;
                                case 'cancelled': echo 'secondary'; break;
                                case 'rejected': echo 'danger'; break;
                                default: echo 'primary';
                            }
                        ?>">
                            <?php echo ucfirst($reservation['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <th width="30%">Reservation ID</th>
                                <td><?php echo $reservation['reservation_id']; ?></td>
                            </tr>
                            <tr>
                                <th>Lab</th>
                                <td><?php echo htmlspecialchars($reservation['lab_name']); ?></td>
                            </tr>
                            <tr>
                                <th>Date</th>
                                <td><?php echo date('F d, Y', strtotime($reservation['reservation_date'])); ?></td>
                            </tr>
                            <tr>
                                <th>Time Slot</th>
                                <td>
                                    <?php echo date('g:i A', strtotime($reservation['start_time'])); ?> - 
                                    <?php echo date('g:i A', strtotime($reservation['end_time'])); ?>
                                    (<?php 
                                        $start = strtotime($reservation['start_time']);
                                        $end = strtotime($reservation['end_time']);
                                        $hours = ($end - $start) / 3600;
                                        echo $hours . ' hour' . ($hours > 1 ? 's' : '');
                                    ?>)
                                </td>
                            </tr>
                            <tr>
                                <th>User</th>
                                <td>
                                    <?php echo htmlspecialchars($reservation['full_name']); ?><br>
                                    <small><?php echo htmlspecialchars($reservation['email']); ?></small>
                                </td>
                            </tr>
                            <tr>
                                <th>Purpose</th>
                                <td><?php echo nl2br(htmlspecialchars($reservation['purpose'])); ?></td>
                            </tr>
                            <tr>
                                <th>Created On</th>
                                <td><?php echo date('F d, Y h:i A', strtotime($reservation['created_at'])); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="card-footer">
                        <?php if ($_SESSION['role'] == 'admin' && $reservation['status'] == 'pending'): ?>
                        <a href="manage_reservation.php?approve=<?php echo $reservation_id; ?>" 
                           class="btn btn-success">Approve</a>
                        <a href="manage_reservation.php?reject=<?php echo $reservation_id; ?>" 
                           class="btn btn-danger">Reject</a>
                        <?php endif; ?>
                        
                        <?php if ($reservation['user_id'] == $user_id && $reservation['status'] == 'pending'): ?>
                        <a href="cancel_reservation.php?id=<?php echo $reservation_id; ?>" 
                           class="btn btn-warning"
                           onclick="return confirm('Cancel this reservation?')">Cancel</a>
                        <?php endif; ?>
                        
                        <?php if ($_SESSION['role'] == 'admin'): ?>
                        <a href="edit_reservation.php?id=<?php echo $reservation_id; ?>" 
                           class="btn btn-info">Edit</a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Lab Equipment -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Lab Equipment</h5>
                    </div>
                    <div class="card-body">
                        <p><?php echo nl2br(htmlspecialchars($reservation['lab_equipment'])); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="col-md-4">
                <!-- Lab Capacity -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Lab Capacity</h5>
                    </div>
                    <div class="card-body">
                        <div class="progress mb-2" style="height: 20px;">
                            <?php
                            // Get today's reservations for this lab
                            $today_sql = "SELECT COUNT(*) as count FROM reservations 
                                         WHERE lab_id = ? 
                                         AND reservation_date = ? 
                                         AND status = 'approved'";
                            $today_stmt = mysqli_prepare($conn, $today_sql);
                            mysqli_stmt_bind_param($today_stmt, "is", $reservation['lab_id'], $reservation['reservation_date']);
                            mysqli_stmt_execute($today_stmt);
                            $today_result = mysqli_stmt_get_result($today_stmt);
                            $today_count = mysqli_fetch_assoc($today_result)['count'];
                            
                            $percent = ($today_count / $reservation['capacity']) * 100;
                            ?>
                            <div class="progress-bar bg-<?php echo $percent > 80 ? 'danger' : ($percent > 50 ? 'warning' : 'success'); ?>" 
                                 style="width: <?php echo $percent; ?>%">
                                <?php echo round($percent); ?>%
                            </div>
                        </div>
                        <p class="mb-0">
                            <strong><?php echo $today_count; ?></strong> of 
                            <strong><?php echo $reservation['capacity']; ?></strong> seats booked today
                        </p>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <a href="make_reservation.php?lab_id=<?php echo $reservation['lab_id']; ?>" 
                           class="btn btn-primary w-100 mb-2">
                           <i class="fas fa-plus"></i> Book Same Lab Again
                        </a>
                        
                        <?php if ($reservation['status'] == 'approved'): ?>
                        <button class="btn btn-success w-100 mb-2" onclick="printReservation()">
                            <i class="fas fa-print"></i> Print Confirmation
                        </button>
                        <?php endif; ?>
                        
                        <a href="contact_support.php?reservation_id=<?php echo $reservation_id; ?>" 
                           class="btn btn-info w-100 mb-2">
                           <i class="fas fa-question-circle"></i> Get Help
                        </a>
                    </div>
                </div>
                
                <!-- Status Legend -->
                <div class="card">
                    <div class="card-header">
                        <h5>Status Legend</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <span class="badge bg-success me-2">&nbsp;</span> Approved
                            </li>
                            <li class="mb-2">
                                <span class="badge bg-warning me-2">&nbsp;</span> Pending
                            </li>
                            <li class="mb-2">
                                <span class="badge bg-secondary me-2">&nbsp;</span> Cancelled
                            </li>
                            <li class="mb-2">
                                <span class="badge bg-danger me-2">&nbsp;</span> Rejected
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function printReservation() {
        var printContent = `
            <html>
            <head>
                <title>Reservation Confirmation</title>
                <style>
                    body { font-family: Arial, sans-serif; }
                    .header { text-align: center; margin-bottom: 30px; }
                    .details { width: 100%; border-collapse: collapse; }
                    .details th, .details td { 
                        border: 1px solid #ddd; 
                        padding: 8px; 
                        text-align: left; 
                    }
                    .footer { margin-top: 30px; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h2>Reservation Confirmation</h2>
                    <h3>Computer Lab Management System</h3>
                </div>
                
                <table class="details">
                    <tr>
                        <th>Reservation ID:</th>
                        <td><?php echo $reservation['reservation_id']; ?></td>
                    </tr>
                    <tr>
                        <th>Lab:</th>
                        <td><?php echo htmlspecialchars($reservation['lab_name']); ?></td>
                    </tr>
                    <tr>
                        <th>Date:</th>
                        <td><?php echo date('F d, Y', strtotime($reservation['reservation_date'])); ?></td>
                    </tr>
                    <tr>
                        <th>Time:</th>
                        <td><?php echo date('g:i A', strtotime($reservation['start_time'])); ?> - <?php echo date('g:i A', strtotime($reservation['end_time'])); ?></td>
                    </tr>
                    <tr>
                        <th>User:</th>
                        <td><?php echo htmlspecialchars($reservation['full_name']); ?></td>
                    </tr>
                    <tr>
                        <th>Purpose:</th>
                        <td><?php echo htmlspecialchars($reservation['purpose']); ?></td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td><?php echo ucfirst($reservation['status']); ?></td>
                    </tr>
                </table>
                
                <div class="footer">
                    <p>Generated on: <?php echo date('F d, Y h:i A'); ?></p>
                    <p>This is a computer-generated document. No signature required.</p>
                </div>
            </body>
            </html>
        `;
        
        var printWindow = window.open('', '_blank');
        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.print();
    }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>