<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

// Require admin role
requireRole('admin');

$conn = 'getConnection'();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_lab'])) {
        $lab_name = sanitize($_POST['lab_name']);
        $lab_code = sanitize($_POST['lab_code']);
        $location = sanitize($_POST['location']);
        $capacity = $_POST['capacity'];
        $description = sanitize($_POST['description']);
        $status = $_POST['status'];
        
        $stmt = $conn->prepare("INSERT INTO labs (lab_name, lab_code, location, capacity, description, status) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$lab_name, $lab_code, $location, $capacity, $description, $status])) {
            $_SESSION['success'] = 'Laboratory added successfully';
        } else {
            $_SESSION['error'] = 'Failed to add laboratory';
        }
    }
    
    if (isset($_POST['update_lab'])) {
        $lab_id = $_POST['lab_id'];
        $lab_name = sanitize($_POST['lab_name']);
        $lab_code = sanitize($_POST['lab_code']);
        $location = sanitize($_POST['location']);
        $capacity = $_POST['capacity'];
        $description = sanitize($_POST['description']);
        $status = $_POST['status'];
        
        $stmt = $conn->prepare("UPDATE labs SET lab_name = ?, lab_code = ?, location = ?, 
                               capacity = ?, description = ?, status = ? WHERE lab_id = ?");
        if ($stmt->execute([$lab_name, $lab_code, $location, $capacity, $description, $status, $lab_id])) {
            $_SESSION['success'] = 'Laboratory updated successfully';
        } else {
            $_SESSION['error'] = 'Failed to update laboratory';
        }
    }
    
    if (isset($_POST['delete_lab'])) {
        $lab_id = $_POST['lab_id'];
        
        $stmt = $conn->prepare("DELETE FROM labs WHERE lab_id = ?");
        if ($stmt->execute([$lab_id])) {
            $_SESSION['success'] = 'Laboratory deleted successfully';
        } else {
            $_SESSION['error'] = 'Failed to delete laboratory';
        }
    }
    
    // Redirect to prevent form resubmission
    header('Location: manage_labs.php');
    exit();
}

// Get all labs
$labs = getAllLabs();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Laboratories - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="dashboard-content">
            <div class="dashboard-header">
                <h1><i class="fas fa-building"></i> Manage Laboratories</h1>
            </div>
            
            <?php $message = getFlash('success'); if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php $error = getFlash('error'); if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="dashboard-grid">
                <!-- Add/Edit Lab Form -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><?php echo isset($_GET['edit']) ? 'Edit' : 'Add New'; ?> Laboratory</h3>
                    </div>
                    <div class="card-body">
                        <?php
                        $edit_lab = null;
                        if (isset($_GET['edit'])) {
                            $stmt = $conn->prepare("SELECT * FROM labs WHERE lab_id = ?");
                            $stmt->execute([$_GET['edit']]);
                            $edit_lab = $stmt->fetch();
                        }
                        ?>
                        
                        <form method="POST" action="">
                            <?php if ($edit_lab): ?>
                                <input type="hidden" name="lab_id" value="<?php echo $edit_lab['lab_id']; ?>">
                                <input type="hidden" name="update_lab" value="1">
                            <?php else: ?>
                                <input type="hidden" name="add_lab" value="1">
                            <?php endif; ?>
                            
                            <div class="form-group">
                                <label for="lab_name">Laboratory Name *</label>
                                <input type="text" id="lab_name" name="lab_name" 
                                       value="<?php echo $edit_lab ? htmlspecialchars($edit_lab['lab_name']) : ''; ?>" 
                                       required class="form-control">
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="lab_code">Laboratory Code *</label>
                                    <input type="text" id="lab_code" name="lab_code" 
                                           value="<?php echo $edit_lab ? htmlspecialchars($edit_lab['lab_code']) : ''; ?>" 
                                           required class="form-control">
                                </div>
                                
                                <div class="form-group">
                                    <label for="capacity">Capacity *</label>
                                    <input type="number" id="capacity" name="capacity" 
                                           value="<?php echo $edit_lab ? $edit_lab['capacity'] : '30'; ?>" 
                                           min="1" required class="form-control">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="location">Location</label>
                                <input type="text" id="location" name="location" 
                                       value="<?php echo $edit_lab ? htmlspecialchars($edit_lab['location']) : ''; ?>" 
                                       class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select id="status" name="status" class="form-control" required>
                                    <option value="active" <?php echo ($edit_lab && $edit_lab['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                                    <option value="maintenance" <?php echo ($edit_lab && $edit_lab['status'] == 'maintenance') ? 'selected' : ''; ?>>Maintenance</option>
                                    <option value="inactive" <?php echo ($edit_lab && $edit_lab['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea id="description" name="description" rows="3" class="form-control"><?php echo $edit_lab ? htmlspecialchars($edit_lab['description']) : ''; ?></textarea>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> 
                                    <?php echo $edit_lab ? 'Update' : 'Add'; ?> Laboratory
                                </button>
                                
                                <?php if ($edit_lab): ?>
                                    <a href="manage_labs.php" class="btn btn-outline">
                                        <i class="fas fa-times"></i> Cancel
                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Labs List -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3>All Laboratories</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Name</th>
                                        <th>Location</th>
                                        <th>Capacity</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($labs as $lab): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($lab['lab_code']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($lab['lab_name']); ?></td>
                                        <td><?php echo htmlspecialchars($lab['location']); ?></td>
                                        <td><?php echo $lab['capacity']; ?></td>
                                        <td>
                                            <?php
                                            $statusClass = [
                                                'active' => 'success',
                                                'maintenance' => 'warning',
                                                'inactive' => 'danger'
                                            ][$lab['status']] ?? 'secondary';
                                            ?>
                                            <span class="badge badge-<?php echo $statusClass; ?>">
                                                <?php echo ucfirst($lab['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="manage_labs.php?edit=<?php echo $lab['lab_id']; ?>" 
                                                   class="btn btn-sm btn-info" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="POST" style="display: inline;" 
                                                      onsubmit="return confirm('Are you sure you want to delete this laboratory?');">
                                                    <input type="hidden" name="lab_id" value="<?php echo $lab['lab_id']; ?>">
                                                    <button type="submit" name="delete_lab" class="btn btn-sm btn-danger" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <style>
        .form-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
    </style>
</body>
</html>