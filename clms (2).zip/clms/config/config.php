<?php
// ============================================
// COMPUTER LAB MANAGEMENT SYSTEM
// Wachemo University - Complete Database Setup
// ============================================

// Start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================
// DATABASE CONFIGURATION
// ============================================

// Database settings
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'clms_db');

// Site Information
define('SITE_NAME', 'Wachemo University - Computer Lab Management');
define('SITE_SHORT_NAME', 'CLMS');
define('BASE_URL', 'http://localhost/clms');

// User Roles
define('ROLE_ADMIN', 'admin');
define('ROLE_FACULTY', 'faculty');
define('ROLE_STUDENT', 'student');
define('ROLE_TECHNICIAN', 'technician');

// ============================================
// DATABASE CONNECTION
// ============================================

// Try to connect to database
try {
    // Create database connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
    
    // Check connection
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
    
    // Create database if it doesn't exist
    $create_db = "CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if ($conn->query($create_db) === TRUE) {
        // Select the database
        $conn->select_db(DB_NAME);
        
        // Create tables
        create_database_tables($conn);
        
        // Insert default data
        insert_default_data($conn);
        
    } else {
        die("Error creating database: " . $conn->error);
    }
    
    // Set charset
    $conn->set_charset("utf8mb4");
    
} catch (Exception $e) {
    die("Database setup error: " . $e->getMessage());
}

// ============================================
// TABLE CREATION FUNCTIONS
// ============================================

/**
 * Create all database tables
 */
function create_database_tables($conn) {
    
    // 1. USERS TABLE (Simplified - removed department column for now)
    $users_table = "CREATE TABLE IF NOT EXISTS users (
        user_id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        phone VARCHAR(20),
        role ENUM('admin', 'faculty', 'student', 'technician') DEFAULT 'student',
        profile_pic VARCHAR(255) DEFAULT 'default.png',
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    // 2. DEPARTMENTS TABLE
    $departments_table = "CREATE TABLE IF NOT EXISTS departments (
        dept_id INT PRIMARY KEY AUTO_INCREMENT,
        dept_name VARCHAR(100) NOT NULL,
        dept_code VARCHAR(10) UNIQUE NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // 3. USER_DEPARTMENTS TABLE (Linking users to departments)
    $user_dept_table = "CREATE TABLE IF NOT EXISTS user_departments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        dept_id INT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE CASCADE,
        UNIQUE KEY unique_user_dept (user_id, dept_id)
    )";
    
    // 4. LABS TABLE
    $labs_table = "CREATE TABLE IF NOT EXISTS labs (
        lab_id INT PRIMARY KEY AUTO_INCREMENT,
        lab_name VARCHAR(100) NOT NULL,
        lab_code VARCHAR(20) UNIQUE NOT NULL,
        location VARCHAR(100),
        capacity INT NOT NULL,
        supervisor_id INT,
        description TEXT,
        equipment TEXT,
        status ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (supervisor_id) REFERENCES users(user_id) ON DELETE SET NULL
    )";
    
    // 5. EQUIPMENT TABLE
    $equipment_table = "CREATE TABLE IF NOT EXISTS equipment (
        equipment_id INT PRIMARY KEY AUTO_INCREMENT,
        equipment_name VARCHAR(100) NOT NULL,
        equipment_code VARCHAR(50) UNIQUE NOT NULL,
        category VARCHAR(50),
        lab_id INT,
        brand VARCHAR(50),
        model VARCHAR(50),
        serial_number VARCHAR(100),
        purchase_date DATE,
        warranty_expiry DATE,
        price DECIMAL(10,2) DEFAULT 0.00,
        status ENUM('available', 'in_use', 'maintenance', 'damaged', 'retired') DEFAULT 'available',
        equipment_condition ENUM('excellent', 'good', 'fair', 'poor') DEFAULT 'good',
        notes TEXT,
        last_maintenance DATE,
        next_maintenance DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (lab_id) REFERENCES labs(lab_id) ON DELETE SET NULL
    )";
    
    // 6. RESERVATIONS TABLE
    $reservations_table = "CREATE TABLE IF NOT EXISTS reservations (
        reservation_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        lab_id INT NOT NULL,
        purpose TEXT NOT NULL,
        reservation_date DATE NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        participants INT DEFAULT 1,
        status ENUM('pending', 'approved', 'rejected', 'cancelled', 'completed') DEFAULT 'pending',
        approved_by INT NULL,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (lab_id) REFERENCES labs(lab_id) ON DELETE CASCADE,
        FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL
    )";
    
    // 7. COURSES TABLE
    $courses_table = "CREATE TABLE IF NOT EXISTS courses (
        course_id INT PRIMARY KEY AUTO_INCREMENT,
        course_code VARCHAR(20) UNIQUE NOT NULL,
        course_name VARCHAR(100) NOT NULL,
        credits INT DEFAULT 3,
        semester VARCHAR(20),
        faculty_id INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (faculty_id) REFERENCES users(user_id) ON DELETE SET NULL
    )";
    
    // 8. NOTIFICATIONS TABLE
    $notifications_table = "CREATE TABLE IF NOT EXISTS notifications (
        notification_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT,
        title VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(50),
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    )";
    
    // 9. MAINTENANCE LOGS TABLE
    $maintenance_table = "CREATE TABLE IF NOT EXISTS maintenance_logs (
        log_id INT PRIMARY KEY AUTO_INCREMENT,
        equipment_id INT NOT NULL,
        technician_id INT NOT NULL,
        maintenance_type ENUM('preventive', 'corrective', 'emergency', 'upgrade') NOT NULL,
        description TEXT NOT NULL,
        maintenance_date DATE NOT NULL,
        start_time TIME,
        end_time TIME,
        cost DECIMAL(10,2),
        parts_replaced TEXT,
        status ENUM('scheduled', 'in_progress', 'completed', 'cancelled') DEFAULT 'scheduled',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (equipment_id) REFERENCES equipment(equipment_id) ON DELETE CASCADE,
        FOREIGN KEY (technician_id) REFERENCES users(user_id) ON DELETE CASCADE
    )";
    
    // 10. ACTIVITY LOGS TABLE
    $activity_table = "CREATE TABLE IF NOT EXISTS activity_logs (
        activity_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT,
        action VARCHAR(100) NOT NULL,
        details TEXT,
        ip_address VARCHAR(45),
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
    )";
    
    // Array of all table creation queries
    $tables = [
        $users_table,
        $departments_table,
        $user_dept_table,
        $labs_table,
        $equipment_table,
        $reservations_table,
        $courses_table,
        $notifications_table,
        $maintenance_table,
        $activity_table
    ];
    
    // Execute table creation queries
    foreach ($tables as $table_query) {
        if (!$conn->query($table_query)) {
            error_log("Table creation error: " . $conn->error);
            // Continue even if some tables fail
        }
    }
    
    // Add department column to users table if it doesn't exist (for backward compatibility)
    $check_column = $conn->query("SHOW COLUMNS FROM users LIKE 'department'");
    if ($check_column->num_rows == 0) {
        $conn->query("ALTER TABLE users ADD COLUMN department VARCHAR(100) AFTER phone");
    }
    
    // Add student_id column to users table if it doesn't exist
    $check_student_id = $conn->query("SHOW COLUMNS FROM users LIKE 'student_id'");
    if ($check_student_id->num_rows == 0) {
        $conn->query("ALTER TABLE users ADD COLUMN student_id VARCHAR(20) AFTER department");
    }
}

/**
 * Insert default data into the database
 */
function insert_default_data($conn) {
    
    // 1. Insert default users
    $check_users = $conn->query("SELECT COUNT(*) as count FROM users");
    $user_count = $check_users->fetch_assoc()['count'];
    
    if ($user_count == 0) {
        // Hash password (admin123)
        $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
        
        // Insert admin user
        $admin_sql = "INSERT INTO users (username, email, password, first_name, last_name, role) 
                     VALUES ('admin', 'admin@wachemo.edu.et', ?, 'System', 'Administrator', 'admin')";
        $stmt = $conn->prepare($admin_sql);
        $stmt->bind_param("s", $hashed_password);
        $stmt->execute();
        
        // Insert sample student
        $student_sql = "INSERT INTO users (username, email, password, first_name, last_name, role, student_id, department) 
                       VALUES ('student1', 'student@wachemo.edu.et', ?, 'John', 'Doe', 'student', 'WU001', 'Computer Science')";
        $stmt = $conn->prepare($student_sql);
        $stmt->bind_param("s", $hashed_password);
        $stmt->execute();
        
        // Insert sample faculty
        $faculty_sql = "INSERT INTO users (username, email, password, first_name, last_name, role, department) 
                       VALUES ('faculty1', 'faculty@wachemo.edu.et', ?, 'Jane', 'Smith', 'faculty', 'Computer Science')";
        $stmt = $conn->prepare($faculty_sql);
        $stmt->bind_param("s", $hashed_password);
        $stmt->execute();
        
        // Insert sample technician
        $tech_sql = "INSERT INTO users (username, email, password, first_name, last_name, role) 
                    VALUES ('tech1', 'tech@wachemo.edu.et', ?, 'Robert', 'Johnson', 'technician')";
        $stmt = $conn->prepare($tech_sql);
        $stmt->bind_param("s", $hashed_password);
        $stmt->execute();
        
        $stmt->close();
    }
    
    // 2. Insert departments
    $check_depts = $conn->query("SELECT COUNT(*) as count FROM departments");
    $dept_count = $check_depts->fetch_assoc()['count'];
    
    if ($dept_count == 0) {
        $departments = [
            "('Computer Science', 'CS', 'Department of Computer Science')",
            "('Information Technology', 'IT', 'Department of Information Technology')",
            "('Software Engineering', 'SE', 'Department of Software Engineering')",
            "('Electrical Engineering', 'EE', 'Department of Electrical Engineering')",
            "('Mechanical Engineering', 'ME', 'Department of Mechanical Engineering')"
        ];
        
        foreach ($departments as $dept) {
            $conn->query("INSERT INTO departments (dept_name, dept_code, description) VALUES $dept");
        }
        
        // Link users to departments
        $conn->query("INSERT IGNORE INTO user_departments (user_id, dept_id) 
                     SELECT u.user_id, d.dept_id FROM users u, departments d 
                     WHERE u.department = d.dept_name");
    }
    
    // 3. Insert labs
    $check_labs = $conn->query("SELECT COUNT(*) as count FROM labs");
    $lab_count = $check_labs->fetch_assoc()['count'];
    
    if ($lab_count == 0) {
        // Get admin ID for supervisor
        $admin_result = $conn->query("SELECT user_id FROM users WHERE username = 'admin'");
        $admin = $admin_result->fetch_assoc();
        $admin_id = $admin ? $admin['user_id'] : 1;
        
        $labs = [
            "('Computer Lab A', 'CL101', 'Building A, Room 101', 30, $admin_id, 'Main computer laboratory with 30 PCs', 'Computers, Projector, Printer')",
            "('Programming Lab', 'PL201', 'Building B, Room 201', 25, $admin_id, 'Programming lab with development software', 'Computers, Dual Monitors, Development Tools')",
            "('Network Lab', 'NL301', 'Building C, Room 301', 20, $admin_id, 'Networking equipment and servers', 'Cisco Equipment, Servers, Testing Tools')",
            "('Hardware Lab', 'HL401', 'Building D, Room 401', 15, $admin_id, 'Computer hardware and repair lab', 'Testing Equipment, Tools, Components')"
        ];
        
        foreach ($labs as $lab) {
            $conn->query("INSERT INTO labs (lab_name, lab_code, location, capacity, supervisor_id, description, equipment) VALUES $lab");
        }
    }
    
    // 4. Insert equipment
    $check_equipment = $conn->query("SELECT COUNT(*) as count FROM equipment");
    $equipment_count = $check_equipment->fetch_assoc()['count'];
    
    if ($equipment_count == 0) {
        // Get lab IDs
        $lab_result = $conn->query("SELECT lab_id FROM labs ORDER BY lab_id LIMIT 4");
        $lab_ids = [];
        while ($row = $lab_result->fetch_assoc()) {
            $lab_ids[] = $row['lab_id'];
        }
        
        if (count($lab_ids) >= 4) {
            $equipment_data = [
                "('Desktop Computer', 'PC001', 'Computers', {$lab_ids[0]}, 'Dell', 'OptiPlex 7090', 'SN001', '2023-01-15', '2026-01-15', 1200.00, 'available', 'excellent')",
                "('Laptop', 'LT002', 'Computers', {$lab_ids[1]}, 'HP', 'EliteBook 840', 'SN002', '2023-02-20', '2026-02-20', 1500.00, 'in_use', 'good')",
                "('Projector', 'PJ003', 'AV Equipment', {$lab_ids[0]}, 'Epson', 'PowerLite 1781W', 'SN003', '2022-11-05', '2025-11-05', 900.00, 'available', 'good')",
                "('Network Switch', 'NS004', 'Networking', {$lab_ids[2]}, 'Cisco', 'Catalyst 2960', 'SN004', '2022-05-10', '2025-05-10', 800.00, 'available', 'good')",
                "('Laser Printer', 'PR005', 'Printers', {$lab_ids[0]}, 'HP', 'LaserJet Pro', 'SN005', '2023-03-20', '2025-03-20', 350.00, 'maintenance', 'fair')",
                "('Server Rack', 'SR006', 'Servers', {$lab_ids[2]}, 'Dell', 'PowerEdge', 'SN006', '2022-08-15', '2026-08-15', 3500.00, 'available', 'excellent')"
            ];
            
            foreach ($equipment_data as $eq) {
                $conn->query("INSERT INTO equipment (equipment_name, equipment_code, category, lab_id, brand, model, serial_number, purchase_date, warranty_expiry, price, status, equipment_condition) VALUES $eq");
            }
        }
    }
    
    // 5. Insert courses
    $check_courses = $conn->query("SELECT COUNT(*) as count FROM courses");
    $course_count = $check_courses->fetch_assoc()['count'];
    
    if ($course_count == 0) {
        // Get faculty ID
        $faculty_result = $conn->query("SELECT user_id FROM users WHERE username = 'faculty1'");
        if ($faculty_result->num_rows > 0) {
            $faculty = $faculty_result->fetch_assoc();
            $faculty_id = $faculty['user_id'];
            
            $courses = [
                "('CS101', 'Introduction to Programming', 3, 'Fall 2024', $faculty_id)",
                "('CS201', 'Data Structures', 4, 'Fall 2024', $faculty_id)",
                "('CS301', 'Database Systems', 3, 'Fall 2024', $faculty_id)",
                "('IT101', 'Computer Networks', 3, 'Fall 2024', $faculty_id)"
            ];
            
            foreach ($courses as $course) {
                $conn->query("INSERT INTO courses (course_code, course_name, credits, semester, faculty_id) VALUES $course");
            }
        }
    }
    
    // 6. Insert sample reservation
    $check_reservations = $conn->query("SELECT COUNT(*) as count FROM reservations");
    $reservation_count = $check_reservations->fetch_assoc()['count'];
    
    if ($reservation_count == 0) {
        // Get user and lab IDs
        $user_result = $conn->query("SELECT user_id FROM users WHERE username = 'student1'");
        $lab_result = $conn->query("SELECT lab_id FROM labs WHERE lab_code = 'CL101'");
        
        if ($user_result->num_rows > 0 && $lab_result->num_rows > 0) {
            $user = $user_result->fetch_assoc();
            $lab = $lab_result->fetch_assoc();
            
            $tomorrow = date('Y-m-d', strtotime('+1 day'));
            
            $reservation_sql = "INSERT INTO reservations (user_id, lab_id, purpose, reservation_date, start_time, end_time, participants, status) 
                               VALUES (?, ?, 'Programming project work', ?, '09:00:00', '11:00:00', 3, 'pending')";
            $stmt = $conn->prepare($reservation_sql);
            $stmt->bind_param("iis", $user['user_id'], $lab['lab_id'], $tomorrow);
            $stmt->execute();
            $stmt->close();
        }
    }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Require user to be logged in
 */
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['error'] = 'Please login to access this page';
        header('Location: ' . BASE_URL . '/login.php');
        exit();
    }
}

/**
 * Require specific user role
 */
function require_role($role) {
    require_login();
    
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != $role) {
        if ($_SESSION['user_role'] != ROLE_ADMIN) {
            $_SESSION['error'] = 'You do not have permission to access this page';
            header('Location: ' . BASE_URL . '/index.php');
            exit();
        }
    }
}

/**
 * Sanitize input data
 */
function clean_input($data) {
    global $conn;
    if (empty($data)) return '';
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    if ($conn) {
        $data = $conn->real_escape_string($data);
    }
    return $data;
}

/**
 * Display messages
 */
function show_message() {
    if (isset($_SESSION['success'])) {
        echo '<div class="alert alert-success alert-dismissible fade show">
                ' . $_SESSION['success'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['success']);
    }
    
    if (isset($_SESSION['error'])) {
        echo '<div class="alert alert-danger alert-dismissible fade show">
                ' . $_SESSION['error'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['error']);
    }
    
    if (isset($_SESSION['warning'])) {
        echo '<div class="alert alert-warning alert-dismissible fade show">
                ' . $_SESSION['warning'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['warning']);
    }
}

/**
 * Get user information
 */
function get_user_info($user_id) {
    global $conn;
    $sql = "SELECT u.*, GROUP_CONCAT(d.dept_name) as departments 
            FROM users u 
            LEFT JOIN user_departments ud ON u.user_id = ud.user_id
            LEFT JOIN departments d ON ud.dept_id = d.dept_id
            WHERE u.user_id = ? 
            GROUP BY u.user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Get all labs
 */
function get_all_labs() {
    global $conn;
    $sql = "SELECT l.*, u.first_name, u.last_name 
            FROM labs l 
            LEFT JOIN users u ON l.supervisor_id = u.user_id 
            WHERE l.status = 'active' 
            ORDER BY l.lab_name";
    $result = $conn->query($sql);
    $labs = [];
    while ($row = $result->fetch_assoc()) {
        $labs[] = $row;
    }
    return $labs;
}

/**
 * Get lab by ID
 */
function get_lab_by_id($lab_id) {
    global $conn;
    $sql = "SELECT l.*, u.first_name, u.last_name, u.email as supervisor_email 
            FROM labs l 
            LEFT JOIN users u ON l.supervisor_id = u.user_id 
            WHERE l.lab_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $lab_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Get all equipment
 */
function get_all_equipment() {
    global $conn;
    $sql = "SELECT e.*, l.lab_name, l.location 
            FROM equipment e 
            LEFT JOIN labs l ON e.lab_id = l.lab_id 
            WHERE e.status != 'retired' 
            ORDER BY e.equipment_name";
    $result = $conn->query($sql);
    $equipment = [];
    while ($row = $result->fetch_assoc()) {
        $equipment[] = $row;
    }
    return $equipment;
}

/**
 * Get equipment by lab ID
 */
function get_equipment_by_lab($lab_id) {
    global $conn;
    $sql = "SELECT * FROM equipment WHERE lab_id = ? AND status != 'retired' ORDER BY equipment_name";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $lab_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $equipment = [];
    while ($row = $result->fetch_assoc()) {
        $equipment[] = $row;
    }
    return $equipment;
}

/**
 * Check lab availability
 */
function check_lab_availability($lab_id, $date, $start_time, $end_time) {
    global $conn;
    $sql = "SELECT * FROM reservations 
            WHERE lab_id = ? 
            AND reservation_date = ? 
            AND status IN ('approved', 'pending')
            AND (
                (start_time < ? AND end_time > ?) OR
                (start_time >= ? AND start_time < ?) OR
                (end_time > ? AND end_time <= ?)
            )";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssssss", $lab_id, $date, $end_time, $start_time, $start_time, $end_time, $start_time, $end_time);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows == 0;
}

/**
 * Make a reservation
 */
function make_reservation($user_id, $lab_id, $date, $start_time, $end_time, $purpose, $participants = 1) {
    global $conn;
    
    // First check availability
    if (!check_lab_availability($lab_id, $date, $start_time, $end_time)) {
        return ['success' => false, 'message' => 'Selected time slot is not available'];
    }
    
    $sql = "INSERT INTO reservations (user_id, lab_id, reservation_date, start_time, end_time, purpose, participants) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iissssi", $user_id, $lab_id, $date, $start_time, $end_time, $purpose, $participants);
    
    if ($stmt->execute()) {
        $reservation_id = $stmt->insert_id;
        
        // Log activity
        log_activity($user_id, 'reservation_created', "Created reservation #$reservation_id");
        
        return ['success' => true, 'reservation_id' => $reservation_id];
    } else {
        return ['success' => false, 'message' => 'Failed to make reservation: ' . $stmt->error];
    }
}

/**
 * Get user reservations
 */
function get_user_reservations($user_id) {
    global $conn;
    $sql = "SELECT r.*, l.lab_name, l.location, 
                   CONCAT(u.first_name, ' ', u.last_name) as approved_by_name
            FROM reservations r
            JOIN labs l ON r.lab_id = l.lab_id
            LEFT JOIN users u ON r.approved_by = u.user_id
            WHERE r.user_id = ?
            ORDER BY r.reservation_date DESC, r.start_time DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $reservations = [];
    while ($row = $result->fetch_assoc()) {
        $reservations[] = $row;
    }
    return $reservations;
}

/**
 * Get all reservations (for admin)
 */
function get_all_reservations() {
    global $conn;
    $sql = "SELECT r.*, l.lab_name, l.location, 
                   CONCAT(u.first_name, ' ', u.last_name) as user_name,
                   CONCAT(au.first_name, ' ', au.last_name) as approved_by_name
            FROM reservations r
            JOIN labs l ON r.lab_id = l.lab_id
            JOIN users u ON r.user_id = u.user_id
            LEFT JOIN users au ON r.approved_by = au.user_id
            ORDER BY r.reservation_date DESC, r.start_time DESC";
    
    $result = $conn->query($sql);
    $reservations = [];
    while ($row = $result->fetch_assoc()) {
        $reservations[] = $row;
    }
    return $reservations;
}

/**
 * Log user activity
 */
function log_activity($user_id, $action, $details = '') {
    global $conn;
    $sql = "INSERT INTO activity_logs (user_id, action, details, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $stmt->bind_param("issss", $user_id, $action, $details, $ip, $agent);
    $stmt->execute();
}

/**
 * Get dashboard statistics
 */
function get_dashboard_stats($user_id, $role) {
    global $conn;
    $stats = [];
    
    if ($role == ROLE_ADMIN) {
        // Admin stats
        $stats['total_users'] = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
        $stats['total_labs'] = $conn->query("SELECT COUNT(*) as count FROM labs WHERE status = 'active'")->fetch_assoc()['count'];
        $stats['total_equipment'] = $conn->query("SELECT COUNT(*) as count FROM equipment WHERE status != 'retired'")->fetch_assoc()['count'];
        $stats['pending_reservations'] = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE status = 'pending'")->fetch_assoc()['count'];
        $stats['today_reservations'] = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE reservation_date = CURDATE()")->fetch_assoc()['count'];
    } elseif ($role == ROLE_STUDENT) {
        // Student stats
        $stats['my_reservations'] = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE user_id = $user_id")->fetch_assoc()['count'];
        $stats['pending_reservations'] = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE user_id = $user_id AND status = 'pending'")->fetch_assoc()['count'];
        $stats['approved_reservations'] = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE user_id = $user_id AND status = 'approved'")->fetch_assoc()['count'];
    }
    
    return $stats;
}

// ============================================
// CREATE UPLOAD DIRECTORIES
// ============================================

$upload_dirs = [
    dirname(__DIR__) . '/uploads/',
    dirname(__DIR__) . '/uploads/profile_pics/',
    dirname(__DIR__) . '/uploads/equipment_images/',
    dirname(__DIR__) . '/uploads/reports/'
];

foreach ($upload_dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
        // Create .htaccess for security
        file_put_contents($dir . '.htaccess', "Deny from all\n");
    }
}

// Create default profile picture if it doesn't exist
$default_pic = dirname(__DIR__) . '/uploads/profile_pics/default.png';
if (!file_exists($default_pic)) {
    // Create a simple default avatar
    $default_avatar = '<?xml version="1.0" encoding="UTF-8"?>
    <svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <circle cx="50" cy="35" r="20" fill="#003366"/>
        <circle cx="50" cy="85" r="30" fill="#003366"/>
    </svg>';
    file_put_contents($default_pic, $default_avatar);
}

?>