<?php
session_start();
require_once 'config.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$message = "";

// Update user role
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_role'])) {
    $user_id = $_POST['user_id'];
    $new_role = $_POST['new_role'];
    
    // Cannot change own role from admin
    if ($user_id == $_SESSION['user_id'] && $new_role != 'admin') {
        $message = "<div class='alert alert-danger'>You cannot change your own admin role</div>";
    } else {
        $sql = "UPDATE users SET role = ? WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $new_role, $user_id);
        
        if (mysqli_stmt_execute($stmt)) {
            // Log the role change
            $log_sql = "INSERT INTO role_logs (user_id, changed_by, old_role, new_role) 
                       VALUES (?, ?, ?, ?)";
            $log_stmt = mysqli_prepare($conn, $log_sql);
            
            // Get old role
            $old_role_sql = "SELECT role FROM users WHERE user_id = ?";
            $old_role_stmt = mysqli_prepare($conn, $old_role_sql);
            mysqli_stmt_bind_param($old_role_stmt, "i", $user_id);
            mysqli_stmt_execute($old_role_stmt);
            $old_role = mysqli_fetch_assoc(mysqli_stmt_get_result($old_role_stmt))['role'];
            
            mysqli_stmt_bind_param($log_stmt, "iiss", $user_id, $_SESSION['user_id'], $old_role, $new_role);
            mysqli_stmt_execute($log_stmt);
            
            $message = "<div class='alert alert-success'>User role updated successfully</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error updating role</div>";
        }
    }
}

// Get all users
$users_sql = "SELECT * FROM users ORDER BY role, full_name";
$users_result = mysqli_query($conn, $users_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Roles - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2>Assign User Roles</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <!-- Role Statistics -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Role Distribution</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $role_stats_sql = "SELECT role, COUNT(*) as count FROM users GROUP BY role";
                        $role_stats_result = mysqli_query($conn, $role_stats_sql);
                        ?>
                        <canvas id="roleChart" height="250"></canvas>
                        
                        <table class="table table-sm mt-3">
                            <thead>
                                <tr>
                                    <th>Role</th>
                                    <th>Count</th>
                                    <th>Color</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $colors = [
                                    'admin' => '#dc3545',
                                    'faculty' => '#198754',
                                    'lab_manager' => '#ffc107',
                                    'student' => '#0d6efd'
                                ];
                                
                                while ($stat = mysqli_fetch_assoc($role_stats_result)): ?>
                                <tr>
                                    <td><?php echo ucfirst($stat['role']); ?></td>
                                    <td><?php echo $stat['count']; ?></td>
                                    <td>
                                        <span class="badge" style="background-color: <?php echo $colors[$stat['role']]; ?>; width: 20px; height: 20px;"></span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Role Permissions -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Role Permissions</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Role</th>
                                    <th>Permissions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><span class="badge bg-danger">Admin</span></td>
                                    <td>Full system access</td>
                                </tr>
                                <tr>
                                    <td><span class="badge bg-success">Faculty</span></td>
                                    <td>Make reservations, manage courses</td>
                                </tr>
                                <tr>
                                    <td><span class="badge bg-warning">Lab Manager</span></td>
                                    <td>Manage equipment, approve reservations</td>
                                </tr>
                                <tr>
                                    <td><span class="badge bg-primary">Student</span></td>
                                    <td>Make reservations, view courses</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Users List -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>User List</h5>
                        <div>
                            <select class="form-select form-select-sm" id="roleFilter" onchange="filterUsers()">
                                <option value="all">All Roles</option>
                                <option value="admin">Admin</option>
                                <option value="faculty">Faculty</option>
                                <option value="lab_manager">Lab Manager</option>
                                <option value="student">Student</option>
                            </select>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="usersTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>User</th>
                                        <th>Contact</th>
                                        <th>Current Role</th>
                                        <th>Department</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($user = mysqli_fetch_assoc($users_result)): ?>
                                    <tr data-role="<?php echo $user['role']; ?>">
                                        <td><?php echo $user['user_id']; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                                            <small class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></small>
                                        </td>
                                        <td>
                                            <small><?php echo htmlspecialchars($user['email']); ?><br>
                                            <?php echo htmlspecialchars($user['phone']); ?></small>
                                        </td>
                                        <td>
                                            <?php 
                                            $role_badge = [
                                                'admin' => 'danger',
                                                'faculty' => 'success',
                                                'lab_manager' => 'warning',
                                                'student' => 'primary'
                                            ];
                                            ?>
                                            <span class="badge bg-<?php echo $role_badge[$user['role']]; ?>">
                                                <?php echo ucfirst($user['role']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($user['department']); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" 
                                                    data-bs-target="#roleModal<?php echo $user['user_id']; ?>">
                                                <i class="fas fa-user-cog"></i> Change Role
                                            </button>
                                        </td>
                                    </tr>
                                    
                                    <!-- Role Change Modal -->
                                    <div class="modal fade" id="roleModal<?php echo $user['user_id']; ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form method="POST" action="">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Change Role for <?php echo htmlspecialchars($user['full_name']); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Current Role</label>
                                                            <input type="text" class="form-control" value="<?php echo ucfirst($user['role']); ?>" readonly>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">New Role</label>
                                                            <select class="form-select" name="new_role" required>
                                                                <option value="student" <?php echo $user['role'] == 'student' ? 'selected' : ''; ?>>Student</option>
                                                                <option value="faculty" <?php echo $user['role'] == 'faculty' ? 'selected' : ''; ?>>Faculty</option>
                                                                <option value="lab_manager" <?php echo $user['role'] == 'lab_manager' ? 'selected' : ''; ?>>Lab Manager</option>
                                                                <option value="admin" <?php echo $user['role'] == 'admin' ? 'selected' : ''; ?>>Administrator</option>
                                                            </select>
                                                        </div>
                                                        <div class="alert alert-warning">
                                                            <i class="fas fa-exclamation-triangle"></i>
                                                            Changing user roles may affect system permissions.
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" name="update_role" class="btn btn-primary">Update Role</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Role Change Log -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Recent Role Changes</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $log_sql = "SELECT rl.*, u1.full_name as user_name, u2.username as changed_by_name 
                                   FROM role_logs rl 
                                   JOIN users u1 ON rl.user_id = u1.user_id 
                                   JOIN users u2 ON rl.changed_by = u2.user_id 
                                   ORDER BY rl.change_date DESC LIMIT 10";
                        $log_result = mysqli_query($conn, $log_sql);
                        ?>
                        
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>User</th>
                                        <th>Old Role</th>
                                        <th>New Role</th>
                                        <th>Changed By</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($log = mysqli_fetch_assoc($log_result)): ?>
                                    <tr>
                                        <td><?php echo date('Y-m-d H:i', strtotime($log['change_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($log['user_name']); ?></td>
                                        <td><span class="badge bg-secondary"><?php echo ucfirst($log['old_role']); ?></span></td>
                                        <td><span class="badge bg-primary"><?php echo ucfirst($log['new_role']); ?></span></td>
                                        <td><?php echo htmlspecialchars($log['changed_by_name']); ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    // Pie chart for role distribution
    var ctx = document.getElementById('roleChart').getContext('2d');
    <?php
    mysqli_data_seek($role_stats_result, 0);
    $labels = [];
    $data = [];
    $backgroundColors = [];
    
    while ($stat = mysqli_fetch_assoc($role_stats_result)) {
        $labels[] = ucfirst($stat['role']);
        $data[] = $stat['count'];
        $backgroundColors[] = $colors[$stat['role']];
    }
    ?>
    
    var roleChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                data: <?php echo json_encode($data); ?>,
                backgroundColor: <?php echo json_encode($backgroundColors); ?>,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    
    function filterUsers() {
        var role = document.getElementById('roleFilter').value;
        var rows = document.querySelectorAll('#usersTable tbody tr');
        
        rows.forEach(function(row) {
            if (role == 'all' || row.getAttribute('data-role') == role) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>