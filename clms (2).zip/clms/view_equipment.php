<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

// Require authentication
requireAuth();

$conn = 'getConnection'();

// Get equipment with filters
$category_filter = $_GET['category'] ?? '';
$status_filter = $_GET['status'] ?? '';
$lab_filter = $_GET['lab'] ?? '';

$sql = "SELECT e.*, c.category_name, l.lab_name, l.location 
        FROM equipment e 
        LEFT JOIN equipment_categories c ON e.category_id = c.category_id 
        LEFT JOIN labs l ON e.lab_id = l.lab_id 
        WHERE 1=1";

$params = [];

if ($category_filter) {
    $sql .= " AND e.category_id = ?";
    $params[] = $category_filter;
}

if ($status_filter) {
    $sql .= " AND e.status = ?";
    $params[] = $status_filter;
}

if ($lab_filter) {
    $sql .= " AND e.lab_id = ?";
    $params[] = $lab_filter;
}

$sql .= " ORDER BY e.equipment_name";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$equipment = $stmt->fetchAll();

// Get categories for filter
$categories = $conn->query("SELECT * FROM equipment_categories ORDER BY category_name")->fetchAll();

// Get labs for filter
$labs = $conn->query("SELECT * FROM labs WHERE status = 'active' ORDER BY lab_name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Equipment - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="dashboard-content">
            <div class="dashboard-header">
                <h1><i class="fas fa-desktop"></i> Equipment Inventory</h1>
                <?php if (isAdmin() || isTechnician()): ?>
                <a href="manage_equipment.php" class="btn btn-primary">
                    <i class="fas fa-tools"></i> Manage Equipment
                </a>
                <?php endif; ?>
            </div>
            
            <!-- Filters -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h3>Filters</h3>
                </div>
                <div class="card-body">
                    <form method="GET" action="" class="filter-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="category">Category</label>
                                <select id="category" name="category" class="form-control">
                                    <option value="">All Categories</option>
                                    <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['category_id']; ?>" 
                                            <?php echo $category_filter == $category['category_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['category_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select id="status" name="status" class="form-control">
                                    <option value="">All Status</option>
                                    <option value="available" <?php echo $status_filter == 'available' ? 'selected' : ''; ?>>Available</option>
                                    <option value="in_use" <?php echo $status_filter == 'in_use' ? 'selected' : ''; ?>>In Use</option>
                                    <option value="maintenance" <?php echo $status_filter == 'maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                                    <option value="damaged" <?php echo $status_filter == 'damaged' ? 'selected' : ''; ?>>Damaged</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="lab">Laboratory</label>
                                <select id="lab" name="lab" class="form-control">
                                    <option value="">All Laboratories</option>
                                    <?php foreach ($labs as $lab): ?>
                                    <option value="<?php echo $lab['lab_id']; ?>" 
                                            <?php echo $lab_filter == $lab['lab_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($lab['lab_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div class="filter-buttons">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-filter"></i> Apply Filters
                                    </button>
                                    <a href="view_equipment.php" class="btn btn-outline">
                                        <i class="fas fa-times"></i> Clear Filters
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Equipment Grid -->
            <div class="equipment-container">
                <?php if (empty($equipment)): ?>
                    <div class="empty-state">
                        <i class="fas fa-search"></i>
                        <h3>No equipment found</h3>
                        <p>Try adjusting your filters or check back later.</p>
                    </div>
                <?php else: ?>
                    <div class="equipment-grid">
                        <?php foreach ($equipment as $item): ?>
                        <div class="equipment-card">
                            <div class="equipment-header">
                                <div class="equipment-image">
                                    <i class="fas fa-<?php echo 'getEquipmentIcon'($item['category_name']); ?>"></i>
                                </div>
                                <div class="equipment-status">
                                    <span class="badge badge-<?php echo 'getStatusBadgeClass'($item['status']); ?>">
                                        <?php echo ucfirst($item['status']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="equipment-body">
                                <h3><?php echo htmlspecialchars($item['equipment_name']); ?></h3>
                                <p class="equipment-code"><?php echo htmlspecialchars($item['equipment_code']); ?></p>
                                
                                <div class="equipment-details">
                                    <div class="detail">
                                        <i class="fas fa-tag"></i>
                                        <span><?php echo htmlspecialchars($item['category_name']); ?></span>
                                    </div>
                                    
                                    <?php if ($item['lab_name']): ?>
                                    <div class="detail">
                                        <i class="fas fa-building"></i>
                                        <span><?php echo htmlspecialchars($item['lab_name']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($item['brand']): ?>
                                    <div class="detail">
                                        <i class="fas fa-industry"></i>
                                        <span><?php echo htmlspecialchars($item['brand']); ?> 
                                              <?php echo htmlspecialchars($item['model']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($item['purchase_date']): ?>
                                    <div class="detail">
                                        <i class="fas fa-calendar-alt"></i>
                                        <span>Purchased: <?php echo formatDate($item['purchase_date']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="equipment-condition">
                                    <strong>Condition:</strong>
                                    <span class="condition-<?php echo $item['condition']; ?>">
                                        <?php echo ucfirst($item['condition']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="equipment-footer">
                                <?php if (isStudent() && $item['status'] == 'available'): ?>
                                <a href="make_reservation.php?equipment_id=<?php echo $item['equipment_id']; ?>" 
                                   class="btn btn-primary btn-block">
                                    <i class="fas fa-calendar-plus"></i> Reserve
                                </a>
                                <?php endif; ?>
                                
                                <?php if (isAdmin() || isTechnician()): ?>
                                <a href="manage_equipment.php?edit=<?php echo $item['equipment_id']; ?>" 
                                   class="btn btn-outline btn-block">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <style>
        .filter-form {
            margin-bottom: 0;
        }
        
        .filter-buttons {
            display: flex;
            gap: 10px;
            margin-top: 8px;
        }
        
        .equipment-container {
            margin-top: 2rem;
        }
        
        .equipment-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .equipment-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
        }
        
        .equipment-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }
        
        .equipment-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1.5rem;
            position: relative;
        }
        
        .equipment-image {
            font-size: 3rem;
            color: white;
            text-align: center;
            margin-bottom: 1rem;
        }
        
        .equipment-status {
            position: absolute;
            top: 1rem;
            right: 1rem;
        }
        
        .equipment-body {
            padding: 1.5rem;
        }
        
        .equipment-body h3 {
            margin-bottom: 0.5rem;
            color: var(--secondary-color);
        }
        
        .equipment-code {
            color: var(--gray-color);
            font-size: 0.875rem;
            margin-bottom: 1rem;
        }
        
        .equipment-details {
            margin-bottom: 1rem;
        }
        
        .detail {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
            color: var(--secondary-color);
        }
        
        .detail i {
            color: var(--primary-color);
            width: 20px;
        }
        
        .equipment-condition {
            padding: 0.5rem;
            background: var(--light-gray);
            border-radius: 4px;
            font-size: 0.875rem;
        }
        
        .condition-excellent { color: var(--success-color); }
        .condition-good { color: #2ecc71; }
        .condition-fair { color: var(--warning-color); }
        .condition-poor { color: var(--danger-color); }
        
        .equipment-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--border-color);
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }
        
        .empty-state i {
            font-size: 4rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            margin-bottom: 0.5rem;
        }
        
        .empty-state p {
            color: var(--gray-color);
        }
        
        @media (max-width: 768px) {
            .equipment-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-form .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
    
    <script>
        function getEquipmentIcon(category) {
            const icons = {
                'Computers': 'desktop',
                'Networking': 'network-wired',
                'Peripherals': 'keyboard',
                'Software': 'compact-disc',
                'Tools': 'tools',
                'Storage': 'hdd',
                'Projectors': 'video',
                'Servers': 'server'
            };
            return icons[category] || 'desktop';
        }
        
        function getStatusBadgeClass(status) {
            const classes = {
                'available': 'success',
                'in_use': 'warning',
                'maintenance': 'info',
                'damaged': 'danger',
                'retired': 'secondary'
            };
            return classes[status] || 'secondary';
        }
    </script>
</body>
</html>