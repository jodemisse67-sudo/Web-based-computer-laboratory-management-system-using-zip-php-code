<?php
require_once 'config/config.php';
require_once 'includes/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <main>
        <section class="about-hero">
            <div class="container">
                <h1>About Wachemo Lab System</h1>
                <p class="subtitle">Streamlining laboratory management for enhanced educational experience</p>
            </div>
        </section>
        
        <section class="about-content">
            <div class="container">
                <div class="about-grid">
                    <div class="about-card">
                        <div class="about-icon">
                            <i class="fas fa-bullseye"></i>
                        </div>
                        <h3>Our Mission</h3>
                        <p>To provide an efficient and user-friendly platform for managing computer laboratory resources, equipment reservations, and academic sessions at Wachemo University Durame Campus.</p>
                    </div>
                    
                    <div class="about-card">
                        <div class="about-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <h3>Our Vision</h3>
                        <p>To become the leading laboratory management system in Ethiopian universities, promoting technological advancement in education.</p>
                    </div>
                    
                    <div class="about-card">
                        <div class="about-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h3>Our Values</h3>
                        <p>Efficiency, Accessibility, Innovation, and User-Centric Design guide our development and service delivery.</p>
                    </div>
                </div>
                
                <div class="about-details">
                    <h2>System Overview</h2>
                    <p>The Computer Laboratory Management System (CLMS) is designed to address the challenges of managing computer laboratory resources in educational institutions. It provides a comprehensive solution for:</p>
                    
                    <ul class="feature-list">
                        <li><i class="fas fa-check-circle"></i> Equipment tracking and management</li>
                        <li><i class="fas fa-check-circle"></i> Laboratory and equipment reservations</li>
                        <li><i class="fas fa-check-circle"></i> Academic session scheduling</li>
                        <li><i class="fas fa-check-circle"></i> Attendance tracking</li>
                        <li><i class="fas fa-check-circle"></i> Maintenance and resource requests</li>
                        <li><i class="fas fa-check-circle"></i> Real-time notifications</li>
                        <li><i class="fas fa-check-circle"></i> Comprehensive reporting</li>
                    </ul>
                    
                    <div class="stats-grid">
                        <div class="stat">
                            <div class="stat-number"><?php echo count(getAllUsers()); ?>+</div>
                            <div class="stat-label">System Users</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number"><?php echo count(getAllLabs()); ?>+</div>
                            <div class="stat-label">Laboratories</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number"><?php echo count(getAllEquipment()); ?>+</div>
                            <div class="stat-label">Equipment Items</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number">24/7</div>
                            <div class="stat-label">System Availability</div>
                        </div>
                    </div>
                </div>
                
                <div class="team-section">
                    <h2>Development Team</h2>
                    <p class="section-subtitle">Brought to you by the Computer Science Department</p>
                    
                    <div class="team-grid">
                        <div class="team-card">
                            <div class="team-avatar">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="team-info">
                                <h4>System Administrators</h4>
                                <p>Responsible for system maintenance and user support</p>
                            </div>
                        </div>
                        
                        <div class="team-card">
                            <div class="team-avatar">
                                <i class="fas fa-code"></i>
                            </div>
                            <div class="team-info">
                                <h4>Development Team</h4>
                                <p>Software engineering students and faculty members</p>
                            </div>
                        </div>
                        
                        <div class="team-card">
                            <div class="team-avatar">
                                <i class="fas fa-headset"></i>
                            </div>
                            <div class="team-info">
                                <h4>Support Team</h4>
                                <p>Available to assist users and resolve issues</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    <?php include 'footer.php'; ?>
    
    <style>
        .about-hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
            text-align: center;
        }
        
        .about-hero h1 {
            color: white;
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        
        .about-hero .subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
        }
        
        .about-content {
            padding: 4rem 0;
        }
        
        .about-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 4rem;
        }
        
        .about-card {
            background: white;
            padding: 2rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            text-align: center;
        }
        
        .about-icon {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        .about-card h3 {
            margin-bottom: 1rem;
        }
        
        .about-details {
            background: white;
            padding: 3rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            margin-bottom: 4rem;
        }
        
        .feature-list {
            list-style: none;
            margin: 2rem 0;
        }
        
        .feature-list li {
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .feature-list i {
            color: var(--success-color);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }
        
        .stat {
            text-align: center;
            padding: 1.5rem;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: var(--border-radius);
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            font-size: 1rem;
            color: var(--secondary-color);
        }
        
        .team-section {
            text-align: center;
        }
        
        .section-subtitle {
            color: var(--gray-color);
            margin-bottom: 3rem;
        }
        
        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }
        
        .team-card {
            background: white;
            padding: 2rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }
        
        .team-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 2rem;
        }
        
        .team-info h4 {
            margin-bottom: 0.5rem;
        }
        
        .team-info p {
            color: var(--gray-color);
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .about-hero h1 {
                font-size: 2.5rem;
            }
            
            .about-details {
                padding: 2rem;
            }
        }
    </style>
</body>
</html>