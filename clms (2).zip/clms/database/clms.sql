-- ============================================
-- Wachemo University Dourame Campus
-- Computer Laboratory Management System
-- ============================================

DROP DATABASE IF EXISTS wachemo_lab_system;
CREATE DATABASE wachemo_lab_system;
USE wachemo_lab_system;

-- ============================================
-- CREATE TABLES IN CORRECT ORDER
-- ============================================

-- 1. Users table (no dependencies)
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    department VARCHAR(100),
    student_id VARCHAR(20),
    faculty_id VARCHAR(20),
    profile_pic VARCHAR(255),
    role ENUM('admin', 'faculty', 'student', 'technician') NOT NULL,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. Departments table (depends on users)
CREATE TABLE departments (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(100) NOT NULL,
    dept_code VARCHAR(10) UNIQUE NOT NULL,
    head_of_dept INT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (head_of_dept) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 3. Labs table (depends on users)
CREATE TABLE labs (
    lab_id INT PRIMARY KEY AUTO_INCREMENT,
    lab_name VARCHAR(100) NOT NULL,
    lab_code VARCHAR(20) UNIQUE NOT NULL,
    location VARCHAR(100),
    capacity INT NOT NULL,
    supervisor_id INT,
    description TEXT,
    status ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supervisor_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 4. Equipment categories table (no dependencies)
CREATE TABLE equipment_categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Equipment table (depends on equipment_categories and labs)
CREATE TABLE equipment (
    equipment_id INT PRIMARY KEY AUTO_INCREMENT,
    equipment_name VARCHAR(100) NOT NULL,
    equipment_code VARCHAR(50) UNIQUE NOT NULL,
    category_id INT,
    lab_id INT,
    brand VARCHAR(50),
    model VARCHAR(50),
    serial_number VARCHAR(100),
    purchase_date DATE,
    warranty_expiry DATE,
    purchase_price DECIMAL(10,2) DEFAULT 0.00,
    current_value DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('available', 'in_use', 'maintenance', 'damaged', 'retired') DEFAULT 'available',
    equipment_condition ENUM('excellent', 'good', 'fair', 'poor') DEFAULT 'good', -- CHANGED FROM 'condition'
    condition_notes TEXT,
    last_maintenance DATE,
    next_maintenance DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES equipment_categories(category_id) ON DELETE SET NULL,
    FOREIGN KEY (lab_id) REFERENCES labs(lab_id) ON DELETE SET NULL
);

-- 6. Courses table (depends on departments and users)
CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    dept_id INT,
    instructor_id INT,
    credits INT DEFAULT 3,
    description TEXT,
    semester VARCHAR(20),
    academic_year VARCHAR(10),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL,
    FOREIGN KEY (instructor_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 7. Lab sessions table (depends on courses, labs, users)
CREATE TABLE lab_sessions (
    session_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    lab_id INT NOT NULL,
    instructor_id INT NOT NULL,
    session_title VARCHAR(100) NOT NULL,
    session_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    session_type ENUM('lecture', 'practical', 'workshop', 'exam') DEFAULT 'practical',
    max_students INT DEFAULT 30,
    description TEXT,
    status ENUM('scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    FOREIGN KEY (lab_id) REFERENCES labs(lab_id) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 8. Course enrollments (depends on users and courses)
CREATE TABLE course_enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('enrolled', 'dropped', 'completed') DEFAULT 'enrolled',
    grade VARCHAR(5),
    attendance_rate DECIMAL(5,2) DEFAULT 0.00,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, course_id)
);

-- 9. Session attendance (depends on lab_sessions and users)
CREATE TABLE session_attendance (
    attendance_id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    student_id INT NOT NULL,
    attendance_status ENUM('present', 'absent', 'late', 'excused') DEFAULT 'absent',
    check_in_time TIMESTAMP NULL,
    check_out_time TIMESTAMP NULL,
    notes TEXT,
    recorded_by INT,
    FOREIGN KEY (session_id) REFERENCES lab_sessions(session_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(user_id) ON DELETE SET NULL,
    UNIQUE KEY unique_attendance (session_id, student_id)
);

-- 10. Equipment reservations (depends on users and equipment)
CREATE TABLE equipment_reservations (
    reservation_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    equipment_id INT NOT NULL,
    reservation_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    purpose TEXT,
    status ENUM('pending', 'approved', 'rejected', 'completed', 'cancelled') DEFAULT 'pending',
    approved_by INT NULL,
    approval_date TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (equipment_id) REFERENCES equipment(equipment_id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 11. Lab reservations (depends on users and labs)
CREATE TABLE lab_reservations (
    reservation_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    lab_id INT NOT NULL,
    reservation_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    purpose TEXT,
    expected_attendees INT,
    status ENUM('pending', 'approved', 'rejected', 'completed', 'cancelled') DEFAULT 'pending',
    approved_by INT NULL,
    approval_date TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (lab_id) REFERENCES labs(lab_id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 12. Resource requests (depends on users)
CREATE TABLE resource_requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    requester_id INT NOT NULL,
    request_type ENUM('equipment', 'software', 'maintenance', 'supplies', 'other') NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    status ENUM('pending', 'in_progress', 'completed', 'rejected') DEFAULT 'pending',
    assigned_to INT NULL,
    requested_date DATE DEFAULT (CURRENT_DATE),
    required_date DATE,
    completion_date DATE NULL,
    admin_notes TEXT,
    estimated_cost DECIMAL(10,2),
    approved_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (requester_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 13. Maintenance records (depends on equipment and users)
CREATE TABLE maintenance_records (
    maintenance_id INT PRIMARY KEY AUTO_INCREMENT,
    equipment_id INT NOT NULL,
    technician_id INT NOT NULL,
    maintenance_type ENUM('preventive', 'corrective', 'emergency', 'upgrade') NOT NULL,
    description TEXT NOT NULL,
    maintenance_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    cost DECIMAL(10,2),
    parts_replaced TEXT,
    status ENUM('scheduled', 'in_progress', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (equipment_id) REFERENCES equipment(equipment_id) ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 14. Notifications (depends on users)
CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT NOT NULL,
    recipient_id INT NULL,
    recipient_role ENUM('admin', 'faculty', 'student', 'technician', 'all') NULL,
    title VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'warning', 'success', 'error', 'reservation', 'maintenance') DEFAULT 'info',
    related_id INT,
    related_type VARCHAR(50),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 15. System logs (depends on users)
CREATE TABLE system_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    action VARCHAR(100) NOT NULL,
    table_affected VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 16. User sessions (depends on users)
CREATE TABLE user_sessions (
    session_id VARCHAR(128) PRIMARY KEY,
    user_id INT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================
-- INSERT DEFAULT DATA IN CORRECT ORDER
-- ============================================

-- 1. Insert users first
INSERT INTO users (username, email, password_hash, first_name, last_name, role) VALUES
('admin', 'admin@wcu.edu.et', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System', 'Administrator', 'admin'),
('faculty1', 'faculty@wcu.edu.et', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John', 'Professor', 'faculty'),
('student1', 'student@wcu.edu.et', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Alice', 'Student', 'student'),
('tech1', 'technician@wcu.edu.et', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Bob', 'Technician', 'technician');

-- 2. Insert departments
INSERT INTO departments (dept_name, dept_code, description) VALUES
('Computer Science', 'CS', 'Department of Computer Science'),
('Information Technology', 'IT', 'Department of Information Technology'),
('Software Engineering', 'SE', 'Department of Software Engineering');

-- 3. Insert labs
INSERT INTO labs (lab_name, lab_code, location, capacity, description) VALUES
('Computer Lab 1', 'CL001', 'Building A, Room 101', 30, 'Main computer lab with 30 PCs'),
('Programming Lab', 'PL002', 'Building B, Room 201', 25, 'Programming lab with advanced software'),
('Network Lab', 'NL003', 'Building C, Room 301', 20, 'Networking equipment lab'),
('Hardware Lab', 'HL004', 'Building D, Room 401', 15, 'Computer hardware lab');

-- 4. Insert equipment categories
INSERT INTO equipment_categories (category_name, description) VALUES
('Computers', 'Desktop and laptop computers'),
('Networking', 'Network equipment'),
('Peripherals', 'Keyboards, mice, monitors'),
('Printers', 'Printers and scanners'),
('Projectors', 'Projectors and displays'),
('Servers', 'Server equipment');

-- 5. Insert equipment
INSERT INTO equipment (equipment_name, equipment_code, category_id, lab_id, brand, model, serial_number, purchase_date, warranty_expiry, purchase_price, current_value, status, equipment_condition) VALUES
('Dell Desktop', 'PC001', 1, 1, 'Dell', 'OptiPlex 7090', 'SN001', '2023-01-15', '2026-01-15', 1200.00, 900.00, 'available', 'excellent'),
('HP Laptop', 'LT002', 1, 2, 'HP', 'EliteBook 840', 'SN002', '2023-02-20', '2026-02-20', 1500.00, 1200.00, 'in_use', 'good'),
('Cisco Switch', 'SW003', 2, 3, 'Cisco', 'Catalyst 2960', 'SN003', '2022-05-10', '2025-05-10', 800.00, 600.00, 'available', 'good'),
('HP Printer', 'PR004', 4, 1, 'HP', 'LaserJet Pro', 'SN004', '2023-03-20', '2025-03-20', 350.00, 280.00, 'available', 'excellent'),
('Epson Projector', 'PJ005', 5, 1, 'Epson', 'PowerLite', 'SN005', '2022-11-05', '2025-11-05', 900.00, 700.00, 'maintenance', 'fair'),
('Dell Server', 'SRV006', 6, 3, 'Dell', 'PowerEdge', 'SN006', '2022-08-15', '2026-08-15', 3500.00, 2800.00, 'available', 'excellent');

-- 6. Insert courses
INSERT INTO courses (course_code, course_name, dept_id, instructor_id, credits, description) VALUES
('CS101', 'Introduction to Programming', 1, 2, 3, 'Basic programming concepts'),
('CS201', 'Data Structures', 1, 2, 4, 'Advanced data structures'),
('IT101', 'Computer Networks', 2, 2, 3, 'Networking fundamentals');

-- 7. Insert lab sessions
INSERT INTO lab_sessions (course_id, lab_id, instructor_id, session_title, session_date, start_time, end_time) VALUES
(1, 1, 2, 'Python Lab', DATE_ADD(CURDATE(), INTERVAL 1 DAY), '09:00:00', '11:00:00'),
(2, 2, 2, 'Data Structures Lab', DATE_ADD(CURDATE(), INTERVAL 2 DAY), '10:00:00', '12:00:00');

-- 8. Insert sample reservations
INSERT INTO lab_reservations (user_id, lab_id, reservation_date, start_time, end_time, purpose, status) VALUES
(3, 1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '14:00:00', '16:00:00', 'Project work', 'approved'),
(3, 2, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '13:00:00', '15:00:00', 'Research', 'pending');

INSERT INTO equipment_reservations (user_id, equipment_id, reservation_date, start_time, end_time, purpose, status) VALUES
(3, 1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '14:00:00', '16:00:00', 'Programming', 'approved'),
(2, 3, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '10:00:00', '12:00:00', 'Network testing', 'pending');

-- ============================================
-- CREATE INDEXES FOR PERFORMANCE
-- ============================================

CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_equipment_status ON equipment(status);
CREATE INDEX idx_equipment_lab ON equipment(lab_id);
CREATE INDEX idx_reservations_date ON lab_reservations(reservation_date);
CREATE INDEX idx_equipment_res_date ON equipment_reservations(reservation_date);

-- ============================================
-- TEST QUERIES
-- ============================================

-- Test query to verify equipment table
SELECT 
    e.equipment_id,
    e.equipment_name,
    e.equipment_code,
    e.status,
    e.equipment_condition,
    l.lab_name,
    ec.category_name
FROM equipment e
LEFT JOIN labs l ON e.lab_id = l.lab_id
LEFT JOIN equipment_categories ec ON e.category_id = ec.category_id;

-- Count records in each table
SELECT 'users' as table_name, COUNT(*) as count FROM users
UNION SELECT 'labs', COUNT(*) FROM labs
UNION SELECT 'equipment', COUNT(*) FROM equipment
UNION SELECT 'lab_reservations', COUNT(*) FROM lab_reservations
UNION SELECT 'equipment_reservations', COUNT(*) FROM equipment_reservations;