<?php
session_start();
require_once 'config.php';

// Get active labs count
$labs_sql = "SELECT COUNT(*) as total FROM labs WHERE status = 'active'";
$labs_result = mysqli_query($conn, $labs_sql);
$labs_count = mysqli_fetch_assoc($labs_result)['total'];

// Get users count
$users_sql = "SELECT COUNT(*) as total FROM users";
$users_result = mysqli_query($conn, $users_sql);
$users_count = mysqli_fetch_assoc($users_result)['total'];

// Get recent reservations
$reservations_sql = "SELECT COUNT(*) as total FROM reservations 
                     WHERE reservation_date >= CURDATE() AND status = 'approved'";
$reservations_result = mysqli_query($conn, $reservations_sql);
$reservations_count = mysqli_fetch_assoc($reservations_result)['total'];

// Get recent notifications
$notifications_sql = "SELECT * FROM notifications 
                      WHERE (target_user = 'all' OR target_user = 'public') 
                      AND expiry_date >= CURDATE() 
                      ORDER BY created_at DESC LIMIT 5";
$notifications_result = mysqli_query($conn, $notifications_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Computer Lab Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('assets/lab-bg.jpg') center/cover no-repeat;
            color: white;
            padding: 100px 0;
            margin-bottom: 50px;
        }
        .stat-card {
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-10px);
        }
        .feature-icon {
            font-size: 3rem;
            color: #0d6efd;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home.php">
                <i class="fas fa-laptop-code"></i> CLMS
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#labs">Labs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 mb-4">Computer Lab Management System</h1>
            <p class="lead mb-4">Efficiently manage lab resources, reservations, and equipment with our comprehensive system</p>
            <?php if(!isset($_SESSION['user_id'])): ?>
                <a href="login.php" class="btn btn-primary btn-lg me-2">Login to Book</a>
                <a href="register.php" class="btn btn-outline-light btn-lg">Create Account</a>
            <?php else: ?>
                <a href="make_reservation.php" class="btn btn-primary btn-lg me-2">Book Lab Now</a>
                <a href="dashboard.php" class="btn btn-outline-light btn-lg">Go to Dashboard</a>
            <?php endif; ?>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-5">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 mb-4">
                    <div class="card stat-card shadow">
                        <div class="card-body">
                            <i class="fas fa-laptop-house feature-icon"></i>
                            <h3 class="card-title"><?php echo $labs_count; ?></h3>
                            <p class="card-text">Active Computer Labs</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card stat-card shadow">
                        <div class="card-body">
                            <i class="fas fa-users feature-icon"></i>
                            <h3 class="card-title"><?php echo $users_count; ?></h3>
                            <p class="card-text">Registered Users</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card stat-card shadow">
                        <div class="card-body">
                            <i class="fas fa-calendar-check feature-icon"></i>
                            <h3 class="card-title"><?php echo $reservations_count; ?></h3>
                            <p class="card-text">Today's Reservations</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card stat-card shadow">
                        <div class="card-body">
                            <i class="fas fa-desktop feature-icon"></i>
                            <h3 class="card-title">200+</h3>
                            <p class="card-text">Available Systems</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Key Features</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-calendar-alt fa-3x text-primary mb-3"></i>
                            <h4>Easy Booking</h4>
                            <p>Simple and intuitive reservation system for labs and equipment</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-chart-bar fa-3x text-success mb-3"></i>
                            <h4>Real-time Analytics</h4>
                            <p>Track lab usage, equipment status, and generate reports</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-bell fa-3x text-warning mb-3"></i>
                            <h4>Instant Notifications</h4>
                            <p>Get notified about reservations, maintenance, and announcements</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Labs Section -->
    <section id="labs" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Our Computer Labs</h2>
            <div class="row">
                <?php
                $active_labs_sql = "SELECT * FROM labs WHERE status = 'active' LIMIT 6";
                $active_labs_result = mysqli_query($conn, $active_labs_sql);
                
                while($lab = mysqli_fetch_assoc($active_labs_result)):
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($lab['lab_name']); ?></h5>
                            <p class="card-text">
                                <i class="fas fa-users"></i> Capacity: <?php echo $lab['capacity']; ?> seats<br>
                                <i class="fas fa-microchip"></i> Equipment: <?php echo htmlspecialchars(substr($lab['equipment'], 0, 50)); ?>...
                            </p>
                            <?php if(isset($_SESSION['user_id'])): ?>
                                <a href="make_reservation.php?lab_id=<?php echo $lab['lab_id']; ?>" class="btn btn-primary">Book Now</a>
                            <?php else: ?>
                                <a href="login.php" class="btn btn-outline-primary">Login to Book</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Notifications Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Latest Announcements</h2>
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="list-group">
                        <?php while($notif = mysqli_fetch_assoc($notifications_result)): ?>
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo htmlspecialchars($notif['title']); ?></h5>
                                <small><?php echo date('M d, Y', strtotime($notif['created_at'])); ?></small>
                            </div>
                            <p class="mb-1"><?php echo htmlspecialchars(substr($notif['message'], 0, 200)); ?>...</p>
                            <?php if($notif['priority'] == 'high'): ?>
                                <span class="badge bg-danger">Important</span>
                            <?php endif; ?>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>CLMS</h5>
                    <p>Computer Lab Management System</p>
                </div>
                <div class="col-md-6 text-end">
                    <p>&copy; <?php echo date('Y'); ?> CLMS. All rights reserved.</p>
                    <p>Contact: admin@clms.edu | Phone: (123) 456-7890</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>