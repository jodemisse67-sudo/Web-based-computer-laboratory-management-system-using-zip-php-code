<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        $authResult = 'authenticateUser'($username, $password);
        
        if ($authResult['success']) {
            'loginUser'($authResult['user']);
            
            // Redirect based on role
            $redirectUrl = isset($_SESSION['redirect_url']) ? $_SESSION['redirect_url'] : $authResult['user']['role'] . '_dashboard.php';
            unset($_SESSION['redirect_url']);
            
            header('Location: ' . $redirectUrl);
            exit();
        } else {
            $error = $authResult['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-sign-in-alt"></i> Welcome Back</h1>
                <p>Sign in to your CLMS account</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" class="auth-form">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username or Email
                    </label>
                    <input type="text" id="username" name="username" 
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                           required autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <input type="password" id="password" name="password" required>
                    <div class="password-toggle">
                        <i class="fas fa-eye" id="togglePassword"></i>
                    </div>
                </div>
                
                <div class="form-group remember-forgot">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember"> Remember me
                    </label>
                    <a href="forgot_password.php" class="forgot-link">Forgot Password?</a>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-sign-in-alt"></i> Sign In
                </button>
                
                <div class="auth-divider">
                    <span>Or continue with</span>
                </div>
                
                <div class="social-login">
                    <button type="button" class="btn btn-google">
                        <i class="fab fa-google"></i> Google
                    </button>
                    <button type="button" class="btn btn-microsoft">
                        <i class="fab fa-microsoft"></i> Microsoft
                    </button>
                </div>
            </form>
            
            <div class="demo-credentials">
                <h4><i class="fas fa-info-circle"></i> Demo Credentials</h4>
                <ul>
                    <li><strong>Admin:</strong> admin / admin123</li>
                    <li><strong>Student:</strong> student1 / admin123</li>
                    <li><strong>Faculty:</strong> faculty1 / admin123</li>
                    <li><strong>Technician:</strong> tech1 / admin123</li>
                </ul>
            </div>
            
            <div class="auth-footer">
                <p>Don't have an account? <a href="signup.php">Sign up here</a></p>
                <p><a href="index.php"><i class="fas fa-arrow-left"></i> Back to Home</a></p>
            </div>
        </div>
        
        <div class="auth-sidebar">
            <div class="auth-sidebar-content">
                <h2>Wachemo University</h2>
                <p class="campus">Durame Campus</p>
                <p class="quote">"Empowering Education Through Technology"</p>
                
                <div class="features-list">
                    <h3><i class="fas fa-check-circle"></i> Why Join CLMS?</h3>
                    <ul>
                        <li>✓ Easy Equipment Reservation</li>
                        <li>✓ Real-time Lab Status</li>
                        <li>✓ Automated Attendance</li>
                        <li>✓ Maintenance Requests</li>
                        <li>✓ Resource Management</li>
                    </ul>
                </div>
                
                <div class="stats">
                    <div class="stat">
                        <i class="fas fa-users"></i>
                        <span><?php echo count(getAllUsers()); ?>+ Users</span>
                    </div>
                    <div class="stat">
                        <i class="fas fa-desktop"></i>
                        <span><?php echo count(getAllEquipment()); ?>+ Equipment</span>
                    </div>
                    <div class="stat">
                        <i class="fas fa-building"></i>
                        <span><?php echo count(getAllLabs()); ?> Labs</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="js/script.js"></script>
    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
        
        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            
            if (!username || !password) {
                e.preventDefault();
                alert('Please fill in all fields');
                return false;
            }
            
            return true;
        });
    </script>
</body>
</html>