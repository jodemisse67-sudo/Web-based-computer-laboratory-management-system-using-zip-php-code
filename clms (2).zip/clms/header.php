<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

// Get current user's profile picture
$profile_pic = isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : 'default.jpg';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo 'SITE_NAME'; ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="images/logo-icon.png">
    
    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="<?php echo 'SITE_NAME'; ?>">
    <meta property="og:description" content="Computer Laboratory Management System - Wachemo University Durame Campus">
    <meta property="og:image" content="<?php echo 'BASE_URL'; ?>images/hero-bg.jpg">
    <meta property="og:url" content="<?php echo 'BASE_URL'; ?>">
    <meta property="og:type" content="website">
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo 'SITE_NAME'; ?>">
    <meta name="twitter:description" content="Computer Laboratory Management System - Wachemo University Durame Campus">
    <meta name="twitter:image" content="<?php echo 'BASE_URL'; ?>images/hero-bg.jpg">
    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <nav class="navbar">
                <div class="logo">
                    <a href="index.php">
                        <img src="images/logo.png" alt="Wachemo University Logo" class="logo-img">
                        <div class="logo-text">
                            <h1>WU CLMS</h1>
                            <p class="campus">Durame Campus</p>
                        </div>
                    </a>
                </div>
                
                <ul class="nav-menu">
                    <li><a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                        <i class="fas fa-home"></i> Home
                    </a></li>
                    
                    <?php if (isLoggedIn()): ?>
                        <li><a href="<?php echo 'USER_ROLE'; ?>_dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a></li>
                        
                        <?php if (isStudent()): ?>
                            <li><a href="make_reservation.php" class="nav-link">
                                <i class="fas fa-calendar-plus"></i> Reserve
                            </a></li>
                        <?php endif; ?>
                        
                        <?php if (isAdmin()): ?>
                            <li><a href="manage_accounts.php" class="nav-link">
                                <i class="fas fa-users-cog"></i> Manage
                            </a></li>
                        <?php endif; ?>
                        
                        <li><a href="view_notification.php" class="nav-link">
                            <i class="fas fa-bell"></i> Notifications
                            <?php
                            $conn = 'getConnection'();
                            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications 
                                                   WHERE (recipient_id = ? OR recipient_role = 'all') AND is_read = 0");
                            $stmt->execute([$_SESSION['user_id']]);
                            $result = $stmt->fetch();
                            if ($result['count'] > 0): ?>
                                <span class="badge badge-danger"><?php echo $result['count']; ?></span>
                            <?php endif; ?>
                        </a></li>
                    <?php endif; ?>
                    
                    <li><a href="about.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : ''; ?>">
                        <i class="fas fa-info-circle"></i> About
                    </a></li>
                    
                    <li><a href="#contact" class="nav-link">
                        <i class="fas fa-envelope"></i> Contact
                    </a></li>
                </ul>
                
                <div class="user-menu">
                    <?php if (isLoggedIn()): ?>
                        <div class="user-dropdown">
                            <img src="uploads/profile_pics/<?php echo htmlspecialchars($profile_pic); ?>" 
                                 alt="Profile" class="user-avatar" id="userDropdown" data-toggle="dropdown">
                            
                            <div class="dropdown-menu" id="dropdownMenu">
                                <div class="dropdown-header">
                                    <img src="uploads/profile_pics/<?php echo htmlspecialchars($profile_pic); ?>" 
                                         alt="Profile" class="dropdown-avatar">
                                    <div class="dropdown-user-info">
                                        <strong><?php echo htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']); ?></strong>
                                        <small><?php echo ucfirst($_SESSION['role']); ?></small>
                                    </div>
                                </div>
                                <a href="manage_personal_accounts.php" class="dropdown-item">
                                    <i class="fas fa-user-cog"></i> Profile Settings
                                </a>
                                <a href="view_reservations.php" class="dropdown-item">
                                    <i class="fas fa-calendar-alt"></i> My Reservations
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="logout.php" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                        <a href="signup.php" class="btn btn-outline btn-sm">
                            <i class="fas fa-user-plus"></i> Sign Up
                        </a>
                    <?php endif; ?>
                    
                    <button class="mobile-menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </nav>
        </div>
    </header>
    
    <main>