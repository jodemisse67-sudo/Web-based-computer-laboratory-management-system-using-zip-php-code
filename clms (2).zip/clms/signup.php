<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'username' => sanitize($_POST['username'] ?? ''),
        'email' => sanitize($_POST['email'] ?? ''),
        'password' => $_POST['password'] ?? '',
        'confirm_password' => $_POST['confirm_password'] ?? '',
        'first_name' => sanitize($_POST['first_name'] ?? ''),
        'last_name' => sanitize($_POST['last_name'] ?? ''),
        'phone' => sanitize($_POST['phone'] ?? ''),
        'department' => sanitize($_POST['department'] ?? ''),
        'student_id' => sanitize($_POST['student_id'] ?? ''),
        'role' => sanitize($_POST['role'] ?? 'student')
    ];
    
    // Validation
    if (empty($data['username']) || empty($data['email']) || empty($data['password']) || 
        empty($data['first_name']) || empty($data['last_name'])) {
        $error = 'Please fill in all required fields';
    } elseif ($data['password'] !== $data['confirm_password']) {
        $error = 'Passwords do not match';
    } elseif (strlen($data['password']) < 6) {
        $error = 'Password must be at least 6 characters long';
    } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address';
    } else {
        $registerResult = 'registerUser'($data);
        
        if ($registerResult['success']) {
            $success = 'Registration successful! You can now login.';
            $_POST = []; // Clear form
        } else {
            $error = $registerResult['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card signup-card">
            <div class="auth-header">
                <h1><i class="fas fa-user-plus"></i> Create Account</h1>
                <p>Join the Computer Laboratory Management System</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" class="auth-form" id="signupForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">
                            <i class="fas fa-user"></i> First Name *
                        </label>
                        <input type="text" id="first_name" name="first_name" 
                               value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">
                            <i class="fas fa-user"></i> Last Name *
                        </label>
                        <input type="text" id="last_name" name="last_name" 
                               value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-at"></i> Username *
                    </label>
                    <input type="text" id="username" name="username" 
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                    <small>Alphanumeric characters and underscores only</small>
                </div>
                
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i> Email *
                    </label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i> Password *
                        </label>
                        <input type="password" id="password" name="password" required>
                        <div class="password-strength" id="passwordStrength"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">
                            <i class="fas fa-lock"></i> Confirm Password *
                        </label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="phone">
                        <i class="fas fa-phone"></i> Phone Number
                    </label>
                    <input type="tel" id="phone" name="phone" 
                           value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="department">
                        <i class="fas fa-building"></i> Department
                    </label>
                    <select id="department" name="department">
                        <option value="">Select Department</option>
                        <option value="Computer Science" <?php echo ($_POST['department'] ?? '') == 'Computer Science' ? 'selected' : ''; ?>>Computer Science</option>
                        <option value="Information Technology" <?php echo ($_POST['department'] ?? '') == 'Information Technology' ? 'selected' : ''; ?>>Information Technology</option>
                        <option value="Software Engineering" <?php echo ($_POST['department'] ?? '') == 'Software Engineering' ? 'selected' : ''; ?>>Software Engineering</option>
                        <option value="Electrical Engineering" <?php echo ($_POST['department'] ?? '') == 'Electrical Engineering' ? 'selected' : ''; ?>>Electrical Engineering</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="student_id">
                        <i class="fas fa-id-card"></i> Student ID (if applicable)
                    </label>
                    <input type="text" id="student_id" name="student_id" 
                           value="<?php echo htmlspecialchars($_POST['student_id'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="role">
                        <i class="fas fa-user-tag"></i> Account Type *
                    </label>
                    <select id="role" name="role" required>
                        <option value="student" <?php echo ($_POST['role'] ?? 'student') == 'student' ? 'selected' : ''; ?>>Student</option>
                        <option value="faculty" <?php echo ($_POST['role'] ?? '') == 'faculty' ? 'selected' : ''; ?>>Faculty</option>
                        <option value="instructor" <?php echo ($_POST['role'] ?? '') == 'instructor' ? 'selected' : ''; ?>>Instructor</option>
                    </select>
                </div>
                
                <div class="form-group terms">
                    <label class="checkbox-label">
                        <input type="checkbox" name="terms" required>
                        I agree to the <a href="terms.php">Terms of Service</a> and <a href="privacy.php">Privacy Policy</a>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </form>
            
            <div class="auth-footer">
                <p>Already have an account? <a href="login.php">Login here</a></p>
                <p><a href="index.php"><i class="fas fa-arrow-left"></i> Back to Home</a></p>
            </div>
        </div>
        
        <div class="auth-sidebar">
            <div class="auth-sidebar-content">
                <h2>Join Our Community</h2>
                <p class="campus">Wachemo University Durame Campus</p>
                <p class="quote">"Technology at Your Fingertips"</p>
                
                <div class="benefits">
                    <h3><i class="fas fa-star"></i> Benefits of Joining</h3>
                    <ul>
                        <li><i class="fas fa-check"></i> Reserve equipment easily</li>
                        <li><i class="fas fa-check"></i> Track lab sessions</li>
                        <li><i class="fas fa-check"></i> Receive notifications</li>
                        <li><i class="fas fa-check"></i> Request resources</li>
                        <li><i class="fas fa-check"></i> View schedules</li>
                        <li><i class="fas fa-check"></i> Generate reports</li>
                    </ul>
                </div>
                
                <div class="security-info">
                    <h4><i class="fas fa-shield-alt"></i> Your Security Matters</h4>
                    <p>All passwords are encrypted and your data is protected.</p>
                </div>
            </div>
        </div>
    </div>
    
    <script src="js/script.js"></script>
    <script>
        // Password strength checker
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthDiv = document.getElementById('passwordStrength');
            
            let strength = 0;
            let message = '';
            let color = '#e74c3c';
            let width = '0%';
            
            // Length check
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            
            // Complexity checks
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            switch (strength) {
                case 0:
                case 1:
                    message = 'Very Weak';
                    color = '#e74c3c';
                    width = '20%';
                    break;
                case 2:
                    message = 'Weak';
                    color = '#e67e22';
                    width = '40%';
                    break;
                case 3:
                    message = 'Good';
                    color = '#f1c40f';
                    width = '60%';
                    break;
                case 4:
                    message = 'Strong';
                    color = '#2ecc71';
                    width = '80%';
                    break;
                case 5:
                    message = 'Very Strong';
                    color = '#27ae60';
                    width = '100%';
                    break;
            }
            
            strengthDiv.innerHTML = `
                <div class="strength-bar" style="background: ${color}; width: ${width}"></div>
                <div class="strength-text">Strength: ${message}</div>
            `;
        });
        
        // Form validation
        document.getElementById('signupForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const email = document.getElementById('email').value;
            const username = document.getElementById('username').value;
            const terms = document.querySelector('input[name="terms"]');
            
            // Password validation
            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long');
                return false;
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match');
                return false;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Please enter a valid email address');
                return false;
            }
            
            // Username validation
            const usernameRegex = /^[a-zA-Z0-9_]+$/;
            if (!usernameRegex.test(username)) {
                e.preventDefault();
                alert('Username can only contain letters, numbers, and underscores');
                return false;
            }
            
            // Terms check
            if (!terms.checked) {
                e.preventDefault();
                alert('You must agree to the terms and conditions');
                return false;
            }
            
            return true;
        });
    </script>
</body>
</html>