<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Handle resource request submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_request'])) {
    $request_type = $_POST['request_type'];
    $lab_id = $_POST['lab_id'];
    $equipment_id = $_POST['equipment_id'];
    $description = $_POST['description'];
    $priority = $_POST['priority'];
    
    $sql = "INSERT INTO resource_requests 
            (user_id, request_type, lab_id, equipment_id, description, priority, status) 
            VALUES (?, ?, ?, ?, ?, ?, 'pending')";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "isiiis", $user_id, $request_type, $lab_id, 
                          $equipment_id, $description, $priority);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = "<div class='alert alert-success'>Resource request submitted successfully</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error submitting request: " . mysqli_error($conn) . "</div>";
    }
}

// Get user's previous requests
$user_requests_sql = "SELECT r.*, l.lab_name, e.equipment_name 
                     FROM resource_requests r 
                     LEFT JOIN labs l ON r.lab_id = l.lab_id 
                     LEFT JOIN equipment e ON r.equipment_id = e.equipment_id 
                     WHERE r.user_id = ? 
                     ORDER BY r.created_at DESC";
$user_requests_stmt = mysqli_prepare($conn, $user_requests_sql);
mysqli_stmt_bind_param($user_requests_stmt, "i", $user_id);
mysqli_stmt_execute($user_requests_stmt);
$user_requests_result = mysqli_stmt_get_result($user_requests_stmt);

// Get labs for dropdown
$labs_sql = "SELECT * FROM labs WHERE status = 'active' ORDER BY lab_name";
$labs_result = mysqli_query($conn, $labs_sql);

// Get available equipment
$equipment_sql = "SELECT * FROM equipment WHERE status = 'working' ORDER BY equipment_name";
$equipment_result = mysqli_query($conn, $equipment_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Resources - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>Request Resources</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <!-- Request Form -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Submit Resource Request</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Request Type</label>
                                <select class="form-select" name="request_type" id="requestType" required 
                                        onchange="toggleRequestFields()">
                                    <option value="">Select Type</option>
                                    <option value="lab_access">Lab Access Request</option>
                                    <option value="equipment">Equipment Request</option>
                                    <option value="maintenance">Maintenance Request</option>
                                    <option value="software">Software Installation</option>
                                    <option value="other">Other Request</option>
                                </select>
                            </div>
                            
                            <div class="mb-3" id="labField" style="display: none;">
                                <label class="form-label">Select Lab</label>
                                <select class="form-select" name="lab_id">
                                    <option value="">Select Lab</option>
                                    <?php while ($lab = mysqli_fetch_assoc($labs_result)): ?>
                                    <option value="<?php echo $lab['lab_id']; ?>">
                                        <?php echo htmlspecialchars($lab['lab_name']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3" id="equipmentField" style="display: none;">
                                <label class="form-label">Select Equipment</label>
                                <select class="form-select" name="equipment_id">
                                    <option value="">Select Equipment</option>
                                    <?php while ($equip = mysqli_fetch_assoc($equipment_result)): ?>
                                    <option value="<?php echo $equip['equipment_id']; ?>">
                                        <?php echo htmlspecialchars($equip['equipment_name']); ?>
                                        <?php if($equip['lab_id']): ?>
                                            (Lab: <?php 
                                                $lab_name_sql = "SELECT lab_name FROM labs WHERE lab_id = ?";
                                                $lab_name_stmt = mysqli_prepare($conn, $lab_name_sql);
                                                mysqli_stmt_bind_param($lab_name_stmt, "i", $equip['lab_id']);
                                                mysqli_stmt_execute($lab_name_stmt);
                                                $lab_name_result = mysqli_stmt_get_result($lab_name_stmt);
                                                $lab_name = mysqli_fetch_assoc($lab_name_result)['lab_name'];
                                                echo htmlspecialchars($lab_name);
                                            ?>)
                                        <?php endif; ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="4" required 
                                          placeholder="Please describe your request in detail..."></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Priority</label>
                                <select class="form-select" name="priority" required>
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                </select>
                            </div>
                            
                            <button type="submit" name="submit_request" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i> Submit Request
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Guidelines -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Request Guidelines</h5>
                    </div>
                    <div class="card-body">
                        <ul class="small">
                            <li>Provide clear and detailed description of your request</li>
                            <li>Use High priority only for urgent matters</li>
                            <li>Lab access requests require at least 24 hours notice</li>
                            <li>Equipment requests should include specific equipment name</li>
                            <li>Maintenance requests should describe the issue clearly</li>
                            <li>You will be notified via email about request status</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- My Requests -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>My Resource Requests</h5>
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($user_requests_result) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Type</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($req = mysqli_fetch_assoc($user_requests_result)): ?>
                                    <tr>
                                        <td><?php echo $req['request_id']; ?></td>
                                        <td><?php echo ucfirst(str_replace('_', ' ', $req['request_type'])); ?></td>
                                        <td><?php echo htmlspecialchars(substr($req['description'], 0, 50)); ?>...</td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                switch($req['status']) {
                                                    case 'approved': echo 'success'; break;
                                                    case 'pending': echo 'warning'; break;
                                                    case 'cancelled': echo 'secondary'; break;
                                                    case 'rejected': echo 'danger'; break;
                                                    default: echo 'primary';
                                                }
                                            ?>">
                                                <?php echo ucfirst($req['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d', strtotime($req['created_at'])); ?></td>
                                        <td>
                                            <a href="view_request.php?id=<?php echo $req['request_id']; ?>" 
                                               class="btn btn-sm btn-info">
                                               <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-info">
                            <p class="mb-0">You haven't submitted any resource requests yet.</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Request Statistics -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Request Statistics</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        // Get user's request stats
                        $stats_sql = "SELECT status, COUNT(*) as count 
                                     FROM resource_requests 
                                     WHERE user_id = ? 
                                     GROUP BY status";
                        $stats_stmt = mysqli_prepare($conn, $stats_sql);
                        mysqli_stmt_bind_param($stats_stmt, "i", $user_id);
                        mysqli_stmt_execute($stats_stmt);
                        $stats_result = mysqli_stmt_get_result($stats_stmt);
                        ?>
                        
                        <div class="row">
                            <?php while ($stat = mysqli_fetch_assoc($stats_result)): ?>
                            <div class="col-md-6 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <h3><?php echo $stat['count']; ?></h3>
                                    <small class="text-muted"><?php echo ucfirst($stat['status']); ?></small>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        
                        <?php if($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'lab_manager'): ?>
                        <hr>
                        <div class="text-center">
                            <a href="manage_requests.php" class="btn btn-sm btn-outline-primary">
                                Manage All Requests
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function toggleRequestFields() {
        var requestType = document.getElementById('requestType').value;
        var labField = document.getElementById('labField');
        var equipmentField = document.getElementById('equipmentField');
        
        // Reset
        labField.style.display = 'none';
        equipmentField.style.display = 'none';
        
        // Show relevant fields based on request type
        if (requestType === 'lab_access') {
            labField.style.display = 'block';
        } else if (requestType === 'equipment') {
            equipmentField.style.display = 'block';
        } else if (requestType === 'maintenance') {
            equipmentField.style.display = 'block';
        }
    }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>