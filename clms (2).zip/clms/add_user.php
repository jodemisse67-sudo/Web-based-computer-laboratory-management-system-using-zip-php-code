<?php
session_start();
require_once 'config.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$message = "";

// Add new user
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $full_name = $_POST['full_name'];
    $role = $_POST['role'];
    $department = $_POST['department'];
    $phone = $_POST['phone'];
    
    // Check if username exists
    $check_sql = "SELECT * FROM users WHERE username = ? OR email = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "ss", $username, $email);
    mysqli_stmt_execute($check_stmt);
    $result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($result) > 0) {
        $message = "<div class='alert alert-danger'>Username or email already exists</div>";
    } else {
        $sql = "INSERT INTO users (username, password, email, full_name, role, department, phone) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssssss", $username, $password, $email, $full_name, $role, $department, $phone);
        
        if (mysqli_stmt_execute($stmt)) {
            $new_user_id = mysqli_insert_id($conn);
            
            // Send welcome email (optional)
            // mail($email, "Welcome to CLMS", "Your account has been created. Username: $username");
            
            $message = "<div class='alert alert-success'>User added successfully! User ID: $new_user_id</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error adding user: " . mysqli_error($conn) . "</div>";
        }
    }
}

// Bulk upload via CSV
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bulk_upload'])) {
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
        $file = $_FILES['csv_file']['tmp_name'];
        
        if (($handle = fopen($file, "r")) !== FALSE) {
            $success_count = 0;
            $error_count = 0;
            
            // Skip header row
            fgetcsv($handle);
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                if (count($data) >= 6) {
                    $username = $data[0];
                    $email = $data[1];
                    $full_name = $data[2];
                    $role = $data[3];
                    $department = $data[4];
                    $phone = $data[5];
                    $temp_password = $data[6] ?? 'password123'; // Default password
                    
                    // Generate username if not provided
                    if (empty($username)) {
                        $username = strtolower(str_replace(' ', '.', $full_name));
                    }
                    
                    // Check if user exists
                    $check_sql = "SELECT * FROM users WHERE username = ? OR email = ?";
                    $check_stmt = mysqli_prepare($conn, $check_sql);
                    mysqli_stmt_bind_param($check_stmt, "ss", $username, $email);
                    mysqli_stmt_execute($check_stmt);
                    
                    if (mysqli_num_rows(mysqli_stmt_get_result($check_stmt)) == 0) {
                        $password = password_hash($temp_password, PASSWORD_DEFAULT);
                        
                        $sql = "INSERT INTO users (username, password, email, full_name, role, department, phone) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)";
                        $stmt = mysqli_prepare($conn, $sql);
                        mysqli_stmt_bind_param($stmt, "sssssss", $username, $password, $email, $full_name, $role, $department, $phone);
                        
                        if (mysqli_stmt_execute($stmt)) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                    } else {
                        $error_count++;
                    }
                }
            }
            fclose($handle);
            
            $message = "<div class='alert alert-success'>Bulk upload completed: $success_count users added, $error_count errors</div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>Please select a CSV file</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>Add New User</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <!-- Manual Add Form -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Add Single User</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Username *</label>
                                <input type="text" class="form-control" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Temporary Password *</label>
                                <input type="text" class="form-control" name="password" value="password123" required>
                                <small class="text-muted">User should change this on first login</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email Address *</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" class="form-control" name="full_name" required>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Role *</label>
                                    <select class="form-select" name="role" required>
                                        <option value="student">Student</option>
                                        <option value="faculty">Faculty</option>
                                        <option value="lab_manager">Lab Manager</option>
                                        <option value="admin">Administrator</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Department</label>
                                    <input type="text" class="form-control" name="department">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" name="phone">
                            </div>
                            <button type="submit" name="add_user" class="btn btn-primary">Add User</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Bulk Upload -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Bulk Upload Users (CSV)</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Select CSV File</label>
                                <input type="file" class="form-control" name="csv_file" accept=".csv" required>
                                <small class="text-muted">
                                    CSV Format: username,email,full_name,role,department,phone,temporary_password<br>
                                    <a href="sample_users.csv" class="btn btn-sm btn-outline-primary mt-2">
                                        <i class="fas fa-download"></i> Download Sample CSV
                                    </a>
                                </small>
                            </div>
                            <div class="alert alert-info">
                                <h6>Instructions:</h6>
                                <ol class="mb-0">
                                    <li>Download sample CSV file</li>
                                    <li>Fill user details</li>
                                    <li>Upload the CSV file</li>
                                    <li>Users will be added with default password</li>
                                </ol>
                            </div>
                            <button type="submit" name="bulk_upload" class="btn btn-success">
                                <i class="fas fa-upload"></i> Upload CSV
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Quick Stats -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>User Statistics</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $stats_sql = "SELECT role, COUNT(*) as count FROM users GROUP BY role";
                        $stats_result = mysqli_query($conn, $stats_sql);
                        ?>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Role</th>
                                    <th>Count</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total_sql = "SELECT COUNT(*) as total FROM users";
                                $total_result = mysqli_query($conn, $total_sql);
                                $total = mysqli_fetch_assoc($total_result)['total'];
                                
                                while ($stat = mysqli_fetch_assoc($stats_result)): 
                                    $percentage = round(($stat['count'] / $total) * 100, 1);
                                ?>
                                <tr>
                                    <td><?php echo ucfirst($stat['role']); ?></td>
                                    <td><?php echo $stat['count']; ?></td>
                                    <td>
                                        <div class="progress" style="height: 10px;">
                                            <div class="progress-bar" style="width: <?php echo $percentage; ?>%"></div>
                                        </div>
                                        <small><?php echo $percentage; ?>%</small>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                            <tfoot>
                                <tr class="table-primary">
                                    <td><strong>Total Users</strong></td>
                                    <td colspan="2"><strong><?php echo $total; ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Users -->
        <div class="card mt-4">
            <div class="card-header d-flex justify-content-between">
                <h5>Recently Added Users</h5>
                <a href="manage_users.php" class="btn btn-sm btn-primary">Manage All Users</a>
            </div>
            <div class="card-body">
                <?php
                $recent_sql = "SELECT * FROM users ORDER BY user_id DESC LIMIT 10";
                $recent_result = mysqli_query($conn, $recent_sql);
                ?>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Joined</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($user = mysqli_fetch_assoc($recent_result)): ?>
                            <tr>
                                <td><?php echo $user['user_id']; ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <span class="badge bg-<?php 
                                        switch($user['role']) {
                                            case 'admin': echo 'danger'; break;
                                            case 'faculty': echo 'success'; break;
                                            case 'lab_manager': echo 'warning'; break;
                                            default: echo 'primary';
                                        }
                                    ?>"><?php echo ucfirst($user['role']); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($user['department']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>