<?php
session_start();
require_once 'config.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$message = "";

// Add new lab
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_lab'])) {
    $lab_name = $_POST['lab_name'];
    $capacity = $_POST['capacity'];
    $description = $_POST['description'];
    $equipment = $_POST['equipment'];
    
    $sql = "INSERT INTO labs (lab_name, capacity, description, equipment, status) 
            VALUES (?, ?, ?, ?, 'active')";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "siss", $lab_name, $capacity, $description, $equipment);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = "<div class='alert alert-success'>Lab added successfully</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error adding lab: " . mysqli_error($conn) . "</div>";
    }
}

// Delete lab
if (isset($_GET['delete'])) {
    $lab_id = $_GET['delete'];
    
    // Check if lab has active reservations
    $check_sql = "SELECT * FROM reservations WHERE lab_id = ? AND status = 'approved' 
                  AND reservation_date >= CURDATE()";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "i", $lab_id);
    mysqli_stmt_execute($check_stmt);
    $result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($result) > 0) {
        $message = "<div class='alert alert-danger'>Cannot delete lab with active reservations</div>";
    } else {
        $delete_sql = "DELETE FROM labs WHERE lab_id = ?";
        $delete_stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($delete_stmt, "i", $lab_id);
        
        if (mysqli_stmt_execute($delete_stmt)) {
            $message = "<div class='alert alert-success'>Lab deleted successfully</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error deleting lab</div>";
        }
    }
}

// Get all labs
$labs_sql = "SELECT * FROM labs ORDER BY lab_name";
$labs_result = mysqli_query($conn, $labs_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Labs - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>Manage Computer Labs</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Add New Lab</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Lab Name</label>
                                <input type="text" class="form-control" name="lab_name" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Capacity</label>
                                <input type="number" class="form-control" name="capacity" required min="1">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Equipment</label>
                                <textarea class="form-control" name="equipment" rows="3"></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="3"></textarea>
                            </div>
                            <button type="submit" name="add_lab" class="btn btn-primary">Add Lab</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5>Existing Labs</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Lab Name</th>
                                        <th>Capacity</th>
                                        <th>Equipment</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($lab = mysqli_fetch_assoc($labs_result)): ?>
                                    <tr>
                                        <td><?php echo $lab['lab_id']; ?></td>
                                        <td><?php echo htmlspecialchars($lab['lab_name']); ?></td>
                                        <td><?php echo $lab['capacity']; ?></td>
                                        <td><?php echo htmlspecialchars(substr($lab['equipment'], 0, 50)); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $lab['status'] == 'active' ? 'success' : 'danger'; ?>">
                                                <?php echo $lab['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="edit_lab.php?id=<?php echo $lab['lab_id']; ?>" 
                                               class="btn btn-sm btn-warning">
                                               <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="?delete=<?php echo $lab['lab_id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Delete this lab?')">
                                               <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>