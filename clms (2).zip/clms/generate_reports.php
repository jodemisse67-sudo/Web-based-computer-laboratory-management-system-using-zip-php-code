<?php
session_start();
require_once 'config.php';

// Check if admin or lab manager
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'lab_manager')) {
    header("Location: login.php");
    exit();
}

$message = "";
$report_data = [];

// Generate report
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['generate_report'])) {
    $report_type = $_POST['report_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $lab_id = $_POST['lab_id'];
    $format = $_POST['format'];
    
    // Build report based on type
    switch ($report_type) {
        case 'reservation_summary':
            $sql = "SELECT r.*, l.lab_name, u.full_name, u.username 
                   FROM reservations r 
                   JOIN labs l ON r.lab_id = l.lab_id 
                   JOIN users u ON r.user_id = u.user_id 
                   WHERE r.reservation_date BETWEEN ? AND ? ";
            
            if ($lab_id != 'all') {
                $sql .= "AND r.lab_id = ? ";
                $sql .= "ORDER BY r.reservation_date, r.start_time";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ssi", $start_date, $end_date, $lab_id);
            } else {
                $sql .= "ORDER BY r.reservation_date, r.start_time";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
            }
            break;
            
        case 'lab_utilization':
            $sql = "SELECT l.lab_name, 
                    COUNT(r.reservation_id) as total_reservations,
                    SUM(TIMESTAMPDIFF(HOUR, r.start_time, r.end_time)) as total_hours,
                    AVG(TIMESTAMPDIFF(HOUR, r.start_time, r.end_time)) as avg_hours,
                    COUNT(DISTINCT r.user_id) as unique_users
                   FROM labs l 
                   LEFT JOIN reservations r ON l.lab_id = r.lab_id 
                   AND r.reservation_date BETWEEN ? AND ? 
                   AND r.status = 'approved' 
                   WHERE 1=1 ";
            
            if ($lab_id != 'all') {
                $sql .= "AND l.lab_id = ? ";
                $sql .= "GROUP BY l.lab_id ORDER BY total_reservations DESC";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ssi", $start_date, $end_date, $lab_id);
            } else {
                $sql .= "GROUP BY l.lab_id ORDER BY total_reservations DESC";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
            }
            break;
            
        case 'user_activity':
            $sql = "SELECT u.user_id, u.username, u.full_name, u.role,
                    COUNT(r.reservation_id) as total_reservations,
                    SUM(CASE WHEN r.status = 'approved' THEN 1 ELSE 0 END) as approved,
                    SUM(CASE WHEN r.status = 'pending' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN r.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
                   FROM users u 
                   LEFT JOIN reservations r ON u.user_id = r.user_id 
                   AND r.reservation_date BETWEEN ? AND ? 
                   WHERE u.role IN ('student', 'faculty') ";
            
            $sql .= "GROUP BY u.user_id ORDER BY total_reservations DESC";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
            break;
            
        case 'equipment_status':
            $sql = "SELECT e.*, l.lab_name 
                   FROM equipment e 
                   LEFT JOIN labs l ON e.lab_id = l.lab_id ";
            
            if ($lab_id != 'all') {
                $sql .= "WHERE e.lab_id = ? ";
                $sql .= "ORDER BY e.status, e.equipment_name";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $lab_id);
            } else {
                $sql .= "ORDER BY e.status, e.equipment_name";
                $stmt = mysqli_prepare($conn, $sql);
            }
            break;
    }
    
    mysqli_stmt_execute($stmt);
    $report_data = mysqli_stmt_get_result($stmt);
    
    // Export to CSV if requested
    if ($format == 'csv' && mysqli_num_rows($report_data) > 0) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="clms_report_' . date('Ymd_His') . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        // Add headers
        $headers = [];
        $row = mysqli_fetch_assoc($report_data);
        if ($row) {
            $headers = array_keys($row);
            fputcsv($output, $headers);
            fputcsv($output, $row);
            
            while ($row = mysqli_fetch_assoc($report_data)) {
                fputcsv($output, $row);
            }
        }
        
        fclose($output);
        exit();
    }
}

// Get labs for filter
$labs_sql = "SELECT * FROM labs WHERE status = 'active' ORDER BY lab_name";
$labs_result = mysqli_query($conn, $labs_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2>Generate Reports</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <!-- Report Parameters -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Report Parameters</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Report Type</label>
                                <select class="form-select" name="report_type" id="reportType" onchange="toggleLabFilter()">
                                    <option value="reservation_summary">Reservation Summary</option>
                                    <option value="lab_utilization">Lab Utilization</option>
                                    <option value="user_activity">User Activity</option>
                                    <option value="equipment_status">Equipment Status</option>
                                </select>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Start Date</label>
                                    <input type="date" class="form-control" name="start_date" 
                                           value="<?php echo date('Y-m-d', strtotime('-1 month')); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">End Date</label>
                                    <input type="date" class="form-control" name="end_date" 
                                           value="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3" id="labFilter">
                                <label class="form-label">Lab (Optional)</label>
                                <select class="form-select" name="lab_id">
                                    <option value="all">All Labs</option>
                                    <?php while ($lab = mysqli_fetch_assoc($labs_result)): ?>
                                    <option value="<?php echo $lab['lab_id']; ?>">
                                        <?php echo htmlspecialchars($lab['lab_name']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Output Format</label>
                                <select class="form-select" name="format">
                                    <option value="html">HTML (View in Browser)</option>
                                    <option value="csv">CSV (Download)</option>
                                </select>
                            </div>
                            
                            <button type="submit" name="generate_report" class="btn btn-primary">
                                <i class="fas fa-chart-bar"></i> Generate Report
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Quick Stats -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Quick Statistics</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        // Today's reservations
                        $today_sql = "SELECT COUNT(*) as count FROM reservations 
                                     WHERE reservation_date = CURDATE() AND status = 'approved'";
                        $today_result = mysqli_query($conn, $today_sql);
                        $today = mysqli_fetch_assoc($today_result)['count'];
                        
                        // This week's reservations
                        $week_sql = "SELECT COUNT(*) as count FROM reservations 
                                    WHERE reservation_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE() 
                                    AND status = 'approved'";
                        $week_result = mysqli_query($conn, $week_sql);
                        $week = mysqli_fetch_assoc($week_result)['count'];
                        
                        // Active equipment
                        $equip_sql = "SELECT COUNT(*) as count FROM equipment WHERE status = 'working'";
                        $equip_result = mysqli_query($conn, $equip_sql);
                        $equipment = mysqli_fetch_assoc($equip_result)['count'];
                        ?>
                        
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Today's Reservations</span>
                                <span class="badge bg-primary rounded-pill"><?php echo $today; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>This Week's Reservations</span>
                                <span class="badge bg-success rounded-pill"><?php echo $week; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Active Equipment</span>
                                <span class="badge bg-info rounded-pill"><?php echo $equipment; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Active Labs</span>
                                <span class="badge bg-warning rounded-pill">
                                    <?php echo mysqli_num_rows($labs_result); ?>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Report Results -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Report Results</h5>
                        <?php if (!empty($report_data) && mysqli_num_rows($report_data) > 0): ?>
                        <button class="btn btn-sm btn-success" onclick="window.print()">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($report_data) && mysqli_num_rows($report_data) > 0): 
                            $first_row = mysqli_fetch_assoc($report_data);
                            mysqli_data_seek($report_data, 0);
                        ?>
                        <div class="alert alert-info">
                            Report generated on <?php echo date('F d, Y h:i A'); ?> | 
                            <?php echo mysqli_num_rows($report_data); ?> records found
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead class="table-dark">
                                    <tr>
                                        <?php foreach (array_keys($first_row) as $header): ?>
                                        <th><?php echo ucwords(str_replace('_', ' ', $header)); ?></th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = mysqli_fetch_assoc($report_data)): ?>
                                    <tr>
                                        <?php foreach ($row as $cell): ?>
                                        <td><?php echo htmlspecialchars($cell); ?></td>
                                        <?php endforeach; ?>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Visualization -->
                        <div class="mt-4" id="chartContainer">
                            <canvas id="reportChart" height="100"></canvas>
                        </div>
                        
                        <?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
                        <div class="alert alert-warning">
                            No data found for the selected criteria
                        </div>
                        <?php else: ?>
                        <div class="alert alert-info">
                            Select parameters and generate report to view data
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Pre-defined Reports -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Quick Reports</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <a href="?quick=weekly" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-calendar-week"></i><br>
                                    Weekly Summary
                                </a>
                            </div>
                            <div class="col-md-4 mb-3">
                                <a href="?quick=monthly" class="btn btn-outline-success w-100">
                                    <i class="fas fa-chart-line"></i><br>
                                    Monthly Trends
                                </a>
                            </div>
                            <div class="col-md-4 mb-3">
                                <a href="?quick=equipment" class="btn btn-outline-warning w-100">
                                    <i class="fas fa-desktop"></i><br>
                                    Equipment Report
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function toggleLabFilter() {
        var reportType = document.getElementById('reportType').value;
        var labFilter = document.getElementById('labFilter');
        
        if (reportType == 'user_activity') {
            labFilter.style.display = 'none';
        } else {
            labFilter.style.display = 'block';
        }
    }
    
    <?php if (!empty($report_data) && $_POST['report_type'] == 'lab_utilization'): 
        mysqli_data_seek($report_data, 0);
        $labels = [];
        $data = [];
        
        while ($row = mysqli_fetch_assoc($report_data)) {
            $labels[] = $row['lab_name'];
            $data[] = $row['total_reservations'];
        }
    ?>
    // Create chart for lab utilization report
    var ctx = document.getElementById('reportChart').getContext('2d');
    var reportChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Number of Reservations',
                data: <?php echo json_encode($data); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Reservations Count'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Labs'
                    }
                }
            }
        }
    });
    <?php endif; ?>
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>