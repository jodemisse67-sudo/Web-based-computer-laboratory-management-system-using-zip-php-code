<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$request_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Get request details
$sql = "SELECT r.*, u.full_name, u.email, u.phone, l.lab_name,
               e.equipment_name, e.status as equipment_status
        FROM resource_requests r
        LEFT JOIN users u ON r.user_id = u.user_id
        LEFT JOIN labs l ON r.lab_id = l.lab_id
        LEFT JOIN equipment e ON r.equipment_id = e.equipment_id
        WHERE r.request_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $request_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    header("Location: dashboard.php");
    exit();
}

$request = mysqli_fetch_assoc($result);

// Check permissions
if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'lab_manager' && $request['user_id'] != $user_id) {
    header("Location: dashboard.php");
    exit();
}

// Handle request action
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['approve_request'])) {
        $action = 'approved';
        $admin_notes = $_POST['admin_notes'];
    } elseif (isset($_POST['reject_request'])) {
        $action = 'rejected';
        $admin_notes = $_POST['admin_notes'];
    } elseif (isset($_POST['cancel_request'])) {
        $action = 'cancelled';
    }
    
    $update_sql = "UPDATE resource_requests SET status = ?, admin_notes = ?, 
                   action_date = NOW(), action_by = ? WHERE request_id = ?";
    $update_stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($update_stmt, "ssii", $action, $admin_notes, $_SESSION['user_id'], $request_id);
    
    if (mysqli_stmt_execute($update_stmt)) {
        // Redirect to avoid form resubmission
        header("Location: view_request.php?id=" . $request_id);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Request - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="request_resources.php">Resource Requests</a></li>
                <li class="breadcrumb-item active">Request Details</li>
            </ol>
        </nav>
        
        <h2>Resource Request Details</h2>
        
        <div class="row">
            <!-- Request Info -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Request Information</h5>
                        <span class="badge bg-<?php 
                            switch($request['status']) {
                                case 'approved': echo 'success'; break;
                                case 'pending': echo 'warning'; break;
                                case 'cancelled': echo 'secondary'; break;
                                case 'rejected': echo 'danger'; break;
                                default: echo 'primary';
                            }
                        ?>">
                            <?php echo ucfirst($request['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <th width="30%">Request ID</th>
                                <td><?php echo $request['request_id']; ?></td>
                            </tr>
                            <tr>
                                <th>Request Type</th>
                                <td><?php echo ucfirst($request['request_type']); ?></td>
                            </tr>
                            <?php if($request['lab_id']): ?>
                            <tr>
                                <th>Lab</th>
                                <td><?php echo htmlspecialchars($request['lab_name']); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($request['equipment_id']): ?>
                            <tr>
                                <th>Equipment</th>
                                <td>
                                    <?php echo htmlspecialchars($request['equipment_name']); ?>
                                    <span class="badge bg-<?php 
                                        switch($request['equipment_status']) {
                                            case 'working': echo 'success'; break;
                                            case 'maintenance': echo 'warning'; break;
                                            default: echo 'secondary';
                                        }
                                    ?> ms-2">
                                        <?php echo $request['equipment_status']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th>User</th>
                                <td>
                                    <?php echo htmlspecialchars($request['full_name']); ?><br>
                                    <small><?php echo htmlspecialchars($request['email']); ?></small>
                                </td>
                            </tr>
                            <tr>
                                <th>Description</th>
                                <td><?php echo nl2br(htmlspecialchars($request['description'])); ?></td>
                            </tr>
                            <tr>
                                <th>Priority</th>
                                <td>
                                    <span class="badge bg-<?php 
                                        switch($request['priority']) {
                                            case 'high': echo 'danger'; break;
                                            case 'medium': echo 'warning'; break;
                                            case 'low': echo 'info'; break;
                                        }
                                    ?>">
                                        <?php echo ucfirst($request['priority']); ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th>Requested Date</th>
                                <td><?php echo date('F d, Y', strtotime($request['request_date'])); ?></td>
                            </tr>
                            <tr>
                                <th>Created On</th>
                                <td><?php echo date('F d, Y h:i A', strtotime($request['created_at'])); ?></td>
                            </tr>
                            <?php if($request['admin_notes']): ?>
                            <tr>
                                <th>Admin Notes</th>
                                <td><?php echo nl2br(htmlspecialchars($request['admin_notes'])); ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="card-footer">
                        <?php if($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'lab_manager'): ?>
                            <?php if($request['status'] == 'pending'): ?>
                            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#approveModal">
                                Approve Request
                            </button>
                            <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                Reject Request
                            </button>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <?php if($request['user_id'] == $user_id && $request['status'] == 'pending'): ?>
                        <a href="cancel_request.php?id=<?php echo $request_id; ?>" 
                           class="btn btn-warning"
                           onclick="return confirm('Cancel this request?')">Cancel Request</a>
                        <?php endif; ?>
                        
                        <a href="request_resources.php" class="btn btn-secondary">Back to List</a>
                    </div>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="col-md-4">
                <!-- Request Timeline -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Request Timeline</h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            <div class="timeline-item <?php echo $request['status'] != 'pending' ? 'completed' : ''; ?>">
                                <div class="timeline-marker"></div>
                                <div class="timeline-content">
                                    <h6>Request Submitted</h6>
                                    <small><?php echo date('M d, g:i A', strtotime($request['created_at'])); ?></small>
                                </div>
                            </div>
                            
                            <?php if($request['status'] != 'pending'): ?>
                            <div class="timeline-item completed">
                                <div class="timeline-marker"></div>
                                <div class="timeline-content">
                                    <h6>Request <?php echo ucfirst($request['status']); ?></h6>
                                    <small><?php echo date('M d, g:i A', strtotime($request['action_date'])); ?></small>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Contact Info -->
                <div class="card">
                    <div class="card-header">
                        <h5>Contact Information</h5>
                    </div>
                    <div class="card-body">
                        <p>
                            <i class="fas fa-user me-2"></i>
                            <?php echo htmlspecialchars($request['full_name']); ?>
                        </p>
                        <p>
                            <i class="fas fa-envelope me-2"></i>
                            <?php echo htmlspecialchars($request['email']); ?>
                        </p>
                        <?php if($request['phone']): ?>
                        <p>
                            <i class="fas fa-phone me-2"></i>
                            <?php echo htmlspecialchars($request['phone']); ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Approve Modal -->
    <div class="modal fade" id="approveModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="">
                    <div class="modal-header">
                        <h5 class="modal-title">Approve Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Notes (Optional)</label>
                            <textarea class="form-control" name="admin_notes" rows="3" 
                                      placeholder="Add any notes or instructions..."></textarea>
                        </div>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            This request will be approved and the user will be notified.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="approve_request" class="btn btn-success">Approve</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Reject Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="">
                    <div class="modal-header">
                        <h5 class="modal-title">Reject Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Reason for Rejection</label>
                            <textarea class="form-control" name="admin_notes" rows="3" required 
                                      placeholder="Please provide a reason for rejection..."></textarea>
                        </div>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i>
                            This request will be rejected and the user will be notified.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="reject_request" class="btn btn-danger">Reject</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>