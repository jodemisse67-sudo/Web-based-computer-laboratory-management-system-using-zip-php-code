<?php
session_start();
require_once 'config.php';

// Check if admin or faculty
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'faculty')) {
    header("Location: login.php");
    exit();
}

$message = "";

// Add new course
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_course'])) {
    $course_code = $_POST['course_code'];
    $course_name = $_POST['course_name'];
    $description = $_POST['description'];
    $credits = $_POST['credits'];
    $semester = $_POST['semester'];
    $faculty_id = $_POST['faculty_id'];
    
    $sql = "INSERT INTO courses (course_code, course_name, description, credits, semester, faculty_id) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssiis", $course_code, $course_name, $description, $credits, $semester, $faculty_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = "<div class='alert alert-success'>Course added successfully</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error adding course: " . mysqli_error($conn) . "</div>";
    }
}

// Assign course to student
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_course'])) {
    $course_id = $_POST['course_id'];
    $student_id = $_POST['student_id'];
    
    // Check if already assigned
    $check_sql = "SELECT * FROM student_courses WHERE course_id = ? AND student_id = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "ii", $course_id, $student_id);
    mysqli_stmt_execute($check_stmt);
    
    if (mysqli_num_rows(mysqli_stmt_get_result($check_stmt)) > 0) {
        $message = "<div class='alert alert-warning'>Student already enrolled in this course</div>";
    } else {
        $sql = "INSERT INTO student_courses (course_id, student_id, enrollment_date) 
                VALUES (?, ?, CURDATE())";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $course_id, $student_id);
        
        if (mysqli_stmt_execute($stmt)) {
            $message = "<div class='alert alert-success'>Student enrolled successfully</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error enrolling student</div>";
        }
    }
}

// Get all courses
$courses_sql = "SELECT c.*, u.full_name as faculty_name 
                FROM courses c 
                LEFT JOIN users u ON c.faculty_id = u.user_id 
                ORDER BY c.semester, c.course_code";
$courses_result = mysqli_query($conn, $courses_sql);

// Get faculty for dropdown
$faculty_sql = "SELECT user_id, full_name FROM users WHERE role = 'faculty' ORDER BY full_name";
$faculty_result = mysqli_query($conn, $faculty_sql);

// Get students for dropdown
$students_sql = "SELECT user_id, username, full_name FROM users WHERE role = 'student' ORDER BY full_name";
$students_result = mysqli_query($conn, $students_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2>Course Management</h2>
        
        <?php echo $message; ?>
        
        <div class="row">
            <!-- Add Course Form -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Add New Course</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Course Code</label>
                                <input type="text" class="form-control" name="course_code" required 
                                       pattern="[A-Z]{3,4}[0-9]{3}" 
                                       title="Format: ABC123 or ABCD123">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Course Name</label>
                                <input type="text" class="form-control" name="course_name" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="3"></textarea>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Credits</label>
                                    <select class="form-select" name="credits" required>
                                        <option value="1">1 Credit</option>
                                        <option value="2">2 Credits</option>
                                        <option value="3" selected>3 Credits</option>
                                        <option value="4">4 Credits</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Semester</label>
                                    <select class="form-select" name="semester" required>
                                        <option value="Spring 2024">Spring 2024</option>
                                        <option value="Fall 2024">Fall 2024</option>
                                        <option value="Spring 2025">Spring 2025</option>
                                        <option value="Fall 2025">Fall 2025</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Faculty In-charge</label>
                                <select class="form-select" name="faculty_id" required>
                                    <option value="">Select Faculty</option>
                                    <?php while ($faculty = mysqli_fetch_assoc($faculty_result)): ?>
                                    <option value="<?php echo $faculty['user_id']; ?>">
                                        <?php echo htmlspecialchars($faculty['full_name']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <button type="submit" name="add_course" class="btn btn-primary">Add Course</button>
                        </form>
                    </div>
                </div>
                
                <!-- Assign Student Form -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Enroll Student in Course</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Select Course</label>
                                <select class="form-select" name="course_id" required>
                                    <option value="">Select Course</option>
                                    <?php mysqli_data_seek($courses_result, 0); ?>
                                    <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
                                    <option value="<?php echo $course['course_id']; ?>">
                                        <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Select Student</label>
                                <select class="form-select" name="student_id" required>
                                    <option value="">Select Student</option>
                                    <?php mysqli_data_seek($students_result, 0); ?>
                                    <?php while ($student = mysqli_fetch_assoc($students_result)): ?>
                                    <option value="<?php echo $student['user_id']; ?>">
                                        <?php echo htmlspecialchars($student['full_name'] . ' (' . $student['username'] . ')'); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <button type="submit" name="assign_course" class="btn btn-primary">Enroll Student</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Courses List -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>All Courses</h5>
                        <div>
                            <select class="form-select form-select-sm" id="semesterFilter" onchange="filterCourses()">
                                <option value="all">All Semesters</option>
                                <option value="Spring 2024">Spring 2024</option>
                                <option value="Fall 2024">Fall 2024</option>
                                <option value="Spring 2025">Spring 2025</option>
                                <option value="Fall 2025">Fall 2025</option>
                            </select>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="coursesTable">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Course Name</th>
                                        <th>Credits</th>
                                        <th>Semester</th>
                                        <th>Faculty</th>
                                        <th>Enrolled</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php mysqli_data_seek($courses_result, 0); ?>
                                    <?php while ($course = mysqli_fetch_assoc($courses_result)): 
                                        // Get enrolled count
                                        $enroll_sql = "SELECT COUNT(*) as count FROM student_courses WHERE course_id = ?";
                                        $enroll_stmt = mysqli_prepare($conn, $enroll_sql);
                                        mysqli_stmt_bind_param($enroll_stmt, "i", $course['course_id']);
                                        mysqli_stmt_execute($enroll_stmt);
                                        $enroll_result = mysqli_stmt_get_result($enroll_stmt);
                                        $enrolled = mysqli_fetch_assoc($enroll_result)['count'];
                                    ?>
                                    <tr data-semester="<?php echo $course['semester']; ?>">
                                        <td><?php echo htmlspecialchars($course['course_code']); ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($course['course_name']); ?></strong><br>
                                            <small class="text-muted"><?php echo htmlspecialchars(substr($course['description'], 0, 60)); ?>...</small>
                                        </td>
                                        <td><?php echo $course['credits']; ?></td>
                                        <td><?php echo htmlspecialchars($course['semester']); ?></td>
                                        <td><?php echo htmlspecialchars($course['faculty_name']); ?></td>
                                        <td>
                                            <span class="badge bg-primary"><?php echo $enrolled; ?> students</span>
                                        </td>
                                        <td>
                                            <a href="view_course.php?id=<?php echo $course['course_id']; ?>" 
                                               class="btn btn-sm btn-info" title="View Details">
                                               <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit_course.php?id=<?php echo $course['course_id']; ?>" 
                                               class="btn btn-sm btn-warning" title="Edit">
                                               <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="course_students.php?id=<?php echo $course['course_id']; ?>" 
                                               class="btn btn-sm btn-primary" title="View Students">
                                               <i class="fas fa-users"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function filterCourses() {
        var semester = document.getElementById('semesterFilter').value;
        var rows = document.querySelectorAll('#coursesTable tbody tr');
        
        rows.forEach(function(row) {
            if (semester == 'all' || row.getAttribute('data-semester') == semester) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>