<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

// Require admin role
requireRole('admin');

// Get dashboard statistics
$stats = getDashboardStats(null, 'admin');
$pendingReservations = getPendingReservations();
$recentUsers = getUsersByRole('student', 10);
$recentNotifications = getUserNotifications($_SESSION['user_id'], 5);

// Get recent activity
$conn = 'getConnection'();
$stmt = $conn->prepare("SELECT * FROM system_logs ORDER BY created_at DESC LIMIT 10");
$stmt->execute();
$recentActivity = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo 'SITE_NAME'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="dashboard-content">
            <div class="dashboard-header">
                <h1><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h1>
                <div class="user-info">
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['first_name']); ?>!</span>
                </div>
            </div>
            
            <?php $message = getFlash('success'); if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php $error = getFlash('error'); if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card stat-primary">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $stats['total_users'] ?? 0; ?></div>
                        <div class="stat-label">Total Users</div>
                    </div>
                    <a href="manage_accounts.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
                </div>
                
                <div class="stat-card stat-success">
                    <div class="stat-icon">
                        <i class="fas fa-desktop"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $stats['available_equipment'] ?? 0; ?></div>
                        <div class="stat-label">Available Equipment</div>
                    </div>
                    <a href="manage_equipment.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
                </div>
                
                <div class="stat-card stat-warning">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $stats['pending_reservations'] ?? 0; ?></div>
                        <div class="stat-label">Pending Reservations</div>
                    </div>
                    <a href="manage_reservation.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
                </div>
                
                <div class="stat-card stat-danger">
                    <div class="stat-icon">
                        <i class="fas fa-tools"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $stats['pending_requests'] ?? 0; ?></div>
                        <div class="stat-label">Pending Requests</div>
                    </div>
                    <a href="view_requests.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            
            <!-- Charts Section -->
            <div class="charts-grid">
                <div class="chart-card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-line"></i> User Registrations (Last 7 Days)</h3>
                    </div>
                    <div class="card-body">
                        <canvas id="userChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-pie"></i> User Distribution by Role</h3>
                    </div>
                    <div class="card-body">
                        <canvas id="roleChart"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="quick-actions">
                <h2><i class="fas fa-bolt"></i> Quick Actions</h2>
                <div class="actions-grid">
                    <a href="add_user.php" class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div class="action-text">
                            <h3>Add New User</h3>
                            <p>Create new user accounts</p>
                        </div>
                    </a>
                    
                    <a href="manage_labs.php" class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="action-text">
                            <h3>Manage Labs</h3>
                            <p>Add/edit laboratory information</p>
                        </div>
                    </a>
                    
                    <a href="post_notification.php" class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <div class="action-text">
                            <h3>Post Notification</h3>
                            <p>Send announcements to users</p>
                        </div>
                    </a>
                    
                    <a href="generates_reports.php" class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="action-text">
                            <h3>Generate Reports</h3>
                            <p>Create system reports</p>
                        </div>
                    </a>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="recent-activity">
                <div class="activity-header">
                    <h2><i class="fas fa-history"></i> Recent Activity</h2>
                    <a href="view_reports.php" class="view-all">View All</a>
                </div>
                <div class="activity-list">
                    <?php if (empty($recentActivity)): ?>
                        <div class="empty-state">
                            <i class="fas fa-info-circle"></i>
                            <p>No recent activity found</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($recentActivity as $activity): ?>
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <i class="fas fa-<?php echo $activity['action'] === 'login' ? 'sign-in-alt' : 'edit'; ?>"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title"><?php echo htmlspecialchars($activity['action']); ?></div>
                                    <div class="activity-details">
                                        <span class="activity-user">
                                            User ID: <?php echo $activity['user_id'] ?? 'System'; ?>
                                        </span>
                                        <span class="activity-time">
                                            <?php echo formatDate($activity['created_at'], 'M d, H:i'); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Pending Reservations -->
            <div class="pending-reservations">
                <div class="reservation-header">
                    <h2><i class="fas fa-clock"></i> Pending Reservations</h2>
                    <a href="manage_reservation.php" class="view-all">View All</a>
                </div>
                <div class="reservation-list">
                    <?php if (empty($pendingReservations)): ?>
                        <div class="empty-state">
                            <i class="fas fa-check-circle"></i>
                            <p>No pending reservations</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($pendingReservations as $reservation): ?>
                            <div class="reservation-item">
                                <div class="reservation-info">
                                    <div class="reservation-title">
                                        <strong><?php echo htmlspecialchars($reservation['equipment_name']); ?></strong>
                                        <span class="badge badge-warning">Pending</span>
                                    </div>
                                    <div class="reservation-details">
                                        <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($reservation['user_name']); ?></span>
                                        <span><i class="fas fa-calendar"></i> <?php echo formatDate($reservation['reservation_date']); ?></span>
                                        <span><i class="fas fa-clock"></i> <?php echo formatTime($reservation['start_time']); ?> - <?php echo formatTime($reservation['end_time']); ?></span>
                                    </div>
                                </div>
                                <div class="reservation-actions">
                                    <button class="btn btn-sm btn-success approve-btn" data-id="<?php echo $reservation['reservation_id']; ?>">
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                    <button class="btn btn-sm btn-danger reject-btn" data-id="<?php echo $reservation['reservation_id']; ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script src="js/script.js"></script>
    <script>
        // User Registration Chart
        const userCtx = document.getElementById('userChart').getContext('2d');
        const userChart = new Chart(userCtx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'New Users',
                    data: [12, 19, 8, 15, 12, 10, 7],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 5
                        }
                    }
                }
            }
        });
        
        // Role Distribution Chart
        const roleCtx = document.getElementById('roleChart').getContext('2d');
        const roleChart = new Chart(roleCtx, {
            type: 'doughnut',
            data: {
                labels: ['Students', 'Faculty', 'Admin', 'Technicians'],
                datasets: [{
                    data: [65, 20, 5, 10],
                    backgroundColor: [
                        '#3498db',
                        '#2ecc71',
                        '#e74c3c',
                        '#f39c12'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        
        // Handle reservation actions
        document.querySelectorAll('.approve-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const reservationId = this.dataset.id;
                if (confirm('Are you sure you want to approve this reservation?')) {
                    updateReservationStatus(reservationId, 'approved');
                }
            });
        });
        
        document.querySelectorAll('.reject-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const reservationId = this.dataset.id;
                if (confirm('Are you sure you want to reject this reservation?')) {
                    updateReservationStatus(reservationId, 'rejected');
                }
            });
        });
        
        function updateReservationStatus(reservationId, status) {
            fetch('ajax/update_reservation.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    reservation_id: reservationId,
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred');
            });
        }
    </script>
</body>
</html>