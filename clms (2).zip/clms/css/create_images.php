<?php
// Create placeholder images for the project
require_once 'config/config.php';

function createPlaceholderImage($width, $height, $text, $filename) {
    // Create image
    $image = imagecreatetruecolor($width, $height);
    
    // Colors
    $background = imagecolorallocate($image, 52, 152, 219); // Blue background
    $textColor = imagecolorallocate($image, 255, 255, 255); // White text
    $darkBlue = imagecolorallocate($image, 41, 128, 185); // Darker blue
    
    // Fill background
    imagefilledrectangle($image, 0, 0, $width, $height, $background);
    
    // Add gradient effect
    for ($i = 0; $i < $height; $i++) {
        $color = imagecolorallocate($image, 
            52 - ($i / $height * 20), 
            152 - ($i / $height * 20), 
            219 - ($i / $height * 20)
        );
        imageline($image, 0, $i, $width, $i, $color);
    }
    
    // Add text
    $fontSize = min($width / strlen($text) * 1.5, $height / 3);
    $font = 5; // Use built-in GD font
    
    // Calculate text position
    $textBoundingBox = imagettfbbox($fontSize, 0, __DIR__ . '/fonts/arial.ttf', $text);
    $textWidth = $textBoundingBox[2] - $textBoundingBox[0];
    $textHeight = $textBoundingBox[1] - $textBoundingBox[7];
    
    $x = ($width - $textWidth) / 2;
    $y = ($height + $textHeight) / 2;
    
    // If you have a font file, use it:
    // imagettftext($image, $fontSize, 0, $x, $y, $textColor, 'arial.ttf', $text);
    
    // Or use built-in font:
    $fontWidth = imagefontwidth($font);
    $fontHeight = imagefontheight($font);
    $textWidth = strlen($text) * $fontWidth;
    $textHeight = $fontHeight;
    
    $x = ($width - $textWidth) / 2;
    $y = ($height - $textHeight) / 2;
    
    imagestring($image, $font, $x, $y, $text, $textColor);
    
    // Add border
    imagerectangle($image, 0, 0, $width-1, $height-1, $darkBlue);
    
    // Save image
    imagejpeg($image, __DIR__ . '/images/' . $filename, 90);
    imagedestroy($image);
    
    return 'images/' . $filename;
}

// Create necessary directories
$directories = [
    'images',
    'uploads/profile_pics',
    'uploads/reports'
];

foreach ($directories as $dir) {
    if (!is_dir(__DIR__ . '/' . $dir)) {
        mkdir(__DIR__ . '/' . $dir, 0755, true);
    }
}

// Create placeholder images
$images = [
    ['1200', '600', 'Wachemo University Computer Lab', 'hero-bg.jpg'],
    ['300', '100', 'WU CLMS', 'logo.png'],
    ['100', '100', 'WU', 'logo-icon.png'],
    ['800', '400', 'Computer Laboratory 1', 'lab-1.jpg'],
    ['800', '400', 'Computer Laboratory 2', 'lab-2.jpg'],
    ['600', '400', 'Desktop Computers', 'equipment-1.jpg'],
    ['600', '400', 'Network Equipment', 'equipment-2.jpg'],
    ['800', '600', 'Wachemo University Campus', 'campus-building.jpg'],
    ['800', '600', 'Modern Computer Lab', 'computer-lab.jpg'],
    ['200', '200', 'University Badge', 'university-badge.png'],
    ['400', '400', 'Default User', 'default-avatar.jpg']
];

echo "<h1>Creating Placeholder Images...</h1>";
echo "<ul>";

foreach ($images as $image) {
    list($width, $height, $text, $filename) = $image;
    $path = createPlaceholderImage($width, $height, $text, $filename);
    echo "<li>Created: $path</li>";
}

// Copy default avatar to profile_pics directory
copy(__DIR__ . '/images/default-avatar.jpg', __DIR__ . '/uploads/profile_pics/default.jpg');

echo "<li>Copied default profile picture</li>";
echo "</ul>";
echo "<h2>Images created successfully!</h2>";
echo "<p>You can now replace these placeholder images with actual images.</p>";
?>