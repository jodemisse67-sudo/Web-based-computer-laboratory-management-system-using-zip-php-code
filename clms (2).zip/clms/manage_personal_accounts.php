<?php
// ... existing code ...

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_picture'])) {
    $file = $_FILES['profile_picture'];
    
    // Check for errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'File upload error: ' . $file['error'];
    } else {
        // Check file size (max 5MB)
        if ($file['size'] > 5242880) {
            $error = 'File is too large. Maximum size is 5MB.';
        } else {
            // Check file type
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowedTypes)) {
                $error = 'Only JPG, PNG, and GIF files are allowed.';
            } else {
                // Generate unique filename
                $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                $filename = 'user_' . $_SESSION['user_id'] . '_' . time() . '.' . $extension;
                $destination = 'uploads/profile_pics/' . $filename;
                
                // Create directory if it doesn't exist
                if (!is_dir('uploads/profile_pics')) {
                    mkdir('uploads/profile_pics', 0755, true);
                }
                
                // Move uploaded file
                if (move_uploaded_file($file['tmp_name'], $destination)) {
                    // Update database
                    $conn = 'getConnection'();
                    $stmt = $conn->prepare("UPDATE users SET profile_pic = ? WHERE user_id = ?");
                    
                    if ($stmt->execute([$filename, $_SESSION['user_id']])) {
                        // Update session
                        $_SESSION['profile_pic'] = $filename;
                        
                        // Delete old profile picture if not default
                        $oldFile = 'uploads/profile_pics/' . $currentUser['profile_pic'];
                        if ($currentUser['profile_pic'] !== 'default.jpg' && file_exists($oldFile)) {
                            unlink($oldFile);
                        }
                        
                        $success = 'Profile picture updated successfully!';
                    } else {
                        $error = 'Failed to update profile picture in database.';
                    }
                } else {
                    $error = 'Failed to save uploaded file.';
                }
            }
        }
    }
}

// ... rest of the code ...
?>

<!-- Add profile picture upload form -->
<div class="profile-picture-section">
    <h3><i class="fas fa-camera"></i> Profile Picture</h3>
    
    <div class="current-picture">
        <img src="uploads/profile_pics/<?php echo htmlspecialchars($currentUser['profile_pic']); ?>" 
             alt="Current Profile Picture" class="profile-picture-large">
    </div>
    
    <form method="POST" action="" enctype="multipart/form-data" class="upload-form">
        <div class="form-group">
            <label for="profile_picture">Upload New Picture</label>
            <input type="file" id="profile_picture" name="profile_picture" 
                   accept="image/jpeg,image/png,image/gif" class="form-control">
            <small class="form-text">Maximum size: 5MB. Allowed formats: JPG, PNG, GIF</small>
        </div>
        
        <div class="form-preview" id="imagePreview">
            <img id="previewImage" src="" alt="Preview" style="display: none;">
        </div>
        
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-upload"></i> Upload Picture
        </button>
    </form>
</div>

<script>
// Image preview functionality
document.getElementById('profile_picture').addEventListener('change', function(e) {
    const preview = document.getElementById('previewImage');
    const previewContainer = document.getElementById('imagePreview');
    const file = e.target.files[0];
    
    if (file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            previewContainer.style.display = 'block';
        }
        
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
});
</script>

<style>
.profile-picture-section {
    background: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow);
    margin-bottom: 2rem;
}

.current-picture {
    text-align: center;
    margin-bottom: 2rem;
}

.profile-picture-large {
    width: 200px;
    height: 200px;
    border-radius: 50%;
    object-fit: cover;
    border: 5px solid white;
    box-shadow: var(--shadow);
}

.upload-form {
    max-width: 500px;
    margin: 0 auto;
}

.form-preview {
    margin: 1rem 0;
    text-align: center;
    display: none;
}

#previewImage {
    max-width: 200px;
    max-height: 200px;
    border-radius: 10px;
    box-shadow: var(--shadow);
}

@media (max-width: 768px) {
    .profile-picture-large {
        width: 150px;
        height: 150px;
    }
}
</style>