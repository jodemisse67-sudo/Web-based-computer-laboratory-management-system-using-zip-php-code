<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'faculty') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get faculty stats
$stats = [];

// Total approved reservations
$sql = "SELECT COUNT(*) as total FROM reservations 
        WHERE user_id = ? AND status = 'approved'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$stats['approved'] = mysqli_fetch_assoc($result)['total'];

// Pending reservations
$sql = "SELECT COUNT(*) as total FROM reservations 
        WHERE user_id = ? AND status = 'pending'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$stats['pending'] = mysqli_fetch_assoc($result)['total'];

// Upcoming reservations
$sql = "SELECT COUNT(*) as total FROM reservations 
        WHERE user_id = ? AND status = 'approved' 
        AND reservation_date >= CURDATE()";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$stats['upcoming'] = mysqli_fetch_assoc($result)['total'];

// Get upcoming reservations
$upcoming_sql = "SELECT r.*, l.lab_name 
                 FROM reservations r 
                 JOIN labs l ON r.lab_id = l.lab_id 
                 WHERE r.user_id = ? AND r.status = 'approved' 
                 AND r.reservation_date >= CURDATE() 
                 ORDER BY r.reservation_date ASC, r.start_time ASC 
                 LIMIT 5";
$upcoming_stmt = mysqli_prepare($conn, $upcoming_sql);
mysqli_stmt_bind_param($upcoming_stmt, "i", $user_id);
mysqli_stmt_execute($upcoming_stmt);
$upcoming_result = mysqli_stmt_get_result($upcoming_stmt);

// Get recent notifications
$notifications_sql = "SELECT * FROM notifications 
                      WHERE (target_user = ? OR target_user = 'all') 
                      AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) 
                      ORDER BY created_at DESC LIMIT 5";
$notifications_stmt = mysqli_prepare($conn, $notifications_sql);
mysqli_stmt_bind_param($notifications_stmt, "i", $user_id);
mysqli_stmt_execute($notifications_stmt);
$notifications_result = mysqli_stmt_get_result($notifications_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard - CLMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2>Faculty Dashboard</h2>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Approved</h5>
                                <h2><?php echo $stats['approved']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-check-circle fa-3x"></i>
                            </div>
                        </div>
                        <p class="mb-0">Total Approved Reservations</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card bg-warning text-dark">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Pending</h5>
                                <h2><?php echo $stats['pending']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-clock fa-3x"></i>
                            </div>
                        </div>
                        <p class="mb-0">Awaiting Approval</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Upcoming</h5>
                                <h2><?php echo $stats['upcoming']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-calendar-alt fa-3x"></i>
                            </div>
                        </div>
                        <p class="mb-0">Scheduled Reservations</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h5>Quick Actions</h5>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-bolt fa-3x"></i>
                            </div>
                        </div>
                        <div class="mt-2">
                            <a href="make_reservation.php" class="btn btn-light btn-sm me-2">New Booking</a>
                            <a href="my_reservations.php" class="btn btn-light btn-sm">View All</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="row">
            <!-- Upcoming Reservations -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Upcoming Reservations</h5>
                        <a href="my_reservations.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($upcoming_result) > 0): ?>
                        <div class="list-group">
                            <?php while ($res = mysqli_fetch_assoc($upcoming_result)): ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($res['lab_name']); ?></h6>
                                    <small><?php echo date('M d', strtotime($res['reservation_date'])); ?></small>
                                </div>
                                <p class="mb-1">
                                    <i class="fas fa-clock"></i> 
                                    <?php echo date('g:i A', strtotime($res['start_time'])); ?> - 
                                    <?php echo date('g:i A', strtotime($res['end_time'])); ?>
                                </p>
                                <small class="text-muted"><?php echo htmlspecialchars(substr($res['purpose'], 0, 100)); ?></small>
                                <div class="mt-2">
                                    <a href="view_reservation.php?id=<?php echo $res['reservation_id']; ?>" 
                                       class="btn btn-sm btn-outline-primary">View</a>
                                    <?php if (strtotime($res['reservation_date'] . ' ' . $res['start_time']) > strtotime('+2 hours')): ?>
                                    <a href="cancel_reservation.php?id=<?php echo $res['reservation_id']; ?>" 
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Cancel this reservation?')">Cancel</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-info">No upcoming reservations</div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Quick Stats Chart -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Monthly Usage</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="usageChart" height="150"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Notifications -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Recent Notifications</h5>
                        <a href="notifications.php" class="btn btn-sm btn-primary">See All</a>
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($notifications_result) > 0): ?>
                        <div class="list-group">
                            <?php while ($notif = mysqli_fetch_assoc($notifications_result)): ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($notif['title']); ?></h6>
                                    <small><?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></small>
                                </div>
                                <p class="mb-1"><?php echo htmlspecialchars(substr($notif['message'], 0, 150)); ?></p>
                                <?php if ($notif['priority'] == 'high'): ?>
                                <span class="badge bg-danger">Important</span>
                                <?php endif; ?>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-info">No recent notifications</div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- System Status -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Lab Availability Status</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $labs_sql = "SELECT l.*, 
                                    (SELECT COUNT(*) FROM reservations r 
                                     WHERE r.lab_id = l.lab_id 
                                     AND r.reservation_date = CURDATE() 
                                     AND r.status = 'approved') as today_reservations
                                    FROM labs l 
                                    WHERE l.status = 'active' 
                                    LIMIT 4";
                        $labs_result = mysqli_query($conn, $labs_sql);
                        ?>
                        <div class="row">
                            <?php while ($lab = mysqli_fetch_assoc($labs_result)): 
                                $availability = $lab['capacity'] - $lab['today_reservations'];
                            ?>
                            <div class="col-md-6 mb-3">
                                <div class="border rounded p-3">
                                    <h6><?php echo htmlspecialchars($lab['lab_name']); ?></h6>
                                    <div class="progress mb-2" style="height: 10px;">
                                        <?php $percent = ($lab['today_reservations'] / $lab['capacity']) * 100; ?>
                                        <div class="progress-bar bg-<?php echo $percent > 80 ? 'danger' : ($percent > 50 ? 'warning' : 'success'); ?>" 
                                             style="width: <?php echo $percent; ?>%">
                                        </div>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo $availability; ?> of <?php echo $lab['capacity']; ?> seats available today
                                    </small>
                                    <div class="mt-2">
                                        <a href="make_reservation.php?lab_id=<?php echo $lab['lab_id']; ?>" 
                                           class="btn btn-sm btn-outline-primary">Book Now</a>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    // Chart for monthly usage
    var ctx = document.getElementById('usageChart').getContext('2d');
    var usageChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Reservations',
                data: [12, 19, 15, 25, 22, 18],
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 5
                    }
                }
            }
        }
    });
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>