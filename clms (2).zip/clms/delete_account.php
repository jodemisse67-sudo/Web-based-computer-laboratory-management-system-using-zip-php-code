<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $delete_id = $_GET['id'];
    
    // Check if user is admin or deleting their own account
    if ($_SESSION['role'] != 'admin' && $_SESSION['user_id'] != $delete_id) {
        $_SESSION['error'] = "Unauthorized to delete this account";
        header("Location: dashboard.php");
        exit();
    }
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Delete user's reservations first
        $delete_reservations = "DELETE FROM reservations WHERE user_id = ?";
        $stmt1 = mysqli_prepare($conn, $delete_reservations);
        mysqli_stmt_bind_param($stmt1, "i", $delete_id);
        mysqli_stmt_execute($stmt1);
        
        // Delete user account
        $delete_user = "DELETE FROM users WHERE user_id = ?";
        $stmt2 = mysqli_prepare($conn, $delete_user);
        mysqli_stmt_bind_param($stmt2, "i", $delete_id);
        mysqli_stmt_execute($stmt2);
        
        mysqli_commit($conn);
        
        // If user deleted their own account, log them out
        if ($_SESSION['user_id'] == $delete_id) {
            session_destroy();
            $_SESSION['success'] = "Account deleted successfully";
            header("Location: index.php");
        } else {
            $_SESSION['success'] = "Account deleted successfully";
            header("Location: manage_users.php");
        }
        exit();
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Error deleting account: " . $e->getMessage();
        header("Location: dashboard.php");
        exit();
    }
} else {
    header("Location: dashboard.php");
    exit();
}
?>